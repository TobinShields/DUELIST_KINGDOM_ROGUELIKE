DUELIST KINGDOM · GOAT FORMAT SIMULATOR · Build 1.0
=====================================================

Open goat-simulador.html by double-clicking it. That's the whole
installation. Keep deckbuilder.html in the same folder: the game's
Deck Builder button opens it.

- Card artwork is loaded from the internet; offline you still play.
- Play with a friend needs an internet connection on both sides.
- Your decks and progress are saved in this browser, on this device.
  Options > Your data > Save backup keeps a copy.

Bugs and AI misplays: the Report button in the game, or
https://github.com/circlenline/DUELIST_KINGDOM_ROGUELIKE/issues

---

Abre goat-simulador.html con doble clic. Deja deckbuilder.html en la
misma carpeta. Para jugar con un amigo hace falta internet. Tus mazos se
guardan en este navegador: Opciones > Tus datos > Guardar copia.
