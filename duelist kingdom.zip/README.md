# Goat Format Simulator

A playable Yu-Gi-Oh! **Goat Format** (April 2005) simulator that runs from a single
HTML file, plus a **Duelist Kingdom roguelike** built on top of it.
No install, no account, no server — download it, double-click it, play.

![Duelist Kingdom](docs/img/banner.jpg)

**[▶ Play in your browser](https://circlenline.github.io/goat-format-simulator/)**

![The duel board](docs/img/duelo.jpg)

---

## Two ways to play

**Free Duel** — pick any of the 20 tournament decks (or build your own), pick an
opponent deck, pick a difficulty, duel. There's also a Challenge board: every deck
against every difficulty, with a medal for each one you beat.

**Duelist Kingdom** — a roguelike run through the island. You start with a
40-card starter deck and 2 Star Chips, and you have to reach Pegasus Castle with
**10**. Every duel you win gives you a card; every duel you lose costs you a chip.
At zero chips the run is over and you start again.

---

## Duelist Kingdom

### The run

You pick a duelist — Yugi, Joey, Mai, Bandit Keith, Kaiba or a **Free Duelist**
you name yourself — and one of their starter decks. There are 20 starters in
total, and none of them is a tournament deck: they're anime decks with a theme
and a lot of room to grow.

The island is three acts, and each act is a column map like *Slay the Spire*:
one, two or three nodes per column, and the route you take is the route you
don't. The branches are real — the paths are explicit edges, not "pick any node
in the next column" — so two runs of the same map play differently.

| Node | What happens |
|---|---|
| **Duel** | A rival from the anime. Win +1 chip and a card; lose −1 chip. |
| **Elite** | Harder deck, better rewards: +2 chips and a rarer card. Marked with a crown. |
| **Boss** | Closes the act. You have to beat it to move on. |
| **Card pack** | Choose 1 of 5 packs, get 10 cards. |
| **Merchant** | No money on this island — you pay with cards. Ten pieces of junk buy one good card. |
| **Camp** | One thing only: +1000 LP for your next three duels, recover a lost chip, or upgrade a card. |
| **Encounter** | A portrait, a couple of lines and a decision. Eight of them, sixteen choices. |
| **Last Chance** | If you reach the castle short of 10 chips, extra duels appear. You can never get stuck. |

### Building a deck as you go

Every duel win offers **three cards** and you keep one. Packs give ten at once.
Everything you don't play goes to the **binder**, and Deck & Binder is where you
move cards between the two — 40 minimum, copy limits enforced against the real
Goat banlist.

Packs have five families (Arcane Arts, Warrior Arsenal, Dragon's Roar, Recruiter
Front, Forbidden Tactics) and you can read exactly what's inside each one before
you open it — hover on desktop, a button on mobile, and a full searchable guide
that tells you which pack a specific card comes from.

Two rules the pack pools have to obey, and there's a test for each:

- **Everything offered has to be playable.** A Fusion you can never summon, a
  Ritual monster whose spell isn't in any pool, a Horus LV6 with no LV4 to
  destroy — those are collectible cards, not playable ones. The validator walks
  every Fusion, Ritual and condition monster the game hands out and checks the
  route exists.
- **Every starter has to have support.** The packs only deal ~210 cards of the
  1,685 in the pool, so if your archetype isn't in there you open packs all run
  and never improve. There's a tool that derives each deck's signals from the
  deck itself — races, archetype names, mechanics its cards repeat — and counts
  how much of that the packs actually deal. Harpies used to score 6. They don't
  anymore.

### The castle

![The castle tower](docs/img/torre.jpg)

Reach the castle with 10 chips and it's a tower: the other four playable
duelists, then Pegasus, with one preparation stop in the middle (a pack, the
merchant or a camp — one, and you choose).

Pegasus plays at 10000 LP and opens with seven cards. His deck is Goat Control
with a Toon package inside it — the Toon cards on their own are a bad deck, so
he gets a real meta shell with the theme sitting in it, and Toon World guaranteed
in his opening hand so the package works at all.

### Mastery

Beat Pegasus with a duelist and you unlock a permanent advantage for that
duelist. Three levels:

1. **The master's card** — pick 1 of 10 signature cards and start with it.
2. **Contacts on the island** — start with a pack of your chosen family, already open.
3. **Steady hand** — every duel reward comes one rarity tier higher.

You only use **one per run**, even with all three unlocked. Stacking them would
turn the fifth run into a free deck.

And Pegasus reads the room: once you have mastery unlocked, he stops playing the
Toon shell and brings the actual tournament decks.

Progress lives in your browser, and there's an Export/Import file so you can move
it to another browser or another phone.

---

## The rules

![A duel against Pegasus](docs/img/duelo-pegasus.jpg)

The rules are not hand-written. The simulator runs **ocgcore** — the same engine
EDOPro uses — compiled to WebAssembly and started in `MODE_GOAT`. That means 2005
rulings behave like 2005: SEGOC, the six damage-step timings, ignition priority,
attack replays, one Field Spell shared by both players.

Writing Yu-Gi-Oh's rules by hand would have been a multi-year project with ruling
bugs forever. This way a chain of four resolves correctly because the engine says
so, not because somebody remembered to code it.

> Playing Goat online today mostly means Dueling Book, where every ruling is
> manual and both players have to agree on what happened. Here the engine resolves
> everything, and you can play alone.

Everything travels inside the HTML: the wasm engine, 1,364 Lua card scripts, the
card database, the decks and the portraits. The only thing fetched from the
network is card artwork. Offline you still play — cards fall back to a tile with
name, ATK/DEF and level.

### One thing worth knowing about how the board is read

The engine identifies cards by **position**, not by identity. If the interface
ever pairs a card by index, a single off-by-one means you play a different card
than the one you dragged — and that really happened: the UI said "set Chaos
Sorcerer" and the engine set Nobleman of Crossout, because Delinquent Duo and
Graceful Charity *shuffle your hand* and nobody was following that message.
Everything now resolves to a stable id.

The same applies to face-down cards. Positions are **bit masks**, not values, and
visibility depends on the **zone**, not the position: a card returned from the
graveyard arrives with the face-down bit set and would be drawn backwards in your
own hand if you trusted the position alone.

And ATK on the board is not ATK in the database. Thousand-Eyes Restrict is listed
at 0 and hits for 1900 when it's absorbing something; a monster under Snatch Steal
doesn't match its card either. The AI used to never attack with a TER for exactly
that reason. Now the board is queried for real stats once per decision.

---

## The bots

Four difficulties, and the difference between them is **measured**, not asserted.

There's no lookahead: ocgcore can't clone or serialize a duel, so there's no tree
search here — the AI is heuristic, like Master Duel's. What it has instead:

- **A vocabulary of card roles** for the cards where arithmetic isn't enough:
  D.D. Warrior Lady banishes *both* monsters even if you kill her, Spirit Reaper
  survives combat, Jinzo and Royal Decree have to go before anything else, spirit
  monsters return to the hand.
- **A card-text reader** for the other 1,576. It reads what the card actually
  says and derives what it does and what it needs to do it. What it can't parse
  scores **zero**, which is the safe side — the previous default was "if you
  don't recognise the card, play it as soon as you can", and that's where the
  Breaker blowing up a random face-down instead of the Premature Burial holding a
  Jinzo came from.
- **A plan per deck**: what each of the 20 decks wins with, how much it should
  risk, which cards are the heavy ones, taken from the published deck guides.
- **A legal view of the board.** The bot literally cannot see your face-down
  cards; there's a boundary module that trims what it's allowed to know, and it
  remembers only what it has legitimately seen.

### How it was tuned

Bot-vs-bot win rate is useless for this — two equally bad bots split 50/50 no
matter what you change. So the yardstick is a **bench of 94 fixed positions with
the known-correct play**, the way chess engines are tested. Each position came
from a real misplay somebody reported.

The progression across versions: **49 → 65 → 74 → 81 → 86 → 89 → 99**.

The other measuring stick is a scanner that plays hundreds of games and counts
**nonsense plays** by name — Snatch Steal on a Scapegoat token, Book of Moon
chained to your own summon with an empty opposing board, Skull Lair eating your
own monster. That number went from 1.38 per game to 0.06, and it's the one that
matches what a player actually complains about. The win rate only proves that
fixing it didn't cost games.

A few things the bots were explicitly taught, each because of a real report:

- A list of legal targets includes **your own cards**. The engine doesn't say
  whether an effect helps or hurts its target, so Ring of Destruction, Book of
  Moon and Nobleman all happily pointed at friendly monsters.
- **Trading isn't suicide.** Equal ATK kills both monsters — that's a trade, and
  it was being scored as a suicide, which is why a Thunder Dragon stolen with
  Mind Control refused to attack a 1600 Breaker and went home untouched.
- **Borrowed monsters have to be spent.** Anything taken with Mind Control or
  Snatch Steal goes back at end of turn; not putting it into combat is giving it
  back for free.
- **Mass removal is a balance, not a card count.** Heavy Storm with three of your
  own backrow against one of theirs is not a play.
- **Holding cards for the perfect moment loses games.** The first "expert" bot
  lost 36% to the medium one because cards died in its hand.

Some of the rules that make it play *well* actually measure **worse** in bot-vs-bot
— not summoning into something bigger, setting instead of handing over a card. A
bot opponent doesn't punish you for giving away cards, so caution only costs
tempo. It's 2 to 4 points, measured repeatedly. They stayed in, and the number
gets stated rather than hidden.

---

## Deck builder

A second HTML file with all 1,685 legal cards: search, copy limits from the real
banlist, YDK import and export, and decks saved in your browser. Anything you
build there shows up in the simulator's deck list.

One quiet trap it handles: many Goat cards exist under **two passcodes**, and the
Lua script only lives on one of them. A decklist copied off the internet often
carries the other, and that card would be dealt, summoned, and do *absolutely
nothing* — no error, no warning. Cards are resolved by name on import so that
can't happen.

---

## Getting it

Download `goat-simulador.html` and `deckbuilder.html` and open them by
double-clicking. That's the whole installation. Works in any modern browser,
including phones (landscape).

Both files are generated artifacts — the sources and the build live in `engine/`.

## Languages

English and Spanish, switchable in Options.

## Usage stats

The hosted page can count visits and a handful of gameplay events (how many runs
are started, how far they get, which decks are played, which errors happen) using
[GoatCounter](https://www.goatcounter.com) — no cookies, no personal data, no
consent banner needed. It ships **off**: without a site code configured nothing is
sent, and a copy opened from your own disk never sends anything at all, even if
one is. It can be turned off in Options, and `Do Not Track` is honoured.
See [docs/ANALITICA.md](docs/ANALITICA.md).

## License

The rules engine (**ocgcore**) and the card scripts come from
[Project Ignis](https://github.com/ProjectIgnis) and are **AGPL-3.0**, so this
project is too. Card artwork and card text are Konami's; the artwork is fetched
from ygoprodeck and is not redistributed here.
