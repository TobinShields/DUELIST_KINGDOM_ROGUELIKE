#!/usr/bin/env bash
# Reconstruye el simulador y el deck builder desde cero.
# Requiere: node. Se ejecuta desde la carpeta engine/.
set -e
W="$(cd "$(dirname "$0")" && pwd)"
echo "── datos ──"
[ -f "$W/data/full_cards.json" ] || python3 "$W/data/export_cards.py"
echo "── scripts Lua de todo el pool ──"
cd "$W/browser" && node build-scripts.mjs "$W/data/goat-pool.json"
echo "── simulador ──"
node build-html.mjs
echo "── deck builder ──"
cd "$W/deckbuilder" && node build.mjs
echo "── verificación ──"
cd "$W/browser"
node check-dom.mjs | tail -2
node check-activar.mjs | tail -1
node check-sync.mjs 2>&1 | tail -1
node check-ia-propias.mjs 2>&1 | tail -1
node check-tapadas.mjs 2>&1 | tail -1
node check-mudas.mjs 2>&1 | tail -1
node check-cartas.mjs 2>&1 | tail -1
node check-contadores.mjs 2>&1 | tail -1
node check-historia.mjs 2>&1 | tail -1
node check-mapa.mjs 500 2>&1 | tail -1
node check-recompensas.mjs 500 2>&1 | tail -1
node check-utilidad.mjs 2>&1 | tail -1
node check-rivales.mjs 2>&1 | tail -1
node check-run.mjs 100 2>&1 | tail -1
node check-jefes.mjs 2>&1 | tail -1
node check-reino.mjs 2>&1 | tail -1
node check-encadenados.mjs 2>&1 | tail -1
node check-p0.mjs 2>&1 | tail -1
node check-pestanas.mjs 2>&1 | tail -1
node check-maestria.mjs 2>&1 | tail -1
node check-barajatapadas.mjs 2>&1 | tail -1
# Va después del deck builder a propósito: lee los DOS html construidos.
node check-movil.mjs 2>&1 | tail -1
# El juego en inglés tiene que estar en inglés: `check-idioma` mira el
# mecanismo, esto recorre las pantallas y LEE lo que sale.
node check-ingles.mjs 2>&1 | tail -1
node check-sobres.mjs 2>&1 | tail -1
node check-zona.mjs 2>&1 | tail -1
node check-fusiones.mjs 2>&1 | tail -1
# Que ningún mazo inicial se quede sin cartas que le sirvan en los sobres.
(cd ../story-tools && node soporte.mjs 2>&1 | tail -2)
node jugar.mjs 2>&1 | tail -2
# Que «Ver el tablero» al acabar un duelo no deje al jugador encerrado.
node check-salida.mjs 2>&1 | tail -1
# Que el contador de uso no filtre nada ni pueda tirar una partida.
node check-telemetria.mjs 2>&1 | tail -1
# Y que la carpeta que se sube tenga lo que dice tener.
node check-publicar.mjs 2>&1 | tail -1
