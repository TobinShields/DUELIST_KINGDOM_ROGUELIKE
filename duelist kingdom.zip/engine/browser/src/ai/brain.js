/* ══════════════════════════════════════════════════════════════════
   CEREBRO DEL BOT — cuatro niveles sobre un mismo motor.

   Los principios están sacados del material competitivo de Goat
   (goatformat.com y el artículo de Pojo "40 Common Mistakes"):
     · La ventaja de cartas decide las partidas, no el ataque.
     · No gastes remoción en algo que puedes matar en combate.
     · Invoca ANTES de usar remoción, o regalas un Torrential Tribute.
     · Ataca primero con el monstruo fuerte para forzar el Scapegoat.
     · Guarda MST para Snatch Steal, Premature Burial o Call.
     · Sinister Serpent y Sangan valen más en la mano que colocados.
     · Thousand-Eyes Restrict sin objetivo bueno no compensa.
     · Scapegoat en tu turno te bloquea la invocación.
   ══════════════════════════════════════════════════════════════════ */
import { vistaDe } from "./view.js";
import { atk, def, poder, valorCarta, rolDe, infoDe, evaluar, ventaja,
         ganaCombate, muereAtacando, pegaMasFuerte, sobrevive,
         evaluarPosicion, valeAtaqueSuicida,
         costeDeQueMuera } from "./evaluar.js";
import { canon } from "./knowledge.js";
import { planDe } from "./plan.js";
import { utilidadLeida, leerCarta } from "./lectura.js";
import { valorar, delta, efectoDe, aplicar } from "./valorar.js";

/* Combinaciones de cartas cuyos valores suman lo que pide el motor: los
   tributos de una invocación ritual. Está duplicado a propósito con el de
   `main.js` porque los dos módulos viven en ámbitos separados dentro del
   HTML de un solo archivo; si algún día se toca uno, tocar los dos. */
export function combinacionesSuma(m){
  const lista = m.selects ?? [];
  const n = lista.length;
  if(!n || n > 16) return [];
  const valores = lista.map(e=>{
    const bajo = e.amount & 0xffff, alto = (e.amount >>> 16) & 0xffff;
    return alto ? [bajo, alto] : [bajo];
  });
  const fijo = (m.selects_must ?? []).reduce((s,e)=>s + (e.amount & 0xffff), 0);
  const objetivo = (m.amount ?? 0) - fijo;
  const exacto = !m.select_max;
  /* OJO: el motor manda min y max en 0 cuando no hay límite de cuántas
     cartas puedes coger; tomarlos al pie de la letra dejaba fuera todas
     las combinaciones y los rituales seguían sin poder pagarse. */
  const min = Math.max(1, m.min || 1), max = (m.max > 0 ? m.max : n);
  const sumasDe = idx => idx.reduce((acc,i)=>{
    const nuevo=[]; for(const s of acc) for(const v of valores[i]) nuevo.push(s+v);
    return [...new Set(nuevo)];
  }, [0]);
  const out=[];
  for(let mask=1; mask<(1<<n); mask++){
    const idx=[]; for(let i=0;i<n;i++) if(mask & (1<<i)) idx.push(i);
    if(idx.length<min || idx.length>max) continue;
    const sumas = sumasDe(idx);
    const vale = exacto ? sumas.includes(objetivo)
      : sumas.some(s=>s>=objetivo) &&
        idx.every(i=>!sumasDe(idx.filter(j=>j!==i)).some(s=>s>=objetivo));
    if(vale) out.push(idx);
  }
  return out.sort((a,b)=>a.length-b.length);
}

export const NIVELES = ["novato","normal","duro","experto"];
const RANGO = { novato:0, normal:1, duro:2, experto:3 };

export function crearCerebro({ X, duel, db, names, nivel="normal", yo=1, log, lastre:lastreExtra }){
  const R = X.OcgResponseType, T = X.OcgMessageType;
  const IA = X.SelectIdleCMDAction, BA = X.SelectBattleCMDAction;
  const n = RANGO[nivel] ?? 1;
  /* Ablación de reglas del nivel experto. Con GOAT_AI_OFF="clave,clave"
     se apagan una a una para medir cuánto aporta cada regla en el torneo:
     así se descubre qué la hacía perder contra "duro". En el navegador
     no existe la variable, así que están todas encendidas. */
  const APAGADAS = new Set(String(
    (typeof process!=="undefined" && process.env && process.env.GOAT_AI_OFF)
    || globalThis.GOAT_AI_OFF || "").split(",").map(x=>x.trim()).filter(Boolean));
  const exp = k => n>=3 && !APAGADAS.has(k);
  /* ── CEREBRO POR EVALUACIÓN ──
     Con GOAT_CEREBRO=evaluacion, cada jugada se puntúa por lo que MEJORA
     el tablero, en cartas (ver `valorar.js`), en vez de con la constante
     que le tocara. Convive con el criterio de siempre a propósito: el
     banco de posiciones dice cuál juega mejor, y hasta que lo diga el
     que manda es el de siempre. */
  const POR_EVALUACION = String(
    (typeof process!=="undefined" && process.env && process.env.GOAT_CEREBRO)
    || globalThis.GOAT_CEREBRO || "") === "evaluacion";

  /* ── LA ESCALERA DE DIFICULTAD ──
     Medido con 300 partidas por cruce, las cuatro "inteligencias" distintas
     daban el mismo bot: ninguna regla de nivel cambiaba la jugada elegida.
     Así que hay UN cerebro que juega lo mejor que sabe y los niveles de
     abajo se lastran con defectos concretos y medibles, como los bots de
     ajedrez. Cada lastre se puede apagar solo y se nota en el torneo.

       error         · probabilidad de elegir una jugada peor a propósito
       sinCadenas    · no responde nada en el turno rival
       cadenaTonta   · responde, pero con lo primero que pilla
       combateTonto  · ataca sin hacer cuentas
       objetivoTonto · elige a quién ataca al azar
       malaSeleccion · elige al azar qué descarta, busca o destruye
       sinRemocion   · no gasta remoción por iniciativa propia
       sinPosicion   · no cambia posiciones ni voltea
       sinGuardar    · gasta las cartas en cuanto puede, sin esperar momento

     Los números salen de medir cada defecto por separado con
     `medir-lastres.mjs`, no de suponerlos. */
  /* ── LO QUE SABE CADA NIVEL DE SU PROPIO MAZO ──
     Hasta ahora los niveles se separaban por defectos genéricos (no
     responde cadenas, ataca sin contar). Faltaba lo que E pidió: que el
     experto siga TODOS los pasos de la guía de su mazo y que los de abajo
     los vayan perdiendo de uno en uno. Son cuatro capacidades y se pierden
     en este orden, de la más avanzada a la más básica:

       pasos    seguir el guion del mazo: los muros antes que la cuenta
                atrás, Necrovalley antes de atacar, la Cannon cuanto antes
       postura  decidir para qué es el turno antes de tocar nada
       motor    reconocer el motor del mazo: voltear el mismo bicho cada
                turno, buscar las piezas, jugar los facilitadores pronto
       claves   saber siquiera con qué gana: no descartar la carta que
                gana la partida ni cambiarla por cualquier cosa

     experto  las cuatro · duro  sin `pasos` · normal  solo `claves`
     novato   ninguna: juega cartas sin saber para qué sirve el mazo. */
  const SABE = {
    experto: { pasos:true,  postura:true,  motor:true,  claves:true },
    duro:    { pasos:false, postura:true,  motor:true,  claves:true },
    normal:  { pasos:false, postura:false, motor:false, claves:true },
    novato:  { pasos:false, postura:false, motor:false, claves:false },
  };

  const LASTRE = {
    /* Medido con `medir-lastres.mjs`, 250 partidas por perfil, contra el
       cerebro limpio: novato pierde el 84%, normal el 66% y duro el 60%.
       Los números salen de ahí, no de la intuición. */
    novato:  { error:0.50, sinCadenas:true,  cadenaTonta:false, combateTonto:true,
               objetivoTonto:true, malaSeleccion:true, sinRemocion:true,
               sinPosicion:true,  sinGuardar:true },
    normal:  { error:0.35, sinCadenas:true,  cadenaTonta:false, combateTonto:true,
               objetivoTonto:true, malaSeleccion:true, sinRemocion:true,
               sinPosicion:false, sinGuardar:false },
    duro:    { error:0.20, sinCadenas:false, cadenaTonta:true,  combateTonto:false,
               objetivoTonto:true, malaSeleccion:false, sinRemocion:false,
               sinPosicion:false, sinGuardar:true },
    experto: { error:0,    sinCadenas:false, cadenaTonta:false, combateTonto:false,
               objetivoTonto:false, malaSeleccion:false, sinRemocion:false,
               sinPosicion:false, sinGuardar:false },
  };

  // `lastre` se puede forzar desde fuera para medir cuánto vale cada
  // defecto por separado (ver medir-lastres.mjs).
  const lastre = { ...(LASTRE[nivel] ?? LASTRE.normal), ...(lastreExtra ?? {}) };
  const traza = (msg,extra)=> log?.({ nivel, msg, ...extra });
  const azar = p => Math.random() < p;

  /* CON QUÉ GANA ESTE MAZO. Se decide una vez, al empezar, mirando la
     decklist: ver `ai/plan.js`. Antes las 20 barajas se jugaban igual y
     por eso un mazo de Burn cambiaba golpes como uno de Zoo. */
  const PLAN_REAL = planDe(duel.decklist?.[yo] ?? [], names);
  /* Un nivel que no "sabe" algo se queda con un plan recortado, no con un
     plan que sabe y no usa: así el defecto es de conocimiento, no de
     fuerza de voluntad, y se puede medir apagándolo. */
  const sabe = SABE[nivel] ?? SABE.normal;
  const PLAN = sabe.claves ? {
    ...PLAN_REAL,
    volteos: sabe.motor && PLAN_REAL.volteos,
    esMotor: n => sabe.motor && PLAN_REAL.esMotor(n),
    pasos:   sabe.pasos ? PLAN_REAL.pasos : [],
  } : {
    nombre: PLAN_REAL.nombre, condicion:"(no sabe con qué gana su mazo)",
    objetivo:"beatdown", agresivo:0.8, aguanta:false, volteos:false, pasos:[],
    peso:()=>0, esClave:()=>false, esMotor:()=>false, sostiene:()=>false,
  };
  traza(`plan: ${PLAN.nombre} — ${PLAN.condicion}`);
  /* El guion, en el log. Es donde se lee si el bot lo está siguiendo. */
  if(PLAN.pasos.length) PLAN.pasos.forEach((paso,i)=>traza(`  paso ${i+1}: ${paso}`));

  const nombreDe = c => names[c.code]?.name ?? "";
  let ultimoAtacante = null;   // para elegir bien el objetivo del ataque
  const giros = new Map();     // uid → veces que le hemos cambiado la posición
  /* Una entrada de una lista de selección, con los ATK/DEF del TABLERO si
     la carta está en campo. Se usa `duel.at` y no `duel.resolve` a
     propósito: resolve incrementa el contador de desincronizaciones cuando
     no encuentra el código, y las tapadas del rival viven en nuestro espejo
     sin código —consultarlas ensuciaría la métrica con ruido. */
  const cartaDeLista = l => {
    const enCampo = l.location===4 || l.location===8;
    // tapada del rival: los ATK/DEF reales no son míos para saberlos
    const oculta = !!(l.position & 0x0a) && l.controller !== yo;
    const real = (enCampo && !oculta) ? duel.at(l.controller, l.location, l.sequence) : null;
    return { code:l.code, nombre:names[l.code]?.name ?? "",
             datos:db.get(l.code) ?? null,
             atkReal: real?.atkReal ?? null, defReal: real?.defReal ?? null,
             defensa:false, bocaAbajo:false };
  };

  /* ── ¿tengo con qué? consultas sobre la vista legal ── */
  const tieneEnMano = (v,nom) => v.mano.some(c=>canon(c.nombre)===nom);
  const enCementerio = (v,nom) => v.cementerio.some(c=>canon(c.nombre)===nom);
  const rivalUso = (v,nom) => v.cementerioRival.some(c=>canon(c.nombre)===nom)
                            || v.desterradasRival.some(c=>canon(c.nombre)===nom);
  /* La "amenaza" era solo lo que estaba boca arriba, y con un campo lleno
     de cartas tapadas el bot creía que no pasaba nada: no gastaba remoción,
     no atacaba —porque no sabía si ganaba— y el duelo se atascaba hasta el
     turno 60. Un monstruo tapado también estorba: si no hay nada a cara
     descubierta, cuenta como amenaza. */
  const amenazaMayor = v => {
    const caraArriba = v.monstruosRival.filter(c=>!c.bocaAbajo);
    /* PRIMERO LOS CANDADOS. Es el concepto que WindBot llama "floodgate" y
       que a esta IA le faltaba: mientras el rival tenga puesto un Jinzo, un
       Royal Decree, un Level Limit o un Thousand-Eyes Restrict, tu mazo no
       hace nada. Eso se quita antes que el monstruo de 1900. */
    const candados = caraArriba.filter(c=>infoDe(c).prioritario)
                               .sort((a,b)=>valorCarta(b)-valorCarta(a));
    if(exp("candados") && candados.length) return candados[0];
    /* AMENAZA es lo que PEGA, no lo que aguanta. Ordenando por "poder", un
       Gravekeeper's Spy de 2000 en defensa salía el primero — que es
       exactamente para lo que el rival lo pone: para que gastes ahí la
       remoción y te quedes sin nada cuando salga su 1900. Los muros se
       rodean, no se destruyen. */
    const pegan = caraArriba.filter(c=>!c.defensa).sort((a,b)=>atk(b)-atk(a));
    if(pegan.length) return pegan[0];
    const utiles = caraArriba.filter(c=>valorCarta(c) >= 1.3)
                             .sort((a,b)=>valorCarta(b)-valorCarta(a));
    if(utiles.length) return utiles[0];
    if(caraArriba.length) return caraArriba.sort((a,b)=>poder(b)-poder(a))[0];
    return v.monstruosRival[0] ?? null;
  };

  /* ── ¿ESTO CONSIGUE ALGO? ──
     La queja de E, palabra por palabra: "juega cartas por jugar". El
     ejemplo que lo resume: Snatch Steal sobre una ficha de Scapegoat. La
     ficha tiene 0 de ataque; robarla no cambia nada y quema la mejor carta
     del mazo. Lo mismo con Thunder Dragon descartado para buscar copias que
     ya no quedan, o con remoción sobre un muro.
     De aquí para abajo, ninguna carta se activa si no consigue algo. */
  /* ¿Es una ficha? Esto era solo `valorCarta(c) <= 0.2`, o sea que
     dependía de que la carta estuviera en la tabla escrita a mano. Las
     fichas que no lo están —y las hay: Sheep Token tiene su propio
     passcode, pero también salen fichas de otras cartas— pasaban por
     monstruo normal, y de ahí las dos jugadas que seguía contando el
     escáner: Snatch Steal sobre una ficha de Scapegoat y Smashing Ground
     gastado en lo mismo. Se mira además el BIT DE FICHA de la base y el
     caso "monstruo normal de 0/0", que es lo que son todas. */
  const esFicha = c => valorCarta(c) <= 0.2
    || !!((c?.datos?.type ?? 0) & 0x4000)
    || (!!((c?.datos?.type ?? 0) & 0x1) && atk(c) === 0 && def(c) === 0);
  const esMuro  = c => !c.bocaAbajo && c.defensa && def(c) >= 1700 && atk(c) <= 1200;
  // a quién merece la pena robarle o absorberle: ni fichas ni tapadas
  const objetivoDeRobo = v => v.monstruosRival
      .filter(c => !c.bocaAbajo && !esFicha(c))
      .sort((a,b) => poder(b) - poder(a))[0] ?? null;
  /* Cuántas copias me quedan de una carta EN EL MAZO. Un jugador se sabe su
     propia lista; el bot no podía porque el espejo del deck es ficticio.
     `v.mazo` lo calcula restándole a la decklist todo lo ya visto. */
  const quedanEnMazo = (v, nom) => {
    let n = 0;
    for(const [code, cuantas] of (v.mazo ?? []))
      if(canon(names[code]?.name ?? "") === nom) n += cuantas;
    return n;
  };

  /* ══════════════════════════════════════════════════════════════════
     LA POSTURA DEL TURNO — para qué es este turno.

     Esto es lo que E echaba en falta: "la IA no sigue una win condition,
     solo juega cartas y responde a jugadas, sin un plan de acción claro".
     Y tenía razón en el diagnóstico: cada carta se puntuaba por su cuenta
     y la mejor nota ganaba. Un humano no juega así. Antes de tocar nada
     decide para qué es el turno —remato, presiono, aguanto, construyo o
     busco— y a partir de ahí todas las cartas se leen distinto: el mismo
     Smashing Ground vale mucho cuando estás estabilizando y poco cuando
     lo que necesitas es cavar para encontrar tu pieza.

     Es lo que hacen las IAs de los juegos de consola (World Championship,
     Tag Force): no buscan en árbol —no pueden—, tienen un modo y una
     lista de prioridades por modo.

     La postura se decide una vez por Main Phase y se apunta en el log,
     que es donde E lee lo que ha hecho el bot. */
  const POSTURAS = {
    rematar:    "voy a por los puntos de vida: todo lo que haga daño",
    estabilizar:"voy por detrás: quitar de en medio y aguantar el turno",
    presionar:  "voy por delante: campo y daño sin regalar cartas",
    construir:  "igualados: ganar cartas y montar la jugada",
    buscar:     "no tengo mis piezas: cavar y guardar lo reactivo",
  };
  let posturaActual = null, posturaTurno = -1;
  function postura(v){
    if(!sabe.postura) return "construir";
    if(posturaTurno === v.turno && posturaActual) return posturaActual;
    const mio  = v.monstruos.filter(c=>!c.bocaAbajo && !c.defensa)
                            .reduce((s,c)=>s+atk(c),0);
    const suyo = pegaMasFuerte(v, { conMano:false });
    const dif  = ventaja(v);
    const campoSuyo = v.monstruosRival.length, campoMio = v.monstruos.length;
    /* ¿tengo en la mano o en el campo algo con lo que gane este mazo? */
    const conPiezas = [...v.mano, ...v.monstruos, ...v.backrow]
      .some(c=>c.nombre && (PLAN.esClave(c.nombre) || PLAN.esMotor(c.nombre)));

    let p;
    if(campoSuyo===0 && mio >= v.lp.rival)                  p = "rematar";
    else if(v.lp.mio <= 2200 || campoSuyo - campoMio >= 2
            || (suyo > 0 && mio === 0 && campoSuyo > 0))    p = "estabilizar";
    else if(dif >= 1 && mio > suyo)                         p = "presionar";
    else if(!conPiezas && v.mano.length >= 2)               p = "buscar";
    else                                                    p = "construir";

    if(p !== posturaActual) traza(`postura: ${p} — ${POSTURAS[p]}`);
    posturaActual = p; posturaTurno = v.turno;
    return p;
  }

  /* Cuánta prisa tengo. Un jugador bueno guarda cartas, pero no las
     entierra: si va por detrás o la partida se alarga, las juega. */
  function apuro(v){
    let a = 0;
    if(v.turno >= 8)  a += 0.4;
    if(v.turno >= 14) a += 0.5;
    if(ventaja(v) < 0) a += 0.5;
    if(v.lp.mio < v.lp.rival - 2000) a += 0.5;
    if(v.lp.mio <= 2500) a += 0.4;
    if(v.mano.length >= 5) a += 0.3;          // mano llena: hay que gastar
    return Math.min(a, 1.6);
  }

  /* ══════════ MAIN PHASE ══════════ */
  function mainPhase(m, intento){
    const v = vistaDe(duel, yo, db, names);
    const prisa = apuro(v);

    // ─ Novato: hace lo primero que puede, sin criterio ─
    if(n===0){
      const todo=[];
      (m.summons||[]).forEach((c,i)=>todo.push({a:IA.SELECT_SUMMON,i}));
      (m.activates||[]).forEach((c,i)=>todo.push({a:IA.SELECT_ACTIVATE,i}));
      (m.spell_sets||[]).forEach((c,i)=>todo.push({a:IA.SELECT_SPELL_SET,i}));
      (m.monster_sets||[]).forEach((c,i)=>todo.push({a:IA.SELECT_MONSTER_SET,i}));
      if(todo.length && intento<todo.length){
        const e=todo[(intento + (azar(.5)?1:0)) % todo.length];
        return { type:R.SELECT_IDLECMD, action:e.a, index:e.i };
      }
      return { type:R.SELECT_IDLECMD, action: m.to_bp?IA.TO_BP:IA.TO_EP, index:null };
    }

    const plan = [];   // {puntos, action, index, por, uid}
    const añadir = (puntos, action, index, por, uid) => plan.push({puntos, action, index, por, uid});

    /* ── EL ORDEN ES LA JUGADA ──
       En Goat la habilidad no está solo en qué cartas juegas sino en el
       orden, y por una razón concreta: Torrential Tribute.
         · La remoción de BACKROW (Heavy Storm, MST) va ANTES de invocar:
           destruye el Torrential que iba a castigar la invocación.
         · La remoción de MONSTRUOS va DESPUÉS de invocar: si limpias
           primero y luego invocas, el Torrential se lleva tu monstruo y
           el campo del rival ya está vacío; si invocas primero, cuando
           cae el Torrential se lleva también lo suyo.
       Es el consejo repetido en todas las guías del formato y el bot lo
       tenía escrito en el comentario de arriba pero no en el código. */
    const puedoInvocar = (m.summons||[]).length > 0;

    /* REMATAR. Un bot decente reconoce cuándo la partida se acaba este
       turno. Si lo único que se interpone entre mi campo y sus puntos de
       vida es un monstruo, quitarlo de en medio no vale "una carta": vale
       el duelo. Sin esto la IA guardaba el Smashing Ground para más
       adelante con el rival a 1.200 puntos.

       TRAMPA MEDIDA: la primera versión no miraba la fase. SELECT_IDLECMD
       también llega en Main Phase 2, cuando los monstruos YA han atacado:
       el bot se gastaba la remoción para un "letal" que no existía. Solo
       cuenta en Main Phase 1 y con batalla por delante.

       Honestidad sobre la medida: con 4.000 partidas contra la versión
       anterior, esta regla sale 61% con ella y 62% sin ella. O sea, NO
       mejora el marcador; se queda porque la jugada que evita —guardar la
       remoción con el rival a 1.200 puntos— es de las que hacen que un
       humano diga "esta IA hace cosas raras". Se puede apagar con
       GOAT_AI_OFF=remate. */
    const miAtaque = v.monstruos.filter(c2=>!c2.bocaAbajo && !c2.defensa)
                                .reduce((s,c2)=>s+atk(c2), 0);
    const remate = v.turnoMio && v.fase===0x4 && !!m.to_bp
                   && v.monstruosRival.length<=1
                   && miAtaque >= v.lp.rival && miAtaque > 0;

    /* 1. INVOCAR. En Goat el monstruo entra antes que la remoción:
          si limpias primero y luego invocas, regalas Torrential. */
    const techoRival = Math.max(0, ...v.monstruosRival.filter(c=>!c.bocaAbajo).map(c=>atk(c)));
    (m.summons||[]).forEach((l,i)=>{
      const c = cartaDeLista(l), inf = infoDe(c);
      let p = 3 + atk(c)/1000, por = `invocar ${c.nombre}`;
      /* ¿SOBREVIVE A SU TURNO? Palabras de E: "la IA a veces invoca en
         ataque por invocar, sin darse cuenta de que yo tengo un monstruo
         con más ataque y que le haré daño al siguiente turno". El bot
         puntuaba lo que conseguía AHORA y no miraba el tablero que dejaba.
         Un monstruo invocado de frente que el rival se come no es solo una
         carta perdida: son los puntos de vida de la diferencia. Y si esa
         misma carta se puede COLOCAR, invocarla es directamente un error,
         no una preferencia: por eso el castigo es mucho mayor cuando hay
         alternativa. */
      const puedeColocarse = (m.monster_sets||[]).some(s=>
        s.code===l.code && s.sequence===l.sequence);
      /* PERO ojo con a quién se le aplica esto. Un monstruo que hace algo
         nada más entrar —Breaker rompe una tapada, Exiled Force se
         sacrifica, Chaos Sorcerer destierra, Airknight roba al golpear— se
         invoca aunque luego se lo coman: ya ha pagado su carta. Castigar
         también a esos costaba dos puntos de victoria medidos, porque el
         bot se quedaba colocando cuerpos y sin hacer nada. La regla es
         para los monstruos que son SOLO un cuerpo. */
      const haceAlgoAlEntrar = inf.rompeBackrow || inf.efectoAlInvocar || inf.invoca
        || inf.atacaTodos || inf.perfora || inf.robaAlGolpear
        || ["removal","buscador","flip","fusion"].includes(inf.rol);
      /* Y tampoco cuenta si el monstruo va a hacer daño ESTE turno. Cambiar
         un 1700 por un ataque directo o por matarle algo es una jugada,
         no un descuido: lo que E reportó es invocar en ataque cuando eso
         no consigue nada y encima le regala daño al rival. */
      const puedePegarYa = !!m.to_bp && (
        v.monstruosRival.length === 0 ||
        v.monstruosRival.some(r=>!r.bocaAbajo && atk(c) > poder(r)));
      const coste = (exp("sobrevivir") && !haceAlgoAlEntrar && !puedePegarYa)
        ? costeDeQueMuera(c, v) : 0;
      /* `noColocar` quiere decir "no la COLOQUES boca abajo" —Sangan muere a
         Nobleman, Sinister Serpent vale más en la mano—, no "invócala sin
         mirar". Estaba saltándose el filtro de supervivencia entero, así
         que el bot invocaba un Sinister Serpent de 300 delante de un 1900.
         Lo cazó el banco de posiciones. */
      /* Y cuánto pesa depende del PLAN. Un mazo de Beastdown acepta el
         cambio y sigue pegando: colocarle los monstruos lo deja sin
         partida (medido: 40% cuando se le aplicaba el freno entero). Uno
         de Burn no se puede permitir perder un cuerpo. `agresivo` estaba
         en la tabla de planes desde el principio y no se usaba para
         nada; aquí es donde tiene sentido. */
      const prudencia = 1 - (PLAN.agresivo ?? 0.5);
      if(coste > 0 && prudencia > 0.1){
        /* El castigo tiene que ser el justo para que gane COLOCAR cuando
           colocar es la jugada, y ni un punto más. Con el doble, el bot se
           volvía miedoso: colocaba cuerpos toda la partida, los duelos se
           alargaban tres turnos y medía dos puntos de victoria peor. */
        p -= (puedeColocarse ? (1.2 + coste*0.6) : (0.5 + coste*0.5)) * (prudencia*2);
        por += ` (lo mata algo de ${pegaMasFuerte(v, { conMano:false })})`;
      }
      /* ══ SISTEMA B · HAY CARTAS QUE QUIEREN ENTRAR BOCA ABAJO ══
         Man-Eater Bug invocada de frente es un cuerpo de 450 que no hace
         nada; colocada, se lleva un monstruo en cuanto la tocan. Black
         Dragon's Chick, igual: 800 puntos de cuerpo cuyo valor es el
         combo. E vio las dos invocadas de frente sin razón.
         La excepción es concreta y se comprueba: si con ella remato o si
         tengo un ataque de verdad, invocar es lo correcto. */
      if(inf.prefiereSet && puedeColocarse && !puedePegarYa){
        p -= 2.6; por += " (su valor está en entrar boca abajo)";
      }
      if(inf.rol==="beater" || inf.rol==="bomba") p += 1.2;
      /* Sangan quiere atacar (es un floater: muera como muera, busca).
         Sinister Serpent no: vuelve sola cada Standby y su sitio es la
         mano, protegiendo del Delinquent Duo y alimentando descartes. */
      if(inf.noColocar && inf.rol!=="recurso") p += 0.4;
      if(inf.rol==="recurso" && !puedePegarYa){
        p -= 2.5; por += " (vale más en la mano)";
      }
      /* ESPÍRITUS. Asura Priest y Tsukuyomi vuelven a tu mano en la End
         Phase: si no pueden atacar este mismo turno, la invocación se ha
         ido a la basura. Reportado en Reddit: el bot invocaba Asura Priest
         en el turno 1, donde ni siquiera hay Battle Phase. */
      if(exp("espiritus") && inf.espiritu && !inf.efectoAlInvocar){
        const hayGolpe = v.monstruosRival.length===0 ||
           v.monstruosRival.some(r=>!r.bocaAbajo && atk(c) > poder(r));
        if(!m.to_bp){
          // turno 1: no hay Battle Phase, o sea que no hace absolutamente nada
          p -= 5.0; por += " (espíritu sin Battle Phase: se va a la mano sin tocar nada)";
        } else if(!hayGolpe){
          p -= 2.5; por += " (espíritu sin nada a lo que pegar)";
        } else if(inf.atacaTodos && v.monstruosRival.length>=2) p += 1.0;
      }
      // no duplicar ATK: Snatch Steal mata dos pájaros de un tiro
      if(exp("atkDuplicado") && v.monstruos.some(x=>!x.bocaAbajo && atk(x)===atk(c))) p -= 1.5;
      /* No sobreextender contra el Torrential Tribute. Una vez lo has
         visto salir ya no hay nada que temer, así que el freno se levanta:
         antes seguía frenando toda la partida y el bot se quedaba corto de
         campo sin motivo. Las fichas de Scapegoat no cuentan como campo:
         un Torrential que se lleva tres fichas es un regalo. */
      const campoReal = v.monstruos.filter(x=>valorCarta(x) > 0.2).length;
      const trampaMasaFuera = rivalUso(v,"Torrential Tribute") || rivalUso(v,"Mirror Force");
      /* Cuanto MÁS campo tengas, peor es añadir otro: un Torrential con
         tres monstruos tuyos fuera es una catástrofe, con uno es un
         cambio. El castigo era fijo (-1.4) y contra un cuerpo de 2000 no
         llegaba ni de lejos; ahora crece con lo que te juegas. */
      if(n>=2 && campoReal>=2 && v.tapadasRival>0 && ventaja(v)>=0 && !trampaMasaFuera){
        const enJuego = v.monstruos.reduce((s,x)=>s+valorCarta(x)+poder(x)/1600, 0);
        p -= 1.0 + enJuego;
        por += " (no sobreextender: tiene tapadas y no ha enseñado el Torrential)";
      }
      /* ══════════════════════════════════════════════════════════════
         SISTEMA E · UN TRIBUTO TIENE QUE SALIR A CUENTA

         Dos casos de E. En uno el bot revivió su Dark Magician y acto
         seguido lo tributó por un monstruo claramente peor. En otro
         tributó un Goblin Attack Force que TODAVÍA PODÍA ATACAR ese
         turno —y que después del ataque pasa a defensa con 0, o sea que
         su valor se evapora—.

         Antes esto no se miraba en absoluto: la nota de invocar era
         `3 + atk/1000` mirase lo que mirase el coste. Ahora se compara
         lo que sale con lo que entra, y se prefiere ATACAR PRIMERO y
         tributar en la Main Phase 2.
         ══════════════════════════════════════════════════════════════ */
      const nivel = c.datos?.level ?? 0;
      const pideTributo = nivel >= 5 && !inf.invocaGratis;
      if(pideTributo && v.monstruos.length){
        /* Los candidatos: los míos, de menos a más valiosos, que es como
           los elegiría cualquiera. Cuántos hacen falta lo dice el nivel. */
        const cuantos = nivel >= 7 ? 2 : 1;
        const candidatos = [...v.monstruos]
          .sort((a,b)=> (valorCarta(a)+poder(a)/2000) - (valorCarta(b)+poder(b)/2000))
          .slice(0, cuantos);
        const costeTributo = candidatos.reduce((t,x)=>
          t + valorCarta(x) + poder(x)/2200, 0);
        const gano = valorCarta(c) + atk(c)/2200;
        /* Y el coste que no se ve en las estadísticas: una invocación por
           tributo GASTA UNA CARTA. Dos cuerpos de 2500 por uno de 2500 no
           es "lo mismo", es perder una carta por nada. Por eso el que
           entra tiene que ser MEJOR por un margen, no solo igual: es
           exactamente lo que pasó con el Dark Magician del log. */
        const costeEnCartas = 0.8 * candidatos.length;
        if(costeTributo + costeEnCartas > gano){
          p -= 1.0 + (costeTributo + costeEnCartas - gano) * 1.6;
          por += ` (tributar ${candidatos.map(x=>x.nombre).join(" y ")} no compensa por ${c.nombre})`;
        }
        /* Y lo del Goblin: si alguno de los que voy a tributar puede
           atacar con provecho AHORA, primero se ataca. La invocación
           sigue estando disponible en la Main Phase 2. */
        if(m.to_bp){
          const conAtaqueUtil = candidatos.filter(x => !x.bocaAbajo && !x.defensa
            && !x.yaAtaco && (
              v.monstruosRival.length === 0 ||
              v.monstruosRival.some(r=>!r.bocaAbajo && atk(x) > poder(r))));
          if(conAtaqueUtil.length){
            /* Esto no es una preferencia, es un ORDEN: la invocación sigue
               ahí en la Main Phase 2 y el ataque no vuelve. Con un simple
               −2.2 el Goblin de 2300 seguía ganando la comparación y se
               tributaba antes de pegar, que es justo lo que E reportó. */
            p = Math.min(p, 0.4);
            por = `invocar ${c.nombre} (primero ataco con ${conAtaqueUtil[0].nombre}` +
                  `, la invocación sigue en la Main 2)`;
          }
        }
      }
      añadir(p, IA.SELECT_SUMMON, i, por);
    });

    (m.special_summons||[]).forEach((l,i)=>{
      const c = cartaDeLista(l);
      añadir(4.5 + atk(c)/1000, IA.SELECT_SPECIAL_SUMMON, i, `inv. especial ${c.nombre}`);
    });

    /* 2. COLOCAR MONSTRUO boca abajo */
    (m.monster_sets||[]).forEach((l,i)=>{
      const c = cartaDeLista(l), inf = infoDe(c);
      let p = 1.6, por = `colocar ${c.nombre}`;
      if(inf.colocarPreferente) p += 1.6;               // los flip quieren ser colocados
      if(inf.prefiereSet) p += 1.4;                     // y estas todavía más
      /* `noColocar` era un -3.0 que los demás bonus se comían: colocar un
         Sinister Serpent sumaba +0.5 por ser pequeño, +0.6 por campo
         vacío y +1.4 por haber algo más grande enfrente, y acababa en 1.1
         —por encima del umbral—. Para las cartas cuyo valor ES estar en la
         mano no hay matiz: no se colocan. */
      if(inf.noColocar) p -= 3.0;                       // Sangan muere a Nobleman
      if(atk(c) < 1400) p += 0.5;
      if(v.monstruos.length===0) p += 0.6;
      // el que gana alargando pone muros, no atacantes
      if(exp("planColocar") && PLAN.aguanta) p += 1.2 + (def(c) >= 1700 ? 0.8 : 0);
      // si enfrente hay algo más grande, colocarla es lo correcto
      if(techoRival && atk(c) <= techoRival) p += 1.4;
      /* AL FINAL, y pisando todo lo anterior: para las cartas cuyo valor
         ES estar en la mano no hay matiz que valga. Puesto arriba como un
         `p = 0.05`, los bonus de después lo levantaban otra vez hasta 2.55
         —pequeña, campo vacío, algo grande enfrente— y el bot colocaba su
         Sinister Serpent igual. Lo cazó el banco de posiciones. */
      if(inf.rol==="recurso"){ p = 0.05; por += " (vale más en la mano)"; }
      añadir(p, IA.SELECT_MONSTER_SET, i, por);
    });

    /* 3. ACTIVAR MAGIA/TRAMPA: aquí vive casi todo el criterio */
    (m.activates||[]).forEach((l,i)=>{
      const c = cartaDeLista(l), inf = infoDe(c), nom = canon(c.nombre);
      let p = 1.0, por = `activar ${c.nombre}`;
      /* `vetado` = "esta carta no consigue NADA aquí", que es distinto de
         "vale poco": una carta vetada no puede resucitar porque la postura
         del turno le sume puntos. Sin esta distinción, el +1.2 a la
         remoción de cuando vas por detrás resucitaba justo las jugadas que
         acabábamos de prohibir: gastar el Smashing Ground en un muro. */
      let vetado = false;

      /* LO QUE INVOCA YA ESTÁ EN EL CAMPO. Reportado en Reddit: el bot
         reanimó Hand of Nephthys teniendo ya el Sacred Phoenix fuera y
         tributó dos monstruos suyos para no conseguir nada. Vale para
         cualquier carta con `invoca`: si eso ya está puesto, o si no queda
         ninguna copia en el mazo, el efecto no hace nada. */
      if(n>=1 && inf.invoca){
        const yaEstá = v.monstruos.some(x=>canon(x.nombre)===inf.invoca);
        const quedan = quedanEnMazo(v, inf.invoca)
                     + v.extra.filter(x=>canon(x.nombre)===inf.invoca).length;
        if(yaEstá || !quedan){
          añadir(0.02, IA.SELECT_ACTIVATE, i,
                 `${por} (${yaEstá ? inf.invoca+" ya está en el campo"
                                   : "no queda ningún "+inf.invoca})`);
          return;
        }
      }

      /* ══ SISTEMA C, EN LA MAIN PHASE ══
         Una trampa colocada se puede activar en tu propio turno, y el bot
         lo hacía: en el log de E, «activar Waboku» en su Main Phase 1 con
         puntos 2.2. Waboku anula daño de batalla; en tu turno no hay
         ningún ataque que anular, así que la carta se tira a la basura.
         Estas dos familias SOLO valen en el turno del rival y por eso su
         sitio es la cadena, no la Main Phase. */
      if(inf.rol==="proteccionBatalla" || inf.rol==="quemaPorMonstruos"){
        añadir(0.02, IA.SELECT_ACTIVATE, i,
               `${por} (es reactiva: se guarda para el turno del rival)`);
        return;
      }

      switch(inf.rol){
        case "draw":
          p = 5.0;
          if(exp("graceful") && nom==="Graceful Charity"){
            // solo +1 de verdad si hay descarte gratis
            const gratis = tieneEnMano(v,"Sinister Serpent") ||
                           v.mano.some(x=>rolDe(x)==="chatarra");
            p = gratis ? 5.5 : 0.4 + prisa*2.6;
            por += gratis ? " (hay descarte gratis)"
                          : (prisa>0.7 ? " (sin descarte ideal, pero hay prisa)"
                                       : " (sin descarte bueno: mejor esperar)");
          }
          break;
        case "handRip":
          p = 4.0;
          if(exp("handRip")){
            // Delinquent Duo se neutraliza con Sinister Serpent
            const serpienteFuera = rivalUso(v,"Sinister Serpent");
            const manoGrande = v.manoRival.cuantas >= 4;
            p = serpienteFuera ? 4.6 : (manoGrande && v.turno<=2 ? 3.4 : 2.2 + prisa*1.5);
          }
          break;
        case "removal": {
          const objetivo = amenazaMayor(v);
          if(!objetivo){ p = 0.2; vetado = true; por += " (sin objetivo)"; break; }
          /* Ni fichas ni muros. Volar una ficha de Scapegoat con un
             Smashing Ground es cambiar una carta por nada, y un muro de
             2000 de defensa está ahí justamente para comerse la remoción
             que necesitas contra su monstruo de verdad. */
          if(exp("remocionUtil") && esFicha(objetivo)){
            p = 0.05; vetado = true; por += " (es una ficha: no vale una carta)"; break; }
          if(exp("remocionUtil") && esMuro(objetivo) && !v.monstruosRival.some(c2=>!c2.bocaAbajo && !c2.defensa)){
            p = 0.3; vetado = true; por += " (es un muro: se rodea, no se destruye)"; break; }
          // no gastes remoción en algo que matas en combate
          const puedoEnCombate = n>=2 && v.monstruos.some(x=>!x.bocaAbajo && ganaCombate(x,objetivo));
          p = puedoEnCombate ? 0.6 : 3.2 + poder(objetivo)/1500;
          if(puedoEnCombate) por += " (lo mato en combate, no la gasto)";
          if(exp("ring") && nom==="Ring of Destruction"){
            // Ring: para lo gordo o para rematar puntos de vida
            /* Ring of Destruction hace el daño a LOS DOS jugadores. Con
               "remata = sus LP <= ataque del objetivo" a secas, el bot se
               mataba a sí mismo: E lo vio suicidarse con ella al final de
               una partida. Solo remata si le mata a él Y NO a mí. */
            const golpe = poder(objetivo);
            const remata = v.lp.rival <= golpe && v.lp.mio > golpe;
            const meMata = v.lp.mio <= golpe;
            const noLoMato = !v.monstruos.some(x=>!x.bocaAbajo && ganaCombate(x,objetivo));
            p = remata ? 9.0
              : meMata ? 0.02
              : poder(objetivo)>=1700 ? 3.8
              : noLoMato ? 2.4 + prisa*1.6
              : 1.0 + prisa;
            if(remata) por += " (remata la partida)";
            if(meMata){ vetado = true; por += " (ese daño me mata a mí también)"; }
            /* Y si de todas formas lo mato en combate, la nota de arriba ya
               decía 0.6 y esta rama la pisaba: el log ponía "lo mato en
               combate, no la gasto" y acto seguido la gastaba. */
            if(!remata && puedoEnCombate){ p = Math.min(p, 0.6); vetado = true; }
          }
          if(n>=2 && nom==="Nobleman of Crossout"){
            const hayTapado = v.monstruosRival.some(c2=>c2.bocaAbajo);
            p = hayTapado ? 4.2 : 0.1;
          }
          // si abre el camino a la victoria, no hay nada mejor que hacer
          if(exp("remate") && remate){ p = 9.5; por += " (le abre el camino: es letal)"; }
          break;
        }
        case "spellRemoval": {
          const objetivos = v.backrowRival.length;
          if(!objetivos){ p = 0.1; break; }
          if(exp("mst")){
            // MST se guarda para equipos y reanimaciones
            const hayJugoso = v.backrowRival.some(c2=>!c2.bocaAbajo &&
              ["equipSteal","revival"].includes(rolDe(c2)));
            p = hayJugoso ? 5.0 : 0.8 + prisa*2.0;
            por += hayJugoso ? " (sobre un equipo/reanimación)" : " (no la malgasto en tapadas)";
          } else p = 2.2;
          break;
        }
        case "massRemoval": {
          const suyas = v.backrowRival.length, mias = v.backrow.length;
          /* Heavy Storm destruye TODO el backrow, también el tuyo, y hay
             dos cartas cuyo destrozo es peor que perder una carta: Snatch
             Steal boca arriba (el monstruo robado se vuelve con su dueño)
             y una reanimación boca arriba (el monstruo que sostiene se
             muere con ella). Un jugador reportó exactamente esto: el bot
             se voló su propio Snatch Steal y le devolvió el monstruo.
             Con una de esas puesta, la tormenta se guarda. */
          /* Y tampoco puede volarse lo que SOSTIENE su propio plan: la
             Wave-Motion Cannon del mazo de Burn, el Necrovalley del de
             Gravekeeper, el Gravity Bind de PACMAN. Sin esa carta en el
             campo, ese mazo no tiene plan. */
          const sostiene = v.backrow.filter(c2=>!c2.bocaAbajo &&
              (["equipSteal","revival"].includes(rolDe(c2)) || PLAN.sostiene(c2.nombre)));
          if(n>=1 && sostiene.length){
            p = 0.05; vetado = true;
            por += ` (me devolvería lo que sostiene ${sostiene[0].nombre})`;
            break;
          }
          /* ══ UNA TORMENTA ES UN BALANCE, NO UNA CUENTA DE CARTAS ══
             Esto miraba CUÁNTAS cartas hay a cada lado y, con n<2, bastaba
             con que el rival tuviera una para puntuar 3.0. En el log de E,
             Pegasus activó Heavy Storm con tres mágicas suyas colocadas y
             se voló su propio backrow entero.

             Lo que hay que comparar es VALOR, no número:

                valor del backrow rival que se destruye
              − valor del backrow propio que se destruye
              + lo que la jugada habilita después

             Una tapada del rival vale su incógnita —puede ser Mirror
             Force— pero una tapada PROPIA vale lo que vale de verdad,
             porque sé cuál es. Y lo que ya está gastado —una Premature o
             una Call cuyo monstruo ya no está— casi no cuesta nada:
             volarlas es de las pocas razones buenas para la tormenta. */
          const valorDeMias = v.backrow.reduce((t, c2) => {
            const rol = rolDe(c2);
            /* Un equipo/reanimación cuyo monstruo ya no está en el campo
               es papel: destruirla no cuesta nada. */
            const gastada = ["equipSteal","revival"].includes(rol)
                            && !v.monstruos.some(m => m.equipadaPor === c2.uid);
            return t + (gastada ? 0.1 : Math.max(0.4, valorCarta(c2)));
          }, 0);
          /* Las del rival: si están boca abajo no sé cuáles son, así que
             valen la media de una trampa de Goat. Boca arriba, su valor. */
          const valorDeSuyas = v.backrowRival.reduce((t, c2) =>
            t + (c2.bocaAbajo ? 1.5 : Math.max(0.8, valorCarta(c2))), 0);
          const balance = valorDeSuyas - valorDeMias;
          /* Lo que habilita: si limpiando el camino puedo invocar y
             atacar, la tormenta vale más que la suma de las cartas. */
          const habilita = (puedoInvocar && suyas >= 2) ? 0.9 : 0;

          if(balance <= 0){
            /* Destruyo más valor mío que suyo: no se activa. Es el caso
               del log, y no hay prisa que lo justifique. */
            p = 0.05; vetado = true;
            por += ` (me destruye ${valorDeMias.toFixed(1)} de valor propio`
                 + ` contra ${valorDeSuyas.toFixed(1)} suyo)`;
            break;
          }
          p = 0.6 + balance * 1.1 + habilita;
          por += ` (balance +${balance.toFixed(1)}: ${valorDeSuyas.toFixed(1)} suyo`
               + ` contra ${valorDeMias.toFixed(1)} mío)`;
          /* Con el campo vacío y sin nada que rematar, sigue sin correr
             prisa: la tormenta es mejor guardada para cuando hay dos o
             más cartas suyas puestas. */
          if(exp("masiva") && suyas < 2) p = Math.min(p, 0.5 + prisa * 0.6);
          break;
        }
        case "stall": {
          // Scapegoat bloquea tu propia invocación: no en tu turno
          p = (n>=2) ? 0.05 : 1.5;
          por += " (mejor encadenarla en el turno rival)";
          break;
        }
        case "revival": {
          const mejor = v.cementerio.filter(c2=>c2.datos?.type & 0x1)
                                    .sort((a,b)=>atk(b)-atk(a))[0];
          if(!mejor){ p = 0.1; break; }
          /* Reanimar un monstruo de 300 de ataque no es una jugada, es
             gastar una carta y 800 puntos de vida. Antes cualquier cosa en
             el cementerio valía 3.4 de salida, por encima del umbral. */
          p = exp("revivirFlojo")
              ? (atk(mejor)>=1700 ? 4.2 : atk(mejor)>=1400 ? 2.6 : 0.5) + atk(mejor)/2500
              : 3.4 + atk(mejor)/1400;
          if(n>=2 && inf.costeLP && v.lp.mio < 2000) p -= 2.0;
          if(exp("revivir") && v.tapadasRival>=2) p -= 1.0;      // te la responden
          break;
        }
        case "equipSteal": {
          /* EL CASO QUE REPORTÓ E: Snatch Steal sobre una ficha de
             Scapegoat. La ficha tiene 0 de ataque; robarla no cambia el
             marcador, no gana la partida y quema la mejor carta del mazo.
             El motivo era tonto: `amenazaMayor` devolvía la ficha porque
             era lo único boca arriba, y el valor no se miraba.
             La regla del formato es la contraria: Snatch Steal se guarda
             para el Airknight o el Black Luster Soldier. */
          const objetivo = objetivoDeRobo(v);
          if(!objetivo){
            p = 0.05; vetado = true; por += " (solo fichas o tapadas: robar eso no gana nada)"; break; }
          const decide = poder(objetivo) >= 1700 || valorCarta(objetivo) >= 1.6;
          p = decide ? 6.0 + poder(objetivo)/1200 : 1.0 + prisa*1.4;
          por += decide ? ` (le quito ${objetivo.nombre})`
                        : ` (${objetivo.nombre} no vale la Snatch: la guardo)`;
          break;
        }
        case "buscador": {
          /* Thunder Dragon. E lo vio descartar para buscar dos copias y
             luego activar esas dos con el mazo ya sin ninguna: tirar dos
             cartas a la basura. Ahora se cuenta lo que queda de verdad. */
          const quedan = quedanEnMazo(v, nom), hacenFalta = inf.necesitaCopias ?? 1;
          p = quedan >= hacenFalta ? 4.2 : 0.02;
          if(quedan < hacenFalta) vetado = true;
          por += quedan >= hacenFalta ? ` (quedan ${quedan} en el mazo)`
                                      : " (no queda ninguna en el mazo: no busca nada)";
          break;
        }
        case "quema": {
          /* Wave-Motion Cannon suma 1000 por turno que aguante puesta.
             Ponerla cuanto antes es el plan; cobrarla pronto es tirarla. */
          const enCampo = l.location === 8;
          if(!enCampo){ p = 5.2; por += " (a contar cuanto antes)"; break; }
          const remata = v.lp.rival <= 3000;
          p = remata ? 6.5 : 0.15;
          por += remata ? " (con esto llega)" : " (que siga sumando)";
          break;
        }
        case "muroGlobal": {
          // Level Limit, Gravity Bind: la carta del que gana alargando
          p = exp("murosGlobales") ? (PLAN.aguanta ? 6.0 : (v.monstruosRival.length > v.monstruos.length ? 2.6 : 0.4)) : 1.2;
          break;
        }
        case "stallGlobal": {
          p = (v.monstruosRival.length > v.monstruos.length || v.lp.mio < v.lp.rival) ? 4.5 : 1.0;
          break;
        }
        case "reloj": p = 9.0; break;      // Final Countdown ES la partida
        case "fusion": {
          /* LA JUGADA DEL FORMATO: ficha de Scapegoat → Metamorphosis →
             Thousand-Eyes Restrict, que absorbe el mejor monstruo del
             rival y deja el campo cerrado. Antes esto se puntuaba mirando
             solo si había un monstruo gordo enfrente, sin comprobar que
             hubiera material barato: el bot llegaba a sacrificar un
             Airknight para hacer un TER, que es cambiar una carta buena
             por otra y perder tempo.
             Lo que hace buena la jugada son las tres cosas a la vez:
             material que no cuesta nada, algo que absorber, y el TER
             realmente en el extra. */
          const rivalGordo = v.monstruosRival.filter(c2=>!c2.bocaAbajo)
                              .sort((a,b)=>poder(b)-poder(a))[0] ?? null;
          const barato = v.monstruos.filter(c2=>valorCarta(c2) <= 0.6 || atk(c2)===0);
          const hayTER = v.extra.some(c2=>canon(c2.nombre)==="Thousand-Eyes Restrict");
          if(exp("fusion")){
            if(!barato.length){ p = 0.3; por += " (solo tengo material caro)"; }
            else if(rivalGordo && poder(rivalGordo)>=1500){
              p = 6.0; por += ` (ficha → TER y le quito ${rivalGordo.nombre})`;
            }
            else if(hayTER && v.monstruosRival.length){ p = 3.4; }
            else { p = 1.0 + prisa; por += " (sin objetivo que absorber)"; }
          } else p = barato.length ? 3.0 : 1.2;
          break;
        }
        case "swap": {
          /* Creature Swap con fichas en campo es robo puro: le das un
             cero y te llevas su monstruo. Sin ficha es un intercambio a
             ciegas que suele salir mal. */
          const ficha = v.monstruos.filter(c2=>valorCarta(c2) <= 0.2);
          const suyo  = v.monstruosRival.filter(c2=>!c2.bocaAbajo)
                          .sort((a,b)=>poder(b)-poder(a))[0] ?? null;
          if(!ficha.length || !suyo){ p = 0.2; por += " (sin ficha o sin nada que llevarme)"; }
          else p = 4.0 + poder(suyo)/1500;
          break;
        }
        case "trick": {
          /* Book of Moon y Enemy Controller son RÁPIDAS: su sitio es el
             turno del rival, cortando un ataque o apagando un efecto. En
             tu propio turno solo valen si desbloquean algo. Con el valor
             por defecto (1.2, por encima del umbral de 0.8) el bot las
             quemaba en cuanto no tenía nada mejor que hacer, y un jugador
             reportó verlo tumbar su propio Dekoichi recién invocado. */
          if(nom==="Book of Moon" || nom==="Enemy Controller"){
            // ¿hay un monstruo suyo que me frena y cuya DEFENSA sí supero?
            const desbloquea = v.monstruosRival.some(r=>!r.bocaAbajo &&
              v.monstruos.some(y=>!y.bocaAbajo && !y.defensa &&
                                  atk(y) <= atk(r) && atk(y) > def(r)));
            p = desbloquea ? 2.8 : 0.05;
            por += desbloquea ? " (lo tumbo y le paso por encima)"
                              : " (rápida: se guarda para el turno rival)";
          } else if(nom==="Tsukuyomi"){
            /* Tsukuyomi vuelve a tu mano cada End Phase, así que la
               tentación es usarla todos los turnos: el escáner la contaba
               3,6 veces por partida. Solo vale si tumba algo que de verdad
               estorba —que aguante a mi mejor monstruo o que sea una carta
               fuerte—, no por girar al primero que vea. */
            const mejorMio = Math.max(0, ...v.monstruos.filter(x=>!x.bocaAbajo).map(x=>atk(x)));
            const estorba = v.monstruosRival.some(c2=>!c2.bocaAbajo &&
                              (atk(c2) >= mejorMio || valorCarta(c2) >= 1.4));
            p = estorba ? 3.2 : 0.05;
            if(!estorba) por += " (no hay nada boca arriba que estorbe)";
          } else p = 1.2;
          break;
        }
        case "invocador": {
          /* Cartas cuyo efecto pone en el campo un monstruo concreto
             (Hand of Nephthys → Sacred Phoenix). Lo que valen es lo que
             vale lo que sacan, menos lo que cuesta sacarlo. El lector de
             textos las dejaba justo en el umbral: "Tribute 2 monsters"
             es caro en general, pero no cuando lo que sale es un 2400
             que además vuelve solo cada End Phase. */
          const sale = inf.invoca ? { nombre: inf.invoca, datos:null } : null;
          p = sale ? 2.2 + valorCarta(sale) : 1.5;
          por += sale ? ` (saca ${inf.invoca})` : "";
          break;
        }
        /* Una carta que HABILITA a otras (Toon World). No hace nada
           sola, pero sin ella media baraja es papel. Se juega en cuanto
           hay algo que dependa de ella, y no antes: pagar 1000 puntos de
           vida sin tener un solo Toon en la mano es regalar el duelo. */
        case "habilita": {
          const marca = inf.habilita ?? "";
          const dependen = [...v.mano, ...v.monstruos].filter(x =>
            x.nombre && x.nombre.startsWith(marca + " ") && canon(x.nombre) !== nom).length;
          if(!dependen){ p = 0.25; vetado = true;
                         por += " (todavía no tengo nada que dependa de ella)"; break; }
          p = 4.0 + Math.min(dependen, 4) * 0.4;
          if(inf.costeLP && v.lp.mio <= inf.costeLP * 2){
            p = 0.3; vetado = true; por += " (no me queda vida para pagarla)"; break; }
          por += ` (habilita ${dependen} carta(s) de la mano)`;
          break;
        }
        case "lock": {
          /* Un 3.0 fijo y sin condición: es el mismo agujero que el
             `default`. Thousand-Eyes Restrict se activaba con el campo
             rival vacío o con solo tapadas, absorbía una tapada y se
             quedaba con 0 de ataque bloqueando su propio campo. E lo vio
             en dos partidas y preguntó si era stall o bug: era esto.
             Un candado necesita algo QUE ENCERRAR. */
          const absorbible = v.monstruosRival
            .filter(c2=>!c2.bocaAbajo && !esFicha(c2))
            .sort((a2,b2)=>poder(b2)-poder(a2))[0] ?? null;
          if(!absorbible){ p = 0.05; vetado = true;
                           por += " (no hay nada boca arriba que absorber)"; break; }
          p = 3.0 + poder(absorbible)/1600;
          por += ` (absorbe ${absorbible.nombre})`;
          break;
        }
        default: {
          /* ── EL ARREGLO QUE NO ERA UN PARCHE ──
             Aquí ponía `p = 1.2`, y el umbral para jugar una carta es
             0.8: la regla efectiva era "si no te suena la carta, juégala
             en cuanto puedas". Y no le suenan 1.576 de las 1.685 del
             pool, porque `knowledge.js` tiene 109 escritas a mano.
             De ahí salen, todos con la MISMA causa, el Breaker rompiendo
             una tapada cualquiera en vez del Premature Burial que
             sostenía un Jinzo, el Skull Lair sobre su propio monstruo y
             el Raigeki Break sobre lo suyo. No eran cuatro bugs.
             Ahora se lee el texto de la carta y, si no se puede
             justificar qué consigue, no se juega. Ver `lectura.js`. */
          const gordo = amenazaMayor(v);
          const leido = utilidadLeida(names[c.code]?.desc, c.datos, v, {
            objetivoBueno: (gordo && !esFicha(gordo)) ? gordo : null,
            hayCadenaRival: !!(duel.cadena?.length &&
                               duel.cadena[duel.cadena.length-1].controller !== yo),
          });
          p = leido.p; por += ` (${leido.por})`;
          if(!p) vetado = true;
          break;
        }
      }
      /* UNA COPIA BASTA. Wall of Revealing Light, Level Limit, Gravity
         Bind, Swords: son continuas cuyo efecto no se acumula. Poner la
         segunda es pagar dos veces por lo mismo y arriesgar dos cartas a
         un solo Heavy Storm; la buena se guarda en la mano hasta que
         destruyan la primera. E lo vio en la partida 9, pagando 1000 de
         vida dos veces por el mismo muro. */
      if(n>=1 && (inf.continua || inf.rol==="muroGlobal" || inf.rol==="stallGlobal")){
        const yaPuesta = v.backrow.some(c2=>!c2.bocaAbajo && canon(c2.nombre)===nom);
        if(yaPuesta){ p = 0.02; vetado = true; por += " (ya tengo una puesta)"; }
      }

      /* ── LA POSTURA MANDA ──
         La misma carta no vale lo mismo según para qué sea el turno. Un
         Smashing Ground es oro cuando vas por detrás y estorbo cuando lo
         que necesitas es cavar para encontrar tu pieza; un Pot of Greed es
         al revés. Antes todas las cartas se puntuaban igual siempre, que
         es exactamente el "juega cartas sin plan" que reportó E. */
      if(exp("postura") && sabe.postura && !vetado){
        const modo = postura(v);
        const empuja = {
          /* Los empujones son PEQUEÑOS a propósito. Con el doble de estos
             números el bot cambiaba de personalidad cada turno y perdía
             dos puntos de victoria: la postura tiene que inclinar el
             desempate, no reescribir el criterio de cada carta. */
          rematar:     { equipSteal:+0.8, removal:+0.6, revival:+0.4, draw:-0.3,
                         stallGlobal:-0.8, muroGlobal:-0.8 },
          estabilizar: { removal:+0.6, trapMass:+0.5, fusion:+0.4,
                         muroGlobal:+0.5, stallGlobal:+0.5, handRip:-0.4 },
          presionar:   { equipSteal:+0.4, removal:+0.25, swap:+0.25,
                         muroGlobal:-0.5, stallGlobal:-0.4 },
          construir:   { draw:+0.3, handRip:+0.3, fusion:+0.2, buscador:+0.25 },
          buscar:      { draw:+0.7, buscador:+0.7, handRip:+0.2, trick:-0.2 },
        }[modo] ?? {};
        if(empuja[inf.rol]){ p += empuja[inf.rol]; por += ` [${modo}]`; }
      }

      /* Secuencia: la remoción de monstruos espera a que haya invocado.
         Ver el bloque de `puedoInvocar` arriba: es la diferencia entre que
         el Torrential del rival se lleve solo lo tuyo o se lleve lo de los
         dos. */
      if(n>=2 && puedoInvocar && ["removal","equipSteal"].includes(inf.rol)
         && !rivalUso(v,"Torrential Tribute")){
        p -= 1.2; por += " (primero invoco, luego limpio)";
      }
      // lastre: un jugador flojo se guarda la remoción hasta que ya da igual
      if(lastre.sinRemocion && ["removal","massRemoval","spellRemoval","fusion","lock","swap","trick"].includes(inf.rol))
        p = Math.min(p, 0.1);
      /* La nota por evaluación sustituye a la constante, pero NUNCA a un
         veto: si la carta no consigue nada, no la juega, y eso ya está
         decidido arriba. Aquí solo se decide CUÁNTO vale lo que sí hace,
         y esa es la parte donde las constantes no eran comparables entre
         sí. */
      if(POR_EVALUACION && !vetado && p > 0.15){
        const efecto = efectoDe(c, leerCarta(names[c.code]?.desc, c.datos));
        if(efecto){
          const d = delta(v, efecto, PLAN);
          /* Se mezcla con el criterio de siempre en vez de sustituirlo del
             todo: la tabla escrita a mano sabe cosas que la evaluación no
             ve (que la Snatch Steal se guarda, que Scapegoat es del turno
             del rival) y tirarlas sería perder información. */
          p = p*0.4 + (d + 0.8)*0.6;
          por += ` [+${d.toFixed(2)} cartas]`;
        }
      }
      if(p > 0.15) añadir(p, IA.SELECT_ACTIVATE, i, por);
    });

    /* 4. COLOCAR MAGIA/TRAMPA */
    (m.spell_sets||[]).forEach((l,i)=>{
      const c = cartaDeLista(l), inf = infoDe(c);
      let p = 1.4;
      if(inf.reactiva || inf.rapida) p += 1.4;          // trampas y rápidas quieren estar puestas
      if(n>=2 && v.backrow.length>=3) p -= 1.2;         // no cargar todo el backrow
      if(exp("cabras") && canon(c.nombre)==="Scapegoat") p += 1.2; // colocada para encadenarla luego

      /* ══ SISTEMA D · UNA MÁGICA NORMAL NO SE COLOCA SI SE PUEDE JUGAR ══
         En el log de E el bot COLOCÓ Reinforcement of the Army (puntos
         1.4) en vez de buscar un guerrero con ella. Colocar una mágica
         normal no la protege de nada —el rival puede romperla igual— y
         retrasa un turno lo que la carta hace. Solo tiene sentido con las
         rápidas (que se activan en el turno del rival) y con las trampas.

         Esto NO es una excepción para ROTA: es la regla general para
         cualquier mágica normal que el motor esté ofreciendo activar
         AHORA MISMO en esta misma lista de acciones. Si no se puede
         activar, colocarla sigue estando bien. */
      const tipo = c.datos?.type ?? 0;
      const esMagia   = !!(tipo & 0x2);
      const esRapida  = !!(tipo & 0x10000);
      const esContinua= !!(tipo & 0x20000 || tipo & 0x40000 || tipo & 0x80000);
      const magiaNormal = esMagia && !esRapida && !esContinua;
      const puedoActivarla = (m.activates||[]).some(a =>
        a.code === l.code && a.location === l.location && a.sequence === l.sequence);
      if(magiaNormal && puedoActivarla){
        p = 0.05;
        añadir(p, IA.SELECT_SPELL_SET, i,
               `colocar ${c.nombre} (es una mágica normal y puedo jugarla ya)`);
        return;
      }
      añadir(p, IA.SELECT_SPELL_SET, i, `colocar ${c.nombre}`);
    });

    /* 5. CAMBIAR POSICIÓN
       TRAMPA: esto valía 0.9 fijo y el umbral para actuar es 0.8, así que
       en cuanto no había nada mejor —que es casi siempre— el bot se dedicaba
       a girar monstruos. En el log del 2026-08-09 (Horus vs PACMAN, experto)
       hizo 72 cambios de posición contra 6 invocaciones: el duelo llegó al
       turno 35 sin que ninguno de los dos pudiera avanzar. Ahora cada giro
       se puntúa por lo que consigue, y se cuentan los giros por carta para
       que no pueda entrar en bucle aunque la valoración falle.
       OJO: pos_changes NO trae la posición, solo (code, zona, índice).
       Hay que resolverla contra el espejo, como en battlePhase. */
    if(!lastre.sinPosicion) (m.pos_changes||[]).forEach((l,i)=>{
      const real = duel.resolve(l, l.code);
      const c = cartaDeLista(l), inf = infoDe(c);
      const pos = real?.position ?? 0;
      const tapada  = !!(pos & 0x0a);          // boca abajo
      const defensa = !!(pos & 0x0c);          // en defensa
      const amenaza = amenazaMayor(v);
      const techo   = amenaza ? poder(amenaza) : 0;
      // el bit FLIP no es de fiar en esta base (Des Lacooda y Medusa Worm
      // salen sin él), así que se mira también el rol de la tabla
      const esFlip = !!((c.datos?.type ?? 0) & 0x200000)
                     || inf.rol==="flip" || inf.colocarPreferente;
      let p, por = `girar ${c.nombre}`;

      /* Voltear por voltear es la trampa de este bot: el escáner contó
         Tsukuyomi volteado casi seis veces por partida. Un volteo vale lo
         que valga su efecto AHÍ: Tsukuyomi sin nada que apagar no hace
         nada, y Magician of Faith sin mágicas en el cementerio tampoco. */
      /* ── MOTORES DE VOLTEO ──
         Tres de los veinte mazos GANAN volteando el mismo bicho cada
         turno: PACMAN, Clown Control y Phoenix. Des Lacooda roba una
         carta cada volteo, Swarm of Scarabs le mata una tapada, Medusa
         Worm cualquier monstruo, Golem Sentry lo devuelve a la mano.
         El bot no sabía nada de esto, y encima su freno anti-bucle
         apagaba justo el motor del mazo. `voltearVale` dice qué tiene
         que haber para que el volteo consiga algo. */
      const nomC = canon(c.nombre);
      const condicionFlip = {
        siempre:       ()=> true,
        tapadaRival:   ()=> v.monstruosRival.some(x=>x.bocaAbajo),
        backrowRival:  ()=> v.backrowRival.length > 0,
        monstruoRival: ()=> v.monstruosRival.length > 0,
      };
      const flipSirve =
          inf.voltearVale           ? (condicionFlip[inf.voltearVale] ?? (()=>true))()
        : nomC==="Tsukuyomi"        ? v.monstruosRival.some(x=>!x.bocaAbajo)
        : nomC==="Magician of Faith"? v.cementerio.some(x=>(x.datos?.type??0) & 0x2)
        : nomC==="Night Assailant"  ? v.cementerio.some(x=>(x.datos?.type??0) & 0x1)
        : true;

      if(tapada){                               // voltear = invocación por volteo
        if(esFlip && flipSirve)       { p = 2.4; por += " (invocación por volteo: dispara su efecto)"; }
        else if(esFlip)               { p = 0.2; por += " (su efecto no conseguiría nada ahora)"; }
        else if(!amenaza)             { p = 1.5; por += " (campo rival vacío: la saco a pegar)"; }
        else if(atk(c) > techo)       { p = 1.3; por += " (a cara descubierta gana el combate)"; }
        else                          { p = 0.05; por += " (descubierta se la comen)"; }
      } else if(defensa){                       // defensa → ataque
        /* PONER UNA FICHA EN ATAQUE. Lo reportó E y es de las cosas que
           más cantan: una ficha de Scapegoat tiene 0 de ataque, así que
           en ataque no mata nada y encima, cuando se la atacan, te comes
           TODO el ataque del rival en la cara. En defensa te comes cero.
           No es una preferencia: es estrictamente peor.
           Y lo mismo, en general, para cualquier monstruo cuya defensa
           sea mejor que su ataque o al que se vayan a comer. */
        const nada = atk(c) === 0 || valorCarta(c) <= 0.2;
        const peorDeFrente = atk(c) < def(c);
        if(nada)                      { p = 0.02; por += " (0 de ataque: en ataque solo sirve para comer daño)"; }
        else if(peorDeFrente)         { p = 0.05; por += " (defiende mejor de lo que pega)"; }
        else if(exp("posicionSegura") && !sobrevive(c, v))
                                      { p = 0.1;  por += " (de frente se la comen)"; }
        else if(!amenaza)             { p = 1.6 + atk(c)/2500; por += " (a atacar: no hay nada delante)"; }
        else if(atk(c) > techo)       { p = 1.4; por += " (ya gana el combate)"; }
        else                          { p = 0.05; por += " (atacando no consigue nada)"; }
      } else {                                  // ataque → defensa
        /* ══ SISTEMA A · AQUÍ ESTABA EL BUG DE LOS CINCO REPORTES ══
           Para agacharse se exigía `def(c) > atk(c)`. Sangan es 1000/600,
           así que NUNCA entraba y se quedaba de frente delante de un
           La Jinn de 1800 regalando 800 de daño por turno. Pero la
           defensa no se compara con el ataque propio: en defensa el daño
           que te llevas es CERO, mida lo que mida. Lo decide ahora
           `evaluarPosicion`, que mira lo único que importa: si de frente
           consigo algo (atacar o aguantar) o solo regalo puntos de vida.

           OJO CON LA FASE: girar a defensa en la Main Phase 1 renuncia al
           ataque de este turno. Solo se considera "puedo atacar aún" si
           de verdad queda Battle Phase por delante. */
        const quedaBatalla = !!m.to_bp;
        const ev = evaluarPosicion(c, v, {
          puedeAtacarYa: quedaBatalla && !c.yaAtaco,
          inmuneCombate: !!inf.inmuneCombate,
          perfora: !!inf.perfora,
        });
        if(ev.quiere === "defensa"){ p = ev.peso; por += ` (${ev.por})`; }
        else                       { p = 0.05;    por += ` (${ev.por})`; }
      }

      /* Dream Clown y Crass Clown se disparan al pasar a DEFENSA, no al
         voltearse: son la única familia que quiere ir hacia atrás. */
      if(inf.aDefensa && !defensa && !tapada && flipSirve){
        p = 3.0; por = `${c.nombre} a defensa (así es como destruye)`;
      }

      /* Freno de bucle: girar la misma carta una y otra vez no suele ser
         un plan… salvo en los mazos cuyo plan es exactamente ese. Con el
         freno puesto para todos, PACMAN y Clown Control se quedaban sin
         motor: su Des Lacooda deja de robar al tercer turno. Ahora el
         freno solo se aplica cuando el volteo NO consigue nada. */
      const uid = real?.uid ?? `${l.code}:${l.sequence}`;
      const yaGirada = giros.get(uid) ?? 0;
      /* MEDIDO, Y AL REVÉS DE LO QUE DECÍA LA TEORÍA. La guía de PACMAN
         dice que el mazo gana volteando sus bichos "una y otra vez", así
         que la primera versión levantaba el freno para esos mazos. Con
         400 partidas de PACMAN contra PACMAN, el resultado es monótono y
         no deja lugar a dudas:

              tope de giros     2      3      5    sin tope
              victorias        59%    44%    30%     24%

         Lo que falta no es permitir más volteos: es que esos monstruos se
         vuelven a poner boca abajo SOLOS con su propio efecto, y el bot
         los deja a cara descubierta con 500 de ataque para que se los
         coman. Hasta que sepa re-taparlos, voltear más es peor.
         Lo que sí ayuda —y mucho, +9 puntos en ese mismo mazo— es la otra
         mitad: `voltearVale`, que solo voltea cuando el volteo consigue
         algo. El freno se queda en dos para todos. */
      if(yaGirada >= 2){
        p = Math.min(p, 0.05); por += ` (ya girada ${yaGirada} veces)`;
      }

      añadir(p, IA.SELECT_POS_CHANGE, i, por, uid);
    });

    plan.sort((a,b)=>b.puntos-a.puntos);
    /* Lastre de nivel: de vez en cuando elige una jugada peor a propósito.
       No es ruido decorativo, es lo que separa novato de experto y se
       puede medir apagándolo. */
    if(lastre.error && plan.length>1 && azar(lastre.error))
      plan.unshift(plan.splice(1+((Math.random()*(plan.length-1))|0),1)[0]);

    const elegido = plan[intento];
    if(elegido && elegido.puntos > 0.8){
      traza(elegido.por, { puntos:+elegido.puntos.toFixed(2) });
      if(elegido.action===IA.SELECT_POS_CHANGE && elegido.uid!=null)
        giros.set(elegido.uid, (giros.get(elegido.uid) ?? 0) + 1);
      return { type:R.SELECT_IDLECMD, action:elegido.action, index:elegido.index };
    }
    // sin nada que merezca la pena: a la batalla o a terminar
    return { type:R.SELECT_IDLECMD,
             action: m.to_bp ? IA.TO_BP : IA.TO_EP, index:null };
  }

  /* ══════════ BATTLE PHASE ══════════ */
  function battlePhase(m, intento){
    const v = vistaDe(duel, yo, db, names);
    const ataques = (m.attacks||[]).map((l,i)=>{
      const c = duel.resolve(l, l.code);
      /* atkReal/defReal vienen del motor, no de la base: sin ellos un
         Thousand-Eyes Restrict con un 1900 absorbido seguía valiendo 0 y
         el bot no atacaba nunca con él. */
      /* `prestado` viene de la vista legal: un monstruo que controlo pero
         que es SUYO (Mind Control, Snatch Steal). Al acabar el turno se lo
         devuelvo, así que o ataca ahora o no ha servido de nada. E lo vio
         dos veces en la misma partida: robaba un Thunder Dragon y lo
         dejaba plantado hasta devolvérselo entero. */
      const enVista = v.monstruos.find(x=>x.uid === c?.uid);
      const mio = c ? { code:c.code, nombre:names[c.code]?.name??"",
                        datos:db.get(c.code)??null,
                        atkReal:c.atkReal ?? null, defReal:c.defReal ?? null,
                        prestado: !!enVista?.prestado,
                        defensa:false, bocaAbajo:false } : null;
      return { i, c:mio };
    }).filter(a=>a.c);

    if(!ataques.length)
      return { type:R.SELECT_BATTLECMD, action: m.to_m2?BA.TO_M2:BA.TO_EP, index:null };

    /* Lastre de combate: atacar con todo sin mirar. Es EL error de novato
       y el que más partidas regala, así que es el que separa los niveles. */
    if(lastre.combateTonto){
      /* "Sin hacer cuentas" no es "suicídate". Contra un monstruo en
         DEFENSA que no puedes romper te comes la diferencia en la cara,
         y el bot lo hacía dos veces seguidas contra el mismo: E lo vio en
         su primer duelo y tiene razón en que eso no es de nivel normal,
         es de no mirar el tablero. El lastre sigue siendo no pensar en
         trampas ni en cambios; el daño de retroceso gratis se evita. */
      const suicida = c => v.monstruosRival.some(r =>
        !r.bocaAbajo && r.defensa && def(r) > atk(c));
      const sensatos = ataques.filter(a => !suicida(a.c));
      const lista2 = sensatos.length ? sensatos : [];
      if(intento < lista2.length)
        return { type:R.SELECT_BATTLECMD, action:BA.SELECT_BATTLE, index:lista2[intento].i };
      return { type:R.SELECT_BATTLECMD, action: m.to_m2?BA.TO_M2:BA.TO_EP, index:null };
    }

    const rivales = v.monstruosRival;
    /* Cuánto vale atacar con este monstruo, mirando TODOS los objetivos.
       El escáner de partidas decía que el 58% de los ataques no conseguían
       nada: se lanzaban contra monstruos en defensa que no podían romper.
       Un ataque que no mata ni muere es tempo regalado y, encima, se come
       la Sakuretsu del rival para nada. */
    /* El plan manda en la batalla. Un mazo de Burn o de Countdown gana
       sobreviviendo: cambiar golpes es justo lo que NO tiene que hacer, y
       hasta ahora atacaba igual que un mazo de pegar. `agresivo` es cuánto
       vale el daño frente a la ventaja de cartas; `aguanta` es "mi plan es
       llegar vivo al final". */
    const valeAtacar = c => {
      /* Un ataque directo es daño gratis y sin riesgo: lo hace CUALQUIER
         plan, también el de Burn. La primera versión de esto se lo prohibía
         a los mazos defensivos y les costó cinco puntos de victoria
         (Clown Control 43%, Final Countdown 45%): no atacaban nunca, así
         que no cerraban ninguna partida y todo acababa en tablas al turno
         60. Lo que un mazo defensivo evita son los CAMBIOS de golpes, no el
         daño gratis. */
      if(!rivales.length) return 8 + atk(c)/1000;
      /* (Aquí hubo una versión que bajaba el ataque directo a 2.5 para los
         mazos defensivos. No cambió NI UNA partida de 2.400: la nota solo
         ordena los ataques entre sí, y 2.5 sigue estando por encima del
         umbral de 0.2. Sirvió para recordar que hay que comprobar que un
         cambio hace algo antes de darlo por bueno.) */
      let mejor = -9;
      const infoC = infoDe(c);
      for(const r of rivales){
        /* ══ SISTEMA F · LO QUE YA HE VISTO, LO RECUERDO ══
           Una tapada de la que ya conozco la identidad no es una
           incógnita. E lo reportó por sus dos caras en dos partidas
           seguidas: atacó a una defensa que sabía que no podía romper, y
           no atacó a otra que sabía que sí. `conocida` la rellena
           `ai/view.js` solo con lo que ha estado boca arriba. */
        const recordada = r.bocaAbajo && r.conocida
          ? { ...r, code:r.conocida.code, nombre:r.conocida.nombre,
              datos:r.conocida.datos, bocaAbajo:false, defensa:true,
              deMemoria:true }
          : r;
        const infoR = recordada.bocaAbajo ? {} : infoDe(recordada);
        /* LA CUENTA DE ATAQUE NO SIEMPRE VALE. Es `IsMonsterDangerous` de
           WindBot y es lo que faltaba aquí:
             · Spirit Reaper no muere en combate por mucho ataque que le
               eches, así que "le gano" es mentira.
             · D.D. Warrior Lady y D.D. Assailant destierran a los dos: la
               matas, sí, pero pierdes el tuyo. Es un cambio, no un regalo.
           OJO con no pasarse: la primera versión marcaba también los muros
           (Gravekeeper's Spy y compañía) y con eso el bot dejaba de pegarle
           a una Spy boca arriba en ataque, que son 1200 y hay que matarla.
           Para los muros ya están sus propios números; no hacen falta
           banderas. Marcarlos costó dos puntos de victoria medidos. */
        let mata = ganaCombate(c, recordada), muero = muereAtacando(c, recordada);
        /* ATAQUES IGUALADOS. `ganaCombate` pide ATK estrictamente mayor,
           que es lo correcto para "me lo llevo gratis", pero con ataques
           iguales mueren LOS DOS: es un cambio, no un suicidio, y aquí se
           puntuaba -4. Por eso el Thunder Dragon robado con Mind Control
           no atacaba al Breaker de 1600 y volvía intacto a su dueño al
           acabar el turno (partida 1, turnos 5 y 8). */
        if(!mata && !recordada.bocaAbajo && !recordada.defensa && atk(c) > 0
           && atk(c) === atk(recordada))
          mata = true;
        if(exp("peligrosos") && infoR.inmuneCombate) mata = false;
        let s;
        if(exp("peligrosos") && infoR.peligroso && mata && !muero)
          s = 0.8 + (valorCarta(recordada) - valorCarta(c));  // cambio, no regalo
        else if(mata && !muero) s = 4 + poder(recordada)/1000;  // te lo llevas gratis
        else if(mata && muero)  s = 1.0 + (valorCarta(recordada) - valorCarta(c));
        else if(!mata && !muero) s = -0.6;                  // no pasa nada: no ataques
        else                     s = -4;                    // suicidio
        /* ══ SISTEMA B · ATACAR HACIA ARRIBA A PROPÓSITO ══
           Hyper Hammerhead devuelve a la mano al monstruo con el que
           combate. Contra algo que no puedo matar de ninguna otra forma,
           perder el cuerpo y unos puntos de vida para quitarlo de en
           medio puede ser buenísimo — y con la cuenta de siempre esto
           salía -4, o sea "suicidio", y no se hacía nunca. */
        if(!mata && (infoC.rebota || infoC.destierra)){
          const trato = valeAtaqueSuicida(c, recordada, v,
            { rebota:!!infoC.rebota, destierra:!!infoC.destierra });
          if(trato && trato.vale > 0) s = Math.max(s, 1.2 + trato.vale);
        }
        /* Si la conozco de haberla visto, el resultado del combate no es
           una apuesta: se apunta en el log para poder auditarlo. */
        if(recordada.deMemoria && s > 0)
          traza(`recuerdo que ${recordada.nombre} tiene ${def(recordada)} de defensa`);
        /* Con plan defensivo, un cambio de golpes no compensa: cada
           monstruo que se queda en el campo es un turno más de vida. */
        if(exp("planBatalla") && PLAN.aguanta && mata && muero) s -= 2.0;
        mejor = Math.max(mejor, s);
      }
      /* Un monstruo prestado no tiene futuro: cambiarlo por lo que sea es
         ganancia, porque la alternativa es devolvérselo entero. */
      if(c.prestado) mejor += 3.0;
      /* Y una carta clave del plan no se cambia por cualquier cosa: el
         Airknight que te gana la partida no muere contra un 1900. */
      if(exp("planBatalla") && mejor < 3) mejor -= PLAN.peso(c.nombre) * 0.6;
      return mejor;
    };

    /* Primero el que más saca; a igualdad, el más gordo. El orden importa:
       atacar con el grande obliga al rival a gastar el Scapegoat o la
       Sakuretsu ahí, y los pequeños pasan después. Al revés le regalas la
       trampa por un monstruo de 1400. */
    /* ══════════════════════════════════════════════════════════════
       SISTEMA G · ¿PUEDO GANAR ESTE TURNO?

       En el log de E (20-08-11, turno 10) el bot tenía daño de sobra
       para cerrar la partida y no atacó: cada ataque se puntuaba por su
       cuenta —"no pasa nada: no ataques"— y nadie sumaba el total.
       Un jugador cuenta ANTES de decidir.

       Solo cuenta lo determinista con el tablero actual: ataques
       directos si no tiene monstruos, y el exceso sobre los que sí
       tiene. Si el rival tiene tapadas, la cuenta sigue valiendo —puede
       haber una trampa, pero no atacar es perder seguro—, aunque no se
       fuerza el remate si eso implica suicidarse contra una defensa
       conocida.
       ══════════════════════════════════════════════════════════════ */
    const hayLethal = (() => {
      if(!exp("rematar")) return false;
      const defensores = rivales.filter(r => !r.bocaAbajo ? true : true);
      const libres = ataques.map(a => a.c).filter(c => atk(c) > 0);
      if(!libres.length) return false;
      if(!rivales.length){
        const total = libres.reduce((t,c) => t + atk(c), 0);
        return total >= v.lp.rival;
      }
      /* Con monstruos delante: se empareja cada atacante con el defensor
         que puede romper, y el resto pega directo solo si no queda
         ninguno. Es una cota INFERIOR del daño, así que si esto dice que
         hay lethal, lo hay de verdad. */
      const suyos = rivales.map(r => (r.bocaAbajo && r.conocida)
        ? { ...r, datos:r.conocida.datos, bocaAbajo:false } : r);
      const puedenRomper = suyos.every(r =>
        libres.some(c => atk(c) > poder(r)));
      if(!puedenRomper) return false;
      if(libres.length <= suyos.length) return false;   // no sobra nadie para pegar directo
      const ordenados = [...libres].sort((a,b)=>atk(b)-atk(a));
      const directos = ordenados.slice(suyos.length);
      const daño = directos.reduce((t,c)=>t+atk(c), 0);
      return daño >= v.lp.rival;
    })();
    if(hayLethal){
      traza(`LETHAL: ataco con todo, el rival está a ${v.lp.rival}`);
      const todos = ataques.map(a=>({ ...a, p: 90 + atk(a.c)/1000 }))
                           .sort((a,b)=>b.p-a.p);
      if(intento < todos.length){
        ultimoAtacante = todos[intento].c;
        return { type:R.SELECT_BATTLECMD, action:BA.SELECT_BATTLE, index:todos[intento].i };
      }
    }

    const puntuados = ataques.map(a=>({ ...a, p:valeAtacar(a.c) }))
                             .filter(a=>a.p > 0.2)
                             .sort((a,b)=> (b.p-a.p) || (atk(b.c)-atk(a.c)));

    /* Freno con motivo: si el rival tiene tapadas, aún no ha enseñado la
       trampa de masa y tú ya vas ganando, no metas todo el campo. */
    const trampasFuera = rivalUso(v,"Mirror Force") || rivalUso(v,"Torrential Tribute");
    const prudente = !trampasFuera && v.tapadasRival>=2 && v.monstruos.length>=3
                     && ventaja(v)>2 && v.lp.rival>3000;
    const lista = prudente ? puntuados.slice(0,1) : puntuados;

    if(intento < lista.length){
      ultimoAtacante = lista[intento].c;
      traza(`ataca con ${lista[intento].c.nombre}`, { valor:+lista[intento].p.toFixed(2) });
      return { type:R.SELECT_BATTLECMD, action:BA.SELECT_BATTLE, index:lista[intento].i };
    }
    return { type:R.SELECT_BATTLECMD, action: m.to_m2?BA.TO_M2:BA.TO_EP, index:null };
  }

  /* ══════════ CADENAS ══════════ */
  function cadena(m, intento){
    const v = vistaDe(duel, yo, db, names);
    const opciones = (m.selects||[]).map((l,i)=>({ i, c:cartaDeLista(l) }));
    if(!opciones.length) return { type:R.SELECT_CHAIN, index:null };
    if(m.forced) return { type:R.SELECT_CHAIN, index: intento % opciones.length };

    /* Los niveles bajos no responden en el turno rival: la mitad de las
       trampas de Goat se quedan sin usar y se nota mucho en el marcador. */
    if(lastre.sinCadenas) return { type:R.SELECT_CHAIN, index:null };
    // lastre: responde con lo primero que tenga, sin pensar si toca
    if(lastre.cadenaTonta) return { type:R.SELECT_CHAIN,
      index: azar(.4) ? ((Math.random()*opciones.length)|0) : null };

    /* NUNCA responder a tu propia carta. En el duelo del 2026-08-10 el
       bot experto negó su propio Trap Dustshoot con Solemn Judgment y
       pagó media vida por nada: veía "hay ventana de respuesta y tengo
       una contra-trampa" sin mirar de quién era el eslabón de arriba. */
    const arriba = duel.cadena?.[duel.cadena.length-1] ?? null;

    /* CONTRA QUÉ estoy respondiendo. Sin esto la ventana de cadena era
       ciega: la IA veía "puedo activar algo" y lo activaba, gastando una
       Sakuretsu Armor en un Sinister Serpent de 300 o media vida de Solemn
       Judgment en un Book of Moon. La mitad de Goat se juega aquí. */
    const desdeCodigo = code => code ? { code, nombre:names[code]?.name ?? "",
                                         datos:db.get(code) ?? null } : null;
    const atacante = (duel.atacante && duel.atacante.controller!==yo)
      ? { ...desdeCodigo(duel.atacante.code),
          atkReal: duel.cards?.get(duel.atacante.uid)?.atkReal ?? null } : null;
    const negando = (arriba && arriba.controller!==yo) ? desdeCodigo(arriba.code) : null;
    const BATALLA = [0x8,0x10,0x20,0x40,0x80];
    const enBatalla = BATALLA.includes(v.fase);
    const enEnd     = v.fase === 0x200;

    const puntuar = o => {
      const inf = infoDe(o.c), nom = canon(o.c.nombre);
      /* Scapegoat se encadena en el turno rival, sí, pero además LO MÁS
         TARDE POSIBLE: en la End Phase o cortando un ataque. Quemarla en
         la Main Phase 1 del rival le enseña las fichas y le deja todo el
         turno para responderlas. */
      if(nom==="Scapegoat"){
        if(v.turnoMio) return -1;
        if(!enBatalla && !enEnd) return 0.5;        // aún es pronto
        return v.monstruos.length===0 ? 6 : 3;
      }
      if(nom==="Book of Moon"){
        /* LA JUGADA QUE MÁS SALÍA EN EL ESCÁNER: 194 veces en 300 partidas,
           el bot encadenaba su propia Book of Moon a su propia invocación,
           con el campo rival vacío o solo con tapadas. Aquí no había
           condición ninguna: "puedo encadenar algo" era razón suficiente.
           Book of Moon es del turno del rival: tumba al que ataca o apaga
           un efecto. En el tuyo, y sin nada boca arriba enfrente, no hace
           absolutamente nada. */
        if(v.turnoMio) return -1;
        const objetivo = atacante ?? v.monstruosRival.find(c=>!c.bocaAbajo);
        if(!objetivo) return -1;
        /* Y contra qué. Tumbar un Sinister Serpent de 300 que ataca a tu
           Airknight es tirar la carta: tu monstruo ya gana ese combate.
           Book of Moon es para lo que NO puedes parar de otra forma. */
        if(n>=2 && atacante){
          const meLoComo = v.monstruos.some(x=>!x.bocaAbajo && !x.defensa
                                            && atk(x) > atk(atacante));
          if(meLoComo) return -1;
        }
        return n>=2 ? 3.5 : 2;
      }
      /* ══ SISTEMA C · REACTIVAS CON CONDICIÓN, NO CON VENTANA ══
         Una ventana de respuesta no es una razón para responder. Estas
         dos salían en el log de E gastadas a nada. */
      if(inf.rol==="proteccionBatalla"){
        /* Waboku anula el daño de batalla DE ESTE TURNO. En tu propio
           turno no hay ataques que anular: la carta se tira. Y aun en el
           turno del rival, hace falta que haya un ataque de verdad o al
           menos algo que pueda atacar. */
        if(v.turnoMio) return -1;
        if(!enBatalla) return 0.2;
        if(!atacante){
          const puedenPegar = v.monstruosRival.filter(x=>!x.bocaAbajo && !x.defensa);
          if(!puedenPegar.length) return -1;
        }
        /* Y cuánto vale: lo que me ahorro. Anular 400 de daño no es
           gastar una carta; salvar el monstruo o media vida, sí. */
        const golpe = atacante ? atk(atacante) : pegaMasFuerte(v, { conMano:false });
        const miMejorDefensor = v.monstruos.filter(x=>!x.bocaAbajo)
                                 .reduce((mx,x)=>Math.max(mx, poder(x)), 0);
        const dañoQueEvito = Math.max(0, golpe - miMejorDefensor);
        const meSalvaElCuerpo = !!atacante && v.monstruos.some(x=>!x.bocaAbajo && poder(x) < golpe);
        if(v.lp.mio <= golpe) return 9;                       // o esto, o pierdo
        if(dañoQueEvito >= 1500 || meSalvaElCuerpo) return 4.2;
        if(dañoQueEvito >= 800) return 2.8;
        return 0.4;
      }
      if(inf.rol==="quemaPorMonstruos"){
        /* Just Desserts: 500 por cada monstruo que tenga el rival. Con un
           solo monstruo son 500 puntos, o sea nada, y la carta ya no está
           para cuando de verdad rematan. Se juega si mata, si el daño es
           relevante, o si la voy a perder igualmente. */
        const cabezas = v.monstruosRival.length;
        const porCabeza = inf.porCabeza ?? 500;
        const daño = cabezas * porCabeza;
        if(daño <= 0) return -1;
        if(daño >= v.lp.rival) return 9.5;                    // lethal: máxima prioridad
        /* ¿Se va a perder de todas formas? Si el rival está resolviendo
           algo que barre el backrow, mejor cobrarla ahora. */
        const laVoyAPerder = !!negando &&
          ["massRemoval","spellRemoval"].includes(rolDe(negando));
        if(laVoyAPerder && daño > 0) return 3.2;
        const trozo = daño / Math.max(1, v.lp.rival);
        if(trozo >= 0.35) return 4.6;                         // más de un tercio de su vida
        if(trozo >= 0.20) return 2.9;
        return 0.3;                                           // daño irrelevante: se guarda
      }

      /* ── ANTES QUE NINGUNA RAMA POR ROL ──
         `conocer()` inventa un rol para las cartas que no están en la
         tabla: toda trampa sale como "trapRemoval". Con este bloque
         DEBAJO de esa rama, Skull Lair y Raigeki Break —que no tienen
         caso escrito— cogían la nota genérica de trapRemoval (4) y se
         encadenaban con el campo rival vacío. Lo cazó el banco de
         posiciones. Un rol deducido no es información: es un hueco. */
      if(inf.deducido){
        const gordo = amenazaMayor(v);
        const leido = utilidadLeida(names[o.c.code]?.desc, o.c.datos, v, {
          objetivoBueno: atacante ?? ((gordo && !esFicha(gordo)) ? gordo : null),
          hayCadenaRival: !!negando,
        });
        return leido.p;
      }
      if(inf.rol==="trapMass"){
        /* Trampa de masa. Lo que la hace buena no es que haya una ventana:
           es la DIFERENCIA de campo, y medida en VALOR, no en número.
           Dos observaciones de E:
             · la usaba como disparador de su propia invocación. Torrential
               salta cuando invoca cualquiera de los dos, y el bot no
               miraba de quién era el turno: se volaba su propio monstruo.
             · la usaba estando por delante, que es regalarla.
           Se activa cuando de verdad va perdiendo el campo. */
        if(nom==="Torrential Tribute" && v.turnoMio) return -1;
        const valorSuyo = v.monstruosRival.reduce((s,c2)=>
          s + (c2.bocaAbajo ? 1.0 : valorCarta(c2) + poder(c2)/2000), 0);
        const valorMio  = v.monstruos.reduce((s,c2)=>
          s + valorCarta(c2) + poder(c2)/2000, 0);
        if(valorSuyo <= valorMio + 0.4) return 0.3;   // saldría perdiendo
        return valorSuyo - valorMio >= 2 ? 6.5 : 3.0;
      }
      if(inf.rol==="trapRemoval"){
        // Sakuretsu y compañía: por un atacante que duela, no por cualquiera
        if(!atacante) return 4;
        const fuerza = atk(atacante);
        return fuerza>=1700 ? 5.2 : fuerza>=1400 ? 3.2 : 1.0;
      }
      if(inf.rol==="counter"){
        /* Solemn Judgment cuesta MEDIA VIDA. Solo por algo que decida la
           partida: negar un Book of Moon con 4.000 puntos de vida es cómo
           se pierde un duelo ganado. */
        if(!exp("counter")) return 2;
        if(v.lp.mio <= 2500) return -1;
        const vale = negando ? valorCarta(negando) : 1.0;
        return vale>=1.6 ? 5.0 : vale>=1.3 ? 2.6 : 0.4;
      }
      if(inf.rol==="removal" && inf.rapida){
        // Ring of Destruction: rematar, o llevarse algo gordo
        const obj = atacante ?? amenazaMayor(v);
        if(obj && v.lp.rival <= atk(obj)) return 9;
        return obj && poder(obj)>=1700 ? 4.5 : 1.5;
      }
      if(inf.rol==="spellRemoval"){
        /* DESTRUIR NO ES NEGAR. Si la carta del rival ya está en la
           cadena resolviéndose, romperla no impide nada: el efecto sale
           igual y tú has tirado tu trampa. E lo vio dos veces —Dust
           Tornado sobre un Nobleman y sobre un Metamorphosis que ya
           estaban activándose— y las dos era tirar la carta. */
        if(negando){ return -1; }
        /* "They Mystical Space Typhooned their own magic/trap card on every
           game I played" (AyeRye, Reddit). Aquí no había NINGUNA condición:
           devolvía 3 y a correr. Si el rival no tiene backrow, el único
           objetivo legal es el tuyo, y el bot se volaba su propia trampa
           puesta. Igual que en la Main Phase: sin objetivo del rival, no
           se activa; y se guarda para lo que de verdad duele. */
        if(!v.backrowRival.length) return -1;
        const jugoso = v.backrowRival.some(c2=>!c2.bocaAbajo &&
          ["equipSteal","revival","lock","muroGlobal","campo"].includes(rolDe(c2)));
        return jugoso ? 5 : 2.6;
      }
      return 2;
    };
    if(arriba && arriba.controller === yo){
      traza("no me encadeno a mi propia carta");
      return { type:R.SELECT_CHAIN, index:null };
    }
    const orden = opciones.map(o=>({...o, p:puntuar(o)}))
                          .filter(o=>o.p>2.4).sort((a,b)=>b.p-a.p);
    if(intento < orden.length){
      traza(`encadena ${orden[intento].c.nombre}`);
      return { type:R.SELECT_CHAIN, index:orden[intento].i };
    }
    return { type:R.SELECT_CHAIN, index:null };
  }

  /* ══════════ SELECCIONES ══════════ */
  function elegirCartas(m, intento){
    const lista = m.type===T.SELECT_UNSELECT_CARD ? (m.select_cards||[]) : (m.selects||[]);
    if(!lista.length) return null;

    /* Lastre: descartar, buscar o destruir a lo tonto. Aquí se decide qué
       carta se va al cementerio y qué se saca del deck, y un jugador malo
       lo hace sin mirar. */
    if(lastre.malaSeleccion && m.type!==T.SELECT_UNSELECT_CARD){
      const min = Math.max(1, m.min ?? 1), max = m.max ?? min;
      const idx = lista.map((_,i)=>i).sort(()=>Math.random()-0.5).slice(0, Math.min(max, Math.max(min,1)));
      return { type: m.type===T.SELECT_TRIBUTE?R.SELECT_TRIBUTE:R.SELECT_CARD, indicies:idx };
    }

    /* Elegir a quién atacar. Antes se cogía "la carta más valiosa", que
       es justo como un monstruo se suicida contra otro más grande. */
    const enBatalla = [8,16,32,64,128].includes(duel.phase);
    if(n>=1 && enBatalla && ultimoAtacante && m.type===T.SELECT_CARD
       && lista.every(l=>l.location===4)){
      const cand = lista.map((l,i)=>{
        const c = cartaDeLista(l);
        const objetivo = { ...c, defensa:!!(l.position & 0x0c), bocaAbajo:!!(l.position & 0x0a) };
        return { i, objetivo, gano: ganaCombate(ultimoAtacante, objetivo),
                 muero: muereAtacando(ultimoAtacante, objetivo),
                 valor: valorCarta(objetivo) + poder(objetivo)/2000 };
      });
      const buenos = cand.filter(c=>c.gano && !c.muero).sort((a,b)=>b.valor-a.valor);
      let elegido = buenos[0] ?? cand.sort((a,b)=>poder(a.objetivo)-poder(b.objetivo))[0];
      // elegir bien a quién atacas es donde está de verdad la habilidad
      if(lastre.objetivoTonto) elegido = cand[(Math.random()*cand.length)|0];
      traza(`objetivo: ${elegido.objetivo.nombre}`);
      return { type:R.SELECT_CARD, indicies:[elegido.i] };
    }
    /* Thousand-Eyes Restrict absorbe copiando el ATK del objetivo. Si
       absorbe una carta tapada se queda en 0 ATK y ataca con 0: medido en
       check-cartas.mjs (boca arriba → 1900, tapada → 0). Así que de los
       monstruos del rival, solo boca arriba, y el de más ataque. */
    if(m.type===T.SELECT_CARD && lista.length>1
       && lista.every(l=>l.location===4) && !enBatalla){
      const rivales = lista.map((l,i)=>({ i, l, c:cartaDeLista(l),
                                          tapada:!!(l.position & 0x0a) }))
                           .filter(x=>x.l.controller!==yo);
      const caraArriba = rivales.filter(x=>!x.tapada);
      if(caraArriba.length){
        const mejor = caraArriba.sort((a,b)=>poder(b.c)-poder(a.c))[0];
        traza(`objetivo boca arriba: ${mejor.c.nombre}`);
        return { type:R.SELECT_CARD, indicies:[mejor.i] };
      }
    }
    const esTributo = m.type===T.SELECT_TRIBUTE;
    const esDescarte = m.type===T.SELECT_CARD && m.selects?.every(l=>l.location===2);

    /* ── NO TE DISPARES EN EL PIE ──
       El motor pasa la lista de objetivos LEGALES y no dice si la carta
       que se resuelve hace bien o mal al objetivo. Ring of Destruction,
       Book of Moon, Nobleman of Crossout y Tsukuyomi admiten monstruos de
       los dos lados, y esta función ordenaba por "lo más valioso" sin
       mirar de quién era: reportado por un jugador, el bot tumbó su propio
       Dekoichi recién invocado con su Book of Moon.
       Regla: si en la lista hay algo del rival, lo mío va al final.
       Cuando la carta necesita de verdad un objetivo propio —el material
       de Metamorphosis, un tributo, una reanimación desde el cementerio—
       la lista es SOLO mía y esta regla no llega a aplicarse. */
    const enCampo = lista.every(l=>[4,8].includes(l.location));
    const hayDelRival = lista.some(l=>l.controller!==yo);
    const evitarPropias = enCampo && hayDelRival && !esTributo && !esDescarte;
    /* Si TODO lo que se ofrece es mío y está en el campo, esto no es un
       objetivo: es un COSTE. El material de Metamorphosis, el tributo de
       una invocación, la carta que se manda al cementerio. Ordenarlo por
       "lo más valioso" hacía que el bot sacrificara el Airknight teniendo
       una ficha de Scapegoat al lado — lo cazó el banco de posiciones. */
    const esCoste = enCampo && !hayDelRival && !esTributo && !esDescarte;

    const puntuar = (l)=>{
      const c = cartaDeLista(l);
      let val = valorCarta(c);
      const inf = infoDe(c);
      if(esTributo || esDescarte){
        // sacrificar/descartar lo que menos duela; Sinister vuelve sola
        if(canon(c.nombre)==="Sinister Serpent") val = 0.1;
        if(inf.rol==="chatarra") val -= 0.4;
        /* Con lo que gana la partida no se paga un coste. Descartar el
           Black Luster Soldier para un Graceful Charity, o tributar el
           Airknight para hacer un Thousand-Eyes, es tirar el plan. */
        /* El peso dice CUÁNTO aporta esa carta a ganar: 3 = es la
           partida (Final Countdown, Black Luster Soldier), 2 = jugada de
           poder, 1 = ayuda. Con eso, "no descartes tu carta buena" deja
           de ser un sí/no y se ordena solo. */
        if(exp("planDescarte")) val += PLAN.peso(c.nombre) * 1.2;
        if(exp("planDescarte") && PLAN.esMotor(c.nombre)) val += 0.6;
        return val;                            // menor es mejor
      }
      if(esCoste) return val;                            // menor es mejor
      if(evitarPropias && l.controller===yo) return 99;   // lo mío, lo último
      return -val - poder(c)/2000;             // destruir/robar lo más valioso
    };
    const orden = lista.map((l,i)=>({i, p:puntuar(l)})).sort((a,b)=>a.p-b.p);
    if(n===0) orden.sort(()=>Math.random()-0.5);
    const min = Math.max(1, m.min??1), max = Math.min(m.max??min, lista.length);
    /* Si es un COSTE (sacrificar, descartar) se coge el mínimo. Si es un
       BENEFICIO (buscar en el deck, recuperar del cementerio) se coge el
       máximo: Thunder Dragon deja añadir dos copias y la IA cogía una. */
    const deZonaOculta = lista.every(l=>[1,16,32].includes(l.location));
    const beneficio = !esTributo && !esDescarte && deZonaOculta;
    const cuantas = beneficio ? Math.max(min, max)
                              : Math.min(Math.max(min,1), Math.max(max,1));
    const desplaz = intento % Math.max(1, orden.length-cuantas+1);
    const idx = orden.slice(desplaz, desplaz+cuantas).map(o=>o.i);
    if(m.type===T.SELECT_UNSELECT_CARD)
      return { type:R.SELECT_UNSELECT_CARD, index: (m.can_finish && intento>=lista.length) ? null : idx[0] };
    return { type: esTributo?R.SELECT_TRIBUTE:R.SELECT_CARD, indicies: idx };
  }

  /* ══════════ POSICIÓN Y SÍ/NO ══════════ */
  function posicion(m){
    const P = X.OcgPosition;
    const v = vistaDe(duel, yo, db, names);
    const puede = p => m.positions & p;
    if(n===0) return { type:R.SELECT_POSITION, position: puede(P.FACEUP_ATTACK)?P.FACEUP_ATTACK:P.FACEUP_DEFENSE };

    /* Antes se comparaba el NÚMERO de monstruos, así que un Thousand-Eyes
       Restrict acababa en defensa aunque el rival tuviera el campo vacío.
       Lo que importa es si algo puede matarlo y si hay a quién pegar. */
    const mio = { datos: db.get(m.code) ?? null, defensa:false, bocaAbajo:false };
    /* Lo que puede pegarme en SU turno, no solo lo que hay ahora en el
       campo: si le quedan cartas en la mano, cuenta con la invocación
       típica del formato. Poner en ataque un 1400 con el rival a punto de
       sacar un 1900 es regalar la carta y los puntos de vida. */
    const amenaza = Math.max(
      v.monstruosRival.reduce((mx,c)=> Math.max(mx, c.bocaAbajo ? 1500 : poder(c)), 0),
      pegaMasFuerte(v));
    const campoRivalVacio = v.monstruosRival.length === 0;
    /* Thousand-Eyes Restrict figura como 0/0 y por eso acababa siempre en
       defensa. Pero absorbe el monstruo del rival JUSTO DESPUÉS de entrar
       y se queda con su ataque: si hay algo boca arriba que absorber, su
       sitio es el ataque. La posición se elige antes de la absorción, así
       que hay que saberlo de antemano. */
    const absorbe = canon(names[m.code]?.name ?? "")==="Thousand-Eyes Restrict"
                    && v.monstruosRival.some(c=>!c.bocaAbajo && atk(c) > amenaza-1);
    const aguanta = absorbe || atk(mio) > amenaza;

    if((campoRivalVacio || aguanta) && puede(P.FACEUP_ATTACK))
      return { type:R.SELECT_POSITION, position:P.FACEUP_ATTACK };
    /* ══ SISTEMA A, TAMBIÉN AQUÍ ══
       Esto pedía `def >= atk` para elegir defensa, la misma condición
       equivocada que dejaba a Sangan de frente: un monstruo que no gana
       el combate pierde CERO puntos de vida en defensa aunque su defensa
       sea ridícula, y la diferencia entera de frente. Si no aguanta y no
       hay nada a lo que pegar, se agacha y punto. */
    const infoMio = infoDe({ ...mio, nombre: names[m.code]?.name ?? "" });
    const ev = evaluarPosicion(mio, v, {
      puedeAtacarYa: false,          // recién invocado: la batalla la decide después
      inmuneCombate: !!infoMio.inmuneCombate,
      perfora: !!infoMio.perfora,
    });
    if(ev.quiere === "defensa" && puede(P.FACEUP_DEFENSE))
      return { type:R.SELECT_POSITION, position:P.FACEUP_DEFENSE };
    if(puede(P.FACEUP_DEFENSE) && def(mio) >= atk(mio))
      return { type:R.SELECT_POSITION, position:P.FACEUP_DEFENSE };
    if(puede(P.FACEUP_ATTACK)) return { type:R.SELECT_POSITION, position:P.FACEUP_ATTACK };
    if(puede(P.FACEUP_DEFENSE)) return { type:R.SELECT_POSITION, position:P.FACEUP_DEFENSE };
    return { type:R.SELECT_POSITION, position:P.FACEDOWN_DEFENSE };
  }
  /* ── LOS EFECTOS OPCIONALES SON DECISIONES ──
     Esto devolvía `yes` a TODO: "los efectos opcionales suelen convenir".
     Suelen, pero no siempre, y ahí vive una familia entera de misplays.
     El que reportó E: D.D. Warrior Lady dice "when this card battles an
     opponent's monster: You can banish that monster, ALSO BANISH THIS
     CARD". Si tu Lady gana el combate limpio, aceptar es cambiar tu
     monstruo vivo por uno que ya estaba muerto: pierdes el cuerpo y el
     tempo. Solo compensa cuando el de enfrente es algo que no puedes
     matar de otra forma. */
  function siNo(m, tipo){
    if(n===0) return { type:tipo, yes: azar(.6) };
    const nom = canon(names[m.code]?.name ?? "");
    const v = vistaDe(duel, yo, db, names);

    if(exp("opcionales") && (nom==="D.D. Warrior Lady" || nom==="D.D. Assailant")){
      /* ¿contra qué está peleando? El adaptador guarda quién declaró el
         ataque; si ataca ella, el objetivo es lo que hay enfrente. */
      const rival = v.monstruosRival.filter(c=>!c.bocaAbajo)
                     .sort((a,b)=>poder(b)-poder(a))[0] ?? null;
      const yoMisma = { datos: db.get(m.code) ?? null, defensa:false, bocaAbajo:false };
      /* Si le gano limpio, me quedo el cuerpo. Si no puedo con él —o es de
         los que no mueren en combate— desterrar a los dos es justo para
         lo que está esa carta. */
      const ganoLimpio = rival && atk(yoMisma) > poder(rival) && !infoDe(rival).inmuneCombate;
      const vale = !rival || !ganoLimpio || valorCarta(rival) >= 1.6;
      traza(`${nom}: ${vale ? "destierro a los dos" : "no, que le gano limpio y me quedo el cuerpo"}`);
      return { type:tipo, yes: vale };
    }
    return { type:tipo, yes:true };     // el resto de opcionales sí convienen
  }

  /* ══════════ ENTRADA ══════════ */
  return function decidir(m, intento=0){
    switch(m.type){
      case T.SELECT_IDLECMD:   return mainPhase(m, intento);
      case T.SELECT_BATTLECMD: return battlePhase(m, intento);
      case T.SELECT_CHAIN:     return cadena(m, intento);
      case T.SELECT_CARD:
      case T.SELECT_TRIBUTE:
      case T.SELECT_UNSELECT_CARD: return elegirCartas(m, intento);
      case T.ANNOUNCE_CARD: {
        /* Un jugador conoce su propio mazo: se declara la carta que más
           copias le quedan, que es la jugada correcta con Archfiend's Oath. */
        /* OJO: esto miraba `duel.zones[yo][DECK]`, y ahí los códigos son
           ficticios —al robar se reasignan—, así que declaraba una carta
           que podía llevar ya en la mano. Se usa el mazo restante de
           verdad: decklist menos todo lo visto. */
        const v2 = vistaDe(duel, yo, db, names);
        const orden=[...(v2.mazo ?? new Map()).entries()].sort((a,b)=>b[1]-a[1]);
        for(const [code] of orden){
          const d=db.get(code); if(!d) continue;
          let vale=true;
          try{ vale = X.cardMatchesOpcode(d, m.opcodes); }catch(e){ vale=true; }
          if(vale){ traza(`declara ${names[code]?.name ?? code}`); return { type:R.ANNOUNCE_CARD, card:code }; }
        }
        return null;
      }
      /* Tributos de una invocación ritual: hay que dar con un grupo cuyos
         niveles sumen lo que pide la carta. Sin esto el bot no podía jugar
         ningún mazo de ritual —y el jugador tampoco, que es por donde
         apareció el fallo. Se paga con lo que menos duela. */
      case T.SELECT_SUM: {
        const combis = combinacionesSuma(m);
        if(!combis.length) return { type:R.SELECT_SUM, indicies:null };
        const coste = idx => idx.reduce((s,i)=>s + valorCarta(cartaDeLista(m.selects[i])), 0);
        const mejor = combis.slice().sort((a,b)=> coste(a)-coste(b) || a.length-b.length)[0];
        traza(`tributa ${mejor.map(i=>names[m.selects[i].code]?.name).join(" + ")}`);
        return { type:R.SELECT_SUM, indicies:mejor };
      }
      case T.SELECT_POSITION:  return posicion(m);
      case T.SELECT_EFFECTYN:  return siNo(m, R.SELECT_EFFECTYN);
      case T.SELECT_YESNO:     return siNo(m, R.SELECT_YESNO);
      default: return null;    // lo demás lo resuelve el piloto genérico
    }
  };
}
