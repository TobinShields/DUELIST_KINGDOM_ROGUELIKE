/* Valoración del estado: cuánto de bien va la partida para el bot. */
import { conocer } from "./knowledge.js";

/* El ATK que cuenta es el del tablero. `atkReal` lo rellena el adaptador
   preguntándole al motor; si la carta no está en campo (mano, cementerio,
   una lista de selección) no hay valor real y se cae a la ficha impresa. */
export const atk = c => c?.atkReal ?? c?.datos?.attack ?? 0;
export const def = c => c?.defReal ?? c?.datos?.defense ?? 0;
export const atkBase = c => c?.datos?.attack ?? 0;
// Lo que aporta un monstruo defendiendo o atacando
export const poder = c => c?.defensa ? def(c) : atk(c);

export function valorCarta(c){
  if(!c?.nombre) return 1.0;                    // desconocida: valor medio
  return conocer(c.nombre, c.datos).valor ?? 1.0;
}
export function rolDe(c){
  if(!c?.nombre) return "desconocido";
  return conocer(c.nombre, c.datos).rol;
}
export function infoDe(c){
  if(!c?.nombre) return {};
  return conocer(c.nombre, c.datos);
}

/* Ventaja de cartas: la métrica que decide las partidas de Goat. */
export function ventaja(v){
  const mias  = v.mano.length + v.monstruos.length + v.backrow.length;
  const suyas = v.manoRival.cuantas + v.monstruosRival.length + v.backrowRival.length;
  return mias - suyas;
}

/* Presión en el campo, contando solo lo que se puede ver. */
export function presion(v){
  const mio   = v.monstruos.reduce((s,c)=>s+poder(c),0);
  const suyo  = v.monstruosRival.reduce((s,c)=>s + (c.bocaAbajo?1200:poder(c)),0);
  return (mio - suyo)/1000;
}

export function evaluar(v){
  return ventaja(v)*3.0 + presion(v)*1.2 + (v.lp.mio - v.lp.rival)/2500;
}

/* ¿Puedo matar a este monstruo en combate sin perder el mío? */
export function ganaCombate(atacante, defensor){
  if(defensor.bocaAbajo) return atk(atacante) > 1600;   // apuesta razonable
  return defensor.defensa ? atk(atacante) > def(defensor)
                          : atk(atacante) > atk(defensor);
}
export function muereAtacando(atacante, defensor){
  if(defensor.bocaAbajo) return false;
  return !defensor.defensa && atk(defensor) >= atk(atacante);
}

/* ══════════════════════════════════════════════════════════════════
   ¿Y DESPUÉS QUÉ? — lo que el rival puede hacerme en su turno.

   Esto es lo que faltaba y lo que E describía: "la IA a veces invoca en
   ataque por invocar, sin darse cuenta de que yo tengo un monstruo con
   más ataque y que le haré daño al siguiente turno". El bot puntuaba la
   jugada por lo que conseguía AHORA y no miraba el tablero que dejaba.

   No hay simulación: ocgcore no deja clonar un duelo. Pero no hace falta
   simular para saber que un 1400 boca arriba delante de un 1900 está
   muerto. Basta con estimar con qué puede pegar el rival.
   ══════════════════════════════════════════════════════════════════ */

/* ATK más alto que el rival puede poner sobre la mesa en su turno.
   Cuenta lo que ya tiene boca arriba y, si le quedan cartas en la mano,
   la invocación típica del formato: en Goat casi todo el mundo juega
   monstruos de nivel 4 de 1700-1900. Es una estimación, y ser prudente
   aquí es gratis: como mucho el bot coloca en vez de invocar. */
export function pegaMasFuerte(v, { conMano = true } = {}){
  let mx = 0;
  for(const c of v.monstruosRival){
    if(c.bocaAbajo) continue;              // no se sabe, no se cuenta
    mx = Math.max(mx, atk(c));
  }
  if(conMano && v.manoRival.cuantas > 0) mx = Math.max(mx, 1800);
  return mx;
}

/* ¿Este monstruo aguanta boca arriba hasta mi siguiente turno? */
export function sobrevive(carta, v, opciones){
  return atk(carta) > pegaMasFuerte(v, opciones);
}

/* Lo que me cuesta que me lo maten: la carta, más el daño que me llevo.

   OJO CON PASARSE DE PRUDENTE. La primera versión metía en el mismo saco
   lo que el rival tiene EN LA MESA y lo que PODRÍA sacar de la mano, así
   que mientras le quedara una carta el bot no invocaba nada de frente: lo
   colocaba todo, las partidas se alargaban tres turnos y medía dos puntos
   de victoria PEOR. Un jugador de verdad invoca su 1900 y ya veremos.
   Así que son dos cosas distintas: lo de la mesa es un hecho y decide;
   lo de la mano es un riesgo y solo inclina. */
export function costeDeQueMuera(carta, v){
  const enMesa = pegaMasFuerte(v, { conMano:false });
  if(atk(carta) > enMesa){
    const deMano = v.manoRival.cuantas >= 2 ? 1800 : 0;
    return atk(carta) > deMano ? 0 : 0.35;     // riesgo, no certeza
  }
  const dano = Math.max(0, enMesa - atk(carta));
  return valorCarta(carta) + dano/1200;
}

/* ══════════════════════════════════════════════════════════════════
   SISTEMA A · EL EVALUADOR DE POSICIÓN

   Cinco reportes distintos de E eran el MISMO bug:

     · Sangan (1000/600) en ataque delante de La Jinn de 1800;
     · Sangan otra vez, sin ni siquiera atacar;
     · Spirit Reaper acabando en ataque;
     · Black Dragon's Chick invocada de frente sin razón;
     · monstruos pequeños delante de un Luster Dragon de 1900.

   Y la causa era una sola línea. Para agacharse, el bot exigía
   `def(c) > atk(c)`:

       else if(exp("posicionSegura") && def(c) > atk(c) && !sobrevive(c,v))

   Sangan tiene 1000 de ataque y 600 de defensa, así que NUNCA entraba
   por ahí y terminaba el turno de frente regalando 800 de daño cada
   turno. Pero la defensa no hay que compararla con el ataque PROPIO:
   en defensa, un monstruo que pierde el combate te hace perder CERO
   puntos de vida —no hay perforación en casi nada del formato—,
   mientras que de frente te comes la diferencia entera. Da igual que
   su defensa sea 600 o 2000: contra un golpe que no puedes ganar, la
   defensa siempre pierde menos.

   Lo único que hay que mirar de verdad es: ¿voy a ganar algo estando
   de frente? Atacar con provecho, o sobrevivir al golpe. Si no,
   agacharse es gratis.
   ══════════════════════════════════════════════════════════════════ */
export function evaluarPosicion(carta, v, opciones = {}){
  const {
    puedeAtacarYa = false,     // ¿queda Battle Phase y este monstruo puede atacar?
    inmuneCombate = false,     // Spirit Reaper y compañía: no mueren en batalla
    perfora       = false,     // si perfora, la defensa del rival no le protege
  } = opciones;

  const miAtk = atk(carta), miDef = def(carta);
  const golpeRival = pegaMasFuerte(v, { conMano:false });
  /* ¿Aguanto de frente? Con ataques iguales mueren los dos, así que
     "aguantar" es estrictamente mayor. */
  const aguantaDeFrente = miAtk > golpeRival;

  /* ¿Consigo algo atacando ESTE turno? Campo rival vacío es daño
     directo; si no, hace falta ganarle a alguno de sus monstruos. */
  const hayGolpe = puedeAtacarYa && (
    v.monstruosRival.length === 0 ||
    v.monstruosRival.some(r => !r.bocaAbajo &&
      (perfora ? miAtk > def(r) : miAtk > poder(r))));

  /* Lo que me cuesta quedarme de frente: la diferencia que me comería
     el rival en su turno. En defensa eso es cero. */
  const dañoGratis = Math.max(0, golpeRival - miAtk);

  /* Un cuerpo que no muere en combate NO deja de cobrar daño: en
     ataque, cada golpe le quita a su dueño la diferencia. Por eso los
     inmunes quieren defensa todavía más que los demás. */
  if(inmuneCombate && !hayGolpe)
    return { quiere:"defensa", peso: 2.2 + dañoGratis/1500,
             por:"no muere en combate, pero de frente cobra daño gratis" };

  if(hayGolpe)
    return { quiere:"ataque", peso: 1.4 + miAtk/2500,
             por:"tiene un ataque que merece la pena" };

  if(aguantaDeFrente)
    return { quiere:"ataque", peso: 0.6,
             por:"aguanta lo que hay enfrente" };

  /* Ni ataca ni aguanta: de frente solo sirve para regalar puntos de
     vida. El peso crece con lo que me ahorro, para que gane a otras
     jugadas menores cuando el daño evitado es grande. */
  return { quiere:"defensa", peso: 1.3 + dañoGratis/1200,
           por: dañoGratis > 0
             ? `de frente le regalo ${dañoGratis} de daño cada turno`
             : "de frente no consigue nada" };
}

/* ¿Merece la pena atacar CON este monstruo aunque pierda el combate,
   solo por lo que consigue su efecto? Es el caso de Hyper Hammerhead:
   ataca a algo más grande, se lo lleva a la mano y tú pagas la
   diferencia en puntos de vida. Contra un monstruo gordo eso es un
   cambio buenísimo; contra un 1500 cualquiera es tirar el cuerpo. */
export function valeAtaqueSuicida(atacante, defensor, v, opciones = {}){
  const { rebota = false, destierra = false } = opciones;
  if(!rebota && !destierra) return null;
  const daño = Math.max(0, poder(defensor) - atk(atacante));
  if(daño >= v.lp.mio) return null;               // eso es perder la partida
  /* Lo que me llevo por delante: cuánto vale su monstruo, y cuánto más
     grande es que el mío (lo que no podría matar de otra forma). */
  const premio = valorCarta(defensor) + Math.max(0, poder(defensor) - atk(atacante))/900;
  /* Y lo que me cuesta: mi cuerpo si muere, más los puntos de vida.
     Rebotar NO mata al mío si el suyo se va antes del cálculo, pero
     Hyper Hammerhead rebota DESPUÉS del daño, así que el mío muere. */
  const coste = valorCarta(atacante) + daño/1100;
  return { vale: premio - coste, premio, coste, daño };
}
