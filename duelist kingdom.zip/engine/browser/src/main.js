/* ════════════════════════════════════════════════════════════
   ORQUESTADOR: motor + adaptador + vista + IA.
   El control principal es arrastrar cartas; los botones quedan
   para lo que no tiene representación física (pasar de fase).
   ════════════════════════════════════════════════════════════ */
let ME = 0;   // lado que te toca; lo decide el sorteo
let duel, decideAI, trivial, OCG, V, NAMES, DB;
let chainMode = "auto", chainActive = false;
let nivelBot = "duro", cerebro = null;
/* Decisiones que se resuelven solas y nunca se te muestran: colocar en
   qué zona, ordenar cartas, declarar tipo/atributo. */
let AUTO_KINDS = new Set();
let DB_RAW = {};
/* Ventana de respuesta a cadenas: si no contestas, se pasa sola.
   Solo se aplica aquí. En los "¿quieres activar el efecto?" no hay
   temporizador a propósito: dejar que caiga tiraría valor a la basura
   (por ejemplo el retorno de Sinister Serpent). */
let CHAIN_TIMEOUT = (typeof globalThis.GOAT_CHAIN_TIMEOUT === "number")
  ? globalThis.GOAT_CHAIN_TIMEOUT : 15;
let promptTimer = null;
/* Lo que se para el bot antes de su primera decisión de cada fase. En las
   pruebas se pone a 0 con GOAT_PENSAR para que 300 partidas no tarden una
   hora; en el navegador vale medio segundo. */
const PENSAR = (()=>{
  if(typeof globalThis.GOAT_PENSAR === "number") return globalThis.GOAT_PENSAR;
  /* También por variable de entorno: las comprobaciones corren en node y
     con medio segundo por decisión una partida de prueba no termina nunca
     —la primera versión dejó a `jugar.mjs` en cero acciones—. */
  const env = typeof process!=="undefined" && process.env && process.env.GOAT_PENSAR;
  if(env !== undefined && env !== "") return Number(env) || 0;
  return 520;
})();
let idle = null;            // SELECT_IDLECMD vigente
let battle = null;          // SELECT_BATTLECMD vigente
let preferredPlace = null;  // zona donde soltó el jugador

const PHNAME={1:"Draw Phase",2:"Standby Phase",4:"Main Phase 1",8:"Battle Phase",
  16:"Battle Step",32:"Damage Step",64:"Damage Step",128:"Battle Phase",
  256:"Main Phase 2",512:"End Phase"};
const LOCNAME={1:"Deck",2:"mano",4:"campo",8:"M/T",16:"Cementerio",32:"desterradas",64:"Extra"};
const ETIQUETA_NIVEL={novato:"Novato",normal:"Normal",duro:"Duro",experto:"Experto"};
/* Por qué terminó el duelo. Los códigos son los del motor. */
const MOTIVOS={0:"Puntos de vida a cero",1:"Se quedó sin cartas en el Deck",
  2:"Efecto de una carta",3:"Rendición",4:"Se acabó el tiempo"};
const T = s => (globalThis.__T ? globalThis.__T(s) : s);
let CONFIG=null;   // lo que eligió el jugador en el menú (avatares, mazos…)
/* Progreso del modo bots: qué mazo has ganado y en qué dificultad. Se
   guarda con la misma forma que lo lee el menú. */
function apuntarVictoria(){
  const reto = CONFIG?.reto;
  if(!reto?.mazoRival || !reto?.nivel) return;
  try{
    const p = JSON.parse(localStorage.getItem("goatProgreso")||"{}");
    p[reto.mazoRival] = p[reto.mazoRival] || {};
    p[reto.mazoRival][reto.nivel] = true;
    localStorage.setItem("goatProgreso", JSON.stringify(p));
  }catch(err){}
}

/* ── registro de partida ──────────────────────────────────────
   Guarda todo lo que pasa: mensajes del motor, lo que se te
   preguntó y lo que respondiste. Con el botón "Descargar log"
   sale un fichero que permite reproducir el fallo. */
const LOG=[]; let SEED=null, DECKLOG=null;
const t0=Date.now();
function snap(v, prof=0){
  if(v===null||typeof v!=="object") return typeof v==="bigint" ? v.toString()+"n" : v;
  if(prof>4) return "…";
  if(Array.isArray(v)) return v.map(x=>snap(x,prof+1));
  const o={};
  for(const k in v){ if(k==="el"||k==="_el") continue; o[k]=snap(v[k],prof+1); }
  return o;
}
function logIt(kind, data){
  // copia inmediata: si guardásemos referencias, el fichero mostraría el
  // estado final de cada carta y no el del momento del suceso
  data = snap(data);
  LOG.push({ ms:Date.now()-t0, turno:duel?.turnCount??0,
             deQuien:duel?.turnPlayer===ME?"tú":"rival",
             fase:PHNAME[duel?.phase]??"", kind, data });
  if(LOG.length>6000) LOG.splice(0,2000);
}
const queue=[]; const onEvent = e => { logIt("evento", e); queue.push(e); };
const nm = c => (NAMES[c]?.name ?? "#"+c);

/* ══════════════════════════════════════════════════════════════════
   LOS "PARONES DE 5 A 10 SEGUNDOS" ERAN LA COLA DE ANIMACIONES

   Un usuario los reportó y la primera reacción fue buscar un bucle
   lento. No lo hay: medido, una decisión de la IA tarda 0,01 ms y nada
   del Reino pasa de 16 ms. Lo que pasa es más simple y peor de
   encontrar con un perfilador, porque el hilo NO está bloqueado: está
   esperando a propósito.

   Cada evento del motor lleva su espera —240 ms al robar, 290 al mover,
   500 por eslabón de cadena, 400 al invocar— y un turno del rival puede
   traer treinta eventos. Scapegoat (4 fichas = 4 `move`) + Metamorphosis
   + una cadena de tres + los movimientos al cementerio se van a más de
   ocho segundos en los que no puedes hacer nada. Desde fuera eso es
   indistinguible de un cuelgue.

   La solución no es quitar las animaciones —una jugada suelta tiene que
   verse— sino que la espera dependa de CUÁNTAS quedan por delante. Con
   la cola vacía, todo igual que antes. Con veinte eventos encolados, las
   esperas se comprimen hasta un quinto y el turno entero pasa en un par
   de segundos. Es lo mismo que hacen los juegos de cartas cuando
   aceleras una cadena larga.
   ══════════════════════════════════════════════════════════════════ */
const RITMO = { normal:1, apurado:0.45, corriendo:0.2 };
let decisionesSeguidas = 0;
function factorDeRitmo(){
  const n = queue.length;
  if(n >= 14) return RITMO.corriendo;
  if(n >= 6)  return RITMO.apurado;
  return RITMO.normal;
}
/* Todas las esperas de la cola pasan por aquí. `V.sleep` sigue existiendo
   para lo que NO es cola (la moneda, el banner final), que se ve una vez
   y no se acumula. */
const pausa = ms => V.sleep(Math.round(ms * factorDeRitmo()));

async function drain(){
  /* Si la cola viene larga, se avisa una vez: así el jugador sabe que el
     juego no se ha colgado, que era la mitad del problema. */
  if(queue.length >= 14) V.toast?.("Resolviendo la jugada…");
  decisionesSeguidas = 0;
  while(queue.length){
    if(rendido) return true;
    const e=queue.shift();
    switch(e.t){
      case "turn":
        V.banner(`Turno ${e.turn} — ${e.player===ME?"Tú":"Oponente"}`,
                 e.player===ME?"var(--gold)":"#ff8f7a");
        setHUD(e.player, duel.phase); await pausa(600); break;
      case "phase":
        chainActive=false; V.ocultarReveladas(); V.setMomento(null);
        V.setPhase(e.phase); setHUD(duel.turnPlayer,e.phase);
        await V.announcePhase(e.phase, duel.turnPlayer===ME);
        await pausa(90); break;
      case "draw": case "pos": V.layoutAll(); await pausa(e.t==="draw"?240:290); break;
      case "move":
        if(e.to?.location===32 && e.from?.location!==32)
          V.toast(`Desterrada: ${nm(e.code)}`);
        V.layoutAll(); await pausa(290); break;
      case "summon":
        V.alHistorial(e.code, duel.cards.get(e.uid)?.controller===ME,
                      e.kind==="flip" ? "volteo" : "invoca");
        if(e.uid){ V.glow(e.uid,true); V.layoutAll(); await pausa(400); V.glow(e.uid,false); }
        V.toast(`${e.kind==="special"?"Invocación especial":e.kind==="flip"?"Invocación por volteo":"Invoca"}: ${nm(e.code)}`);
        await pausa(180); break;
      case "chain":
        chainActive=true;
        V.alHistorial(e.code, e.controller===ME, "cadena");
        if(e.uid) V.glow(e.uid,true);
        V.toast(`Cadena ${e.link}: ${nm(e.code)}`); await pausa(500);
        if(e.uid) V.glow(e.uid,false); break;
      /* Creature Swap: los dos monstruos cambian de sitio de verdad. */
      case "swap":
        V.layoutAll(); V.toast("Intercambio de monstruos"); await pausa(420); break;
      /* Contadores (Wave-Motion Cannon, Breaker…): el número es lo que la
         carta va a hacer, así que tiene que verse. */
      /* La moneda se ve SIEMPRE, sea de quien sea: es información que
         cambia el resultado del combate. */
      case "moneda": await V.tirarMoneda(e.resultados, e.player===ME); break;
      case "dado":
        V.toast(`${T("Dado")}: ${e.resultados.join(" · ")}`); await pausa(700); break;
      case "contador":
        V.contador(e.uid, e.cuantos, e.clase ?? "contador",
                   e.code ? nm(e.code) : null, e.jugador===ME);
        break;
      case "equip": V.layoutAll(); await pausa(200); break;
      case "chainEnd": chainActive=false; V.ocultarReveladas(); break;
      /* Cartas que un efecto pone boca arriba (Trap Dustshoot, Confiscation…):
         salen al centro del tablero hasta que la cadena termina. */
      case "revelar":
        if(e.uids?.length){
          V.revelar(e.uids);
          V.toast(e.location===2 ? "Se revela la mano del rival"
                                 : `Se revelan ${e.uids.length} carta(s)`);
          await pausa(750);
        }
        break;
      /* Nada de cartel a pantalla completa: pasa en cada ataque. Basta con
         la etiqueta sobre Battle, el HUD y el título del panel de cadena. */
      case "damageStep":
        V.setMomento(e.on ? "damage" : null);
        setHUD(duel.turnPlayer, duel.phase);
        break;
      case "attack":
        chainActive=true; V.setMomento("ataque"); setHUD(duel.turnPlayer, duel.phase);
        await V.telegraphAttack(e.uid, e.targetUid); break;
      case "battle":  await V.animateBattle(e.uid, e.targetUid); break;
      case "attackCancelled": V.toast("Ataque anulado"); await pausa(220); break;
      case "damage": V.popDamage(e.amount,e.player); V.setLP(e.player,e.lp); await pausa(320); break;
      case "recover": case "lp": V.setLP(e.player, e.lp ?? e.value); await pausa(200); break;
      case "win":
        if(e.player===ME) apuntarVictoria();
        /* Cuántos duelos se terminan y en cuántos turnos. Sin esto, la
           única forma de saber si un nivel de IA es injugable es que
           alguien se moleste en contarlo. */
        globalThis.__TELE__?.dueloTermina(e.player===ME, duel.turnCount);
        V.banner(e.player===ME?"¡HAS GANADO!":"HAS PERDIDO", e.player===ME?"var(--gold)":"#ff6a55");
        hidePanel(); V.setControles(null); V.ocultarReveladas();
        await pausa(1500);
        /* En el Reino de los Duelistas el duelo no acaba en la pantalla
           de "nuevo duelo": vuelve al mapa con el resultado, que es quien
           decide si ganas una ficha o la pierdes. */
        /* EN EL REINO NO SE SALTA SOLO. E se quedó sin poder descargar el
           log justo cuando lo necesitaba: el duelo acababa y la pantalla
           cambiaba sola. Ahora sale la pantalla final de siempre —con sus
           puntos de vida, sus turnos y el botón de descargar log— y solo
           al pulsar "Continuar" se vuelve al mapa. */
        if(typeof CONFIG?.alTerminar === "function"){
          await V.pantallaFinal({
            ganaste: e.player===ME, motivo: MOTIVOS[e.reason] ?? "",
            lpMio: duel.lp[ME], lpRival: duel.lp[1-ME], turnos: duel.turnCount,
            avatarMio: CONFIG?.avatarMio, avatarRival: CONFIG?.avatarRival,
            nombreRival: CONFIG?.nombreRival,
            textoNuevo: "Continuar",
            onNuevo: () => CONFIG.alTerminar(e.player===ME) });
          return true;
        }
        await V.pantallaFinal({
          ganaste: e.player===ME, motivo: MOTIVOS[e.reason] ?? "",
          lpMio: duel.lp[ME], lpRival: duel.lp[1-ME], turnos: duel.turnCount,
          avatarMio: CONFIG?.avatarMio, avatarRival: CONFIG?.avatarRival,
          nombreRival: CONFIG?.nombreRival });
        return true;
      case "coreError": console.warn("[core]", e.text); break;
    }
  }
  V.layoutAll(); V.fitBoard();
  return duel.finished;
}
function setHUD(player, phase){
  // el Damage Step no es una fase de la tira: se añade aparte si estamos en él
  const extra = V?.momentoTexto?.() ? ` · <b style="color:#ffb257">${V.momentoTexto()}</b>` : "";
  document.getElementById("turnInfo").innerHTML =
    `<b style="color:${player===ME?"var(--gold)":"#ff8f7a"}">${T(player===ME?"TU TURNO":"TURNO RIVAL")}</b>`+
    `<span style="opacity:.6"> · ${T(PHNAME[phase]??"")} · ${T("Turno "+duel.turnCount)}</span>${extra}`;
}

/* ── panel inferior (solo para lo que no se puede arrastrar) ── */
function panel(title, options, note){
  if(!options.length && !note) { hidePanel(); return; }
  const p=document.getElementById("prompt");
  const fase = T(PHNAME[duel?.phase] ?? "");
  const cuando = momentoPanel && momentoPanel!==fase ? ` · ${T(momentoPanel)}` : "";
  p.innerHTML=`<div class="pfase">${fase}${cuando}</div>`+
    `<div class="ptitle">${T(title)}</div>${note?`<div class="pnote">${T(note)}</div>`:""}`;
  const box=document.createElement("div"); box.className="popts";
  for(const o of options){
    const b=document.createElement("button");
    b.className="btn "+(o.primary?"gold":""); b.textContent=T(o.label);
    b.onclick=()=>{ hidePanel(); o.run(); };
    box.appendChild(b);
  }
  /* OJO AL ORDEN: el botón de plegar va ANTES de la caja de opciones.
     Todo lo que lee este panel —las comprobaciones y el propio juego—
     coge el ÚLTIMO hijo como la lista de botones; al añadirlo después, el
     último hijo pasaba a ser el botón de plegar y `jugar.mjs` se quedaba
     en cero acciones sin decir por qué. */
  ponerPlegado(p);
  p.appendChild(box); p.style.display="block";
  if(plegado()) p.style.display="none";
  /* Y que no se coma el marcador del rival: se mide, no se adivina. */
  else V.apartarPanel?.();
}

/* ── PLEGAR EL PANEL ──
   El panel vive encima del tablero y, con el carril reservado, ya no tapa
   nada. Aun así se puede plegar a una pestaña: en pantallas justas el
   tablero se agradece entero, y el reporte era exactamente ese ("having a
   pop up always there blocks the graveyard"). La preferencia se recuerda. */
function plegado(){ try{ return localStorage.getItem("goatPanelPlegado")==="1"; }catch(e){ return false; } }
function setPlegado(v){
  try{ localStorage.setItem("goatPanelPlegado", v?"1":"0"); }catch(e){}
  document.body.classList.toggle("sinCarril", !!v);
  const p=document.getElementById("prompt");
  if(p && p.dataset.visible==="1") p.style.display = v ? "none" : "block";
  V?.fitBoard?.();
}
/* ══ PLEGAR NO EXISTE CON EL DEDO, Y ES A PROPÓSITO ══
   La pestaña para volver a abrirlo (`#pestana`) vive en `right:0;
   top:50%` con z-index 151. En un móvil, ahí mismo está la tira de
   fases —`#phases`, `right:3px; top:50%`— y va a z-index 300, o sea
   ENCIMA. Resultado: plegabas el panel y la pestaña quedaba debajo de
   DRAW/STANDBY/MAIN, sin forma de recuperarlo. Eso no es un panel
   plegado, es un panel perdido. E lo reportó tal cual.

   Se podría mover la pestaña, pero el rincón de la derecha ya está
   reservado para lo único que no puede taparse nunca (fase y fin de
   turno). Así que con el dedo no hay flecha: el panel se queda. En
   escritorio sigue plegándose, que ahí la pestaña tiene su sitio. */
function ponerPlegado(p){
  p.dataset.visible="1";
  if(V?.esTactil?.()) return;
  const b=document.createElement("button");
  b.className="ppleg"; b.textContent="›"; b.title=T("Plegar el panel");
  b.onclick=e=>{ e.stopPropagation?.(); setPlegado(true); };
  p.appendChild(b);
}
const RAZAS={"1":"Guerrero","2":"Mago","4":"Hada","8":"Demonio","16":"Zombi","32":"Máquina",
  "64":"Aqua","128":"Piro","256":"Roca","512":"Bestia Alada","1024":"Planta","2048":"Insecto",
  "4096":"Trueno","8192":"Dragón","16384":"Bestia","32768":"Bestia Guerrero",
  "65536":"Dinosaurio","131072":"Pez","262144":"Serpiente Marina","524288":"Reptil"};
const ATRIBUTOS={"1":"FUEGO","2":"AGUA","4":"TIERRA","8":"VIENTO","16":"LUZ",
  "32":"OSCURIDAD","64":"DIVINO"};
/* Buscador para declarar el nombre de una carta. */
function declararCarta(codigos, alElegir){
  const p=document.getElementById("prompt");
  p.innerHTML=`<div class="ptitle">${T("Declara una carta")}</div>
    <input id="buscaCarta" placeholder="${T("Escribe un nombre…")}" autocomplete="off">
    <div class="pnote" id="buscaAyuda">${codigos.length} cartas posibles</div>
    <div class="popts" id="buscaRes"></div>`;
  p.style.display="block";
  V.apartarPanel?.();
  const inp=p.querySelector("#buscaCarta"), res=p.querySelector("#buscaRes");
  const pintar=()=>{
    const q=(inp.value||"").trim().toLowerCase();
    const hits=[];
    for(const c of codigos){
      const n=nm(c);
      if(!q || n.toLowerCase().includes(q)){ hits.push([c,n]); if(hits.length>=40) break; }
    }
    hits.sort((a,b)=>a[1].localeCompare(b[1]));
    res.innerHTML="";
    for(const [c,n] of hits){
      const b=document.createElement("button");
      b.className="btn"; b.textContent=n;
      b.onclick=()=>{ hidePanel(); alElegir(c); };
      res.appendChild(b);
    }
    p.querySelector("#buscaAyuda").textContent =
      q ? `${hits.length}${hits.length>=40?"+":""} coincidencias` : `${codigos.length} cartas posibles · escribe para filtrar`;
  };
  inp.oninput=pintar; pintar();
  setTimeout(()=>inp.focus?.(),30);
}
function hidePanel(){
  /* Con una carta fijada, ESC la suelta antes que ninguna otra cosa: es
     lo que espera cualquiera de un panel "pineado". */
  V?.atajos?.({ espacio:null,
                escape: V?.hayCartaFijada?.() ? () => V.soltarCarta() : null });
  cancelPromptTimer();
  V?.setControles?.(null);
  const p=document.getElementById("prompt");
  p.style.display="none"; p.dataset.visible="0";
}
function cancelPromptTimer(){
  if(promptTimer){ clearInterval(promptTimer); promptTimer=null; }
  document.getElementById("ptimer")?.remove();
}
function startPromptTimer(segundos, alAgotarse){
  cancelPromptTimer();
  const p=document.getElementById("prompt");
  const barra=document.createElement("div");
  barra.id="ptimer";
  barra.innerHTML=`<div class="ptnum"></div><div class="ptbar"><i></i></div>`;
  p.insertBefore(barra, p.firstChild);
  const relleno=barra.querySelector("i"), num=barra.querySelector(".ptnum");
  const t0=Date.now(), total=segundos*1000;
  promptTimer=setInterval(()=>{
    const queda=Math.max(0, total-(Date.now()-t0));
    relleno.style.width=(queda/total*100)+"%";
    num.textContent=Math.ceil(queda/1000)+"s";
    barra.classList.toggle("urgente", queda<5000);
    if(queda<=0){ cancelPromptTimer(); alAgotarse(); }
  },100);
}
let MSGNAME={};
function msgName(m){ return MSGNAME[m.type] ?? ("tipo "+m.type); }
/* En qué momento exacto se te está preguntando. No hace falta adivinarlo:
   el propio mensaje del motor trae el "timing". Importa sobre todo en
   batalla, donde responder en la declaración de ataque o ya dentro del
   Damage Step son dos jugadas distintas con Book of Moon en la mano. */
const TIMINGS = [
  [4096,"Declaración de ataque"], [134217728,"Tras el combate"],
  [67108864,"Fin del Battle Step"], [16777216,"Battle Phase"],
  [64,"Invocación normal"], [128,"Invocación especial"], [256,"Invocación por volteo"],
  [512,"Al colocar monstruo"], [1024,"Al colocar M/T"], [2048,"Cambio de posición"],
  [524288,"Al destruirse"], [8388608,"Al ir al cementerio"], [2097152,"Al ir a la mano"],
  [32768,"Final de la cadena"], [8,"Inicio de la Battle Phase"], [16,"Fin de la Battle Phase"],
  [4,"Final de la Main Phase"], [32,"End Phase"], [2,"Standby Phase"], [1,"Draw Phase"],
];
/* Antes esto pegaba el momento al título de cada panel y quedaba un
   "¿Confirmas? · Damage Step" que parecía que te pedían aceptar el Damage
   Step. Ahora el momento va en su propia línea, arriba del panel, junto a
   la fase: es una referencia, no una pregunta. */
let momentoPanel = "";
const conMomento = (titulo, m) => { momentoPanel = momentoPregunta(m) || ""; return titulo; };
/* Las "descripciones" del motor llevan el código de la carta en los bits
   altos cuando el aviso es de una carta concreta. */
function cartaDeDescripcion(d){
  try{
    const b = BigInt(d ?? 0);
    if(b > 1048575n){ const c = Number(b >> 20n); if(NAMES[c]) return c; }
  }catch(e){}
  return null;
}
function momentoPregunta(m){
  const t = ((m?.hint_timing>>>0) || (m?.hint_timing_other>>>0)) >>> 0;
  /* Dentro del Damage Step manda el estado que lleva el adaptador: el
     mensaje trae varios bits a la vez y el que importa es ese. */
  if(V?.momento?.() === "damage")
    return (t & 16384) ? "Damage Step · cálculo de daño" : "Damage Step";
  for(const [bit,txt] of TIMINGS) if(t & bit) return txt;
  return V?.momentoTexto?.() ?? "";
}
function resumen(m){
  const p=o=>(o||[]).map(c=>nm(c.code));
  const r={};
  for(const k of ["summons","special_summons","monster_sets","spell_sets","activates",
                  "pos_changes","attacks","chains","selects","select_cards"])
    if(m[k]?.length) r[k]=p(m[k]);
  for(const k of ["forced","min","max","can_cancel","can_finish","to_bp","to_ep","to_m2","positions"])
    if(m[k]!==undefined) r[k]=m[k];
  return r;
}
// los mensajes del core llevan BigInt, que JSON.stringify no sabe serializar
function safeJSON(o){
  try { return JSON.stringify(o, (k,v)=> typeof v==="bigint" ? v.toString()+"n"
        : (v instanceof Map ? "[Map]" : v)); }
  catch(e){ return "(no serializable: "+e.message+")"; }
}
function respondLogged(r, etiqueta){
  logIt("tú_eliges", { accion:etiqueta, respuesta:r });
  duel.respond(r);
}
const cardAt = l => duel.at(l.controller, l.location, l.sequence);
const sameCard = (loc, card) => loc.controller===card.controller
  && loc.location===card.location && loc.sequence===card.sequence;

/* ── control por arrastre en Main Phase ── */
function armIdle(m){
  idle=m; battle=null;
  const send=(r,et)=>{ idle=null; V.setHandlers({}); V.markDraggable(new Set());
                       V.markUsable(new Set()); hidePanel();
                       // la colocación provisional deja de mandar: ahora manda el motor
                       V.quitarPrevia(false);
                       respondLogged(r,et??"main"); loop(); };
  const cancelarSuelta=(aviso)=>{ preferredPlace=null; if(aviso) V.toast(aviso); V.quitarPrevia(); };
  const R=OCG.OcgResponseType, IA=OCG.SelectIdleCMDAction;
  /* Antes se emparejaba la carta arrastrada con las listas del core por
     (controlador, zona, índice). Si el espejo se desincronizaba un puesto,
     jugabas OTRA carta: es lo que pasó con Chaos Sorcerer, que se "colocó"
     y en realidad colocó el Nobleman of Crossout. Ahora se resuelve cada
     entrada a un uid concreto y la interfaz solo trabaja con uids. */
  const acciones=new Map();   // uid -> {summon,specialSummon,monsterSet,activate,spellSet,posChange}
  const mapear=(list,clave)=>(list||[]).forEach((l,i)=>{
    const c=duel.resolve(l, l.code);
    if(!c) return;
    const e=acciones.get(c.uid) ?? {}; e[clave]=i; acciones.set(c.uid,e);
  });
  mapear(m.summons,"summon"); mapear(m.special_summons,"specialSummon");
  mapear(m.monster_sets,"monsterSet"); mapear(m.activates,"activate");
  mapear(m.spell_sets,"spellSet"); mapear(m.pos_changes,"posChange");
  const playable=new Set(acciones.keys());
  // separar: lo que se juega desde la mano vs. lo que ya está en el
  // campo y tiene efecto disponible (lo que más se pasa por alto)
  const enMano=new Set(), enCampo=new Set();
  for(const uid of playable){
    const c=duel.cards.get(uid);
    (c && c.location===2 ? enMano : enCampo).add(uid);
  }
  V.markDraggable(enMano);
  V.markUsable(enCampo);
  V.setHandlers({
    arrastre: true,
    canDrag: card => playable.has(card.uid),
    onDrop: (card, zone, slotIdx, x, y) => {
      const d=DB.get(card.code), mon=!!(d.type & 0x1), trap=!!(d.type & 0x4),
            campo=!!(d.type & 0x80000);
      const zonaOk = mon ? zone==="m"
                   : campo ? (zone==="st" || zone==="field")
                   : zone==="st";
      if(!zonaOk){
        cancelarSuelta(mon?"Los monstruos van en la zona de monstruos":"Las Mágicas y Trampas van en la zona de M/T");
        return;
      }
      /* Con reglas de 2005 el Field Spell ocupa el puesto 5 de la zona de
         M/T, no una zona aparte: sueltes donde sueltes, va ahí. */
      preferredPlace = campo ? { zone:"st", slot:5 } : { zone, slot:slotIdx };
      const a=acciones.get(card.uid);
      if(!a){ cancelarSuelta("Esa carta no se puede jugar ahora"); return; }
      const opts=[];
      const iS=a.summon??-1, iSS=a.specialSummon??-1, iMS=a.monsterSet??-1,
            iA=a.activate??-1, iSp=a.spellSet??-1;
      if(iS>=0)  opts.push({icon:"⚔", label:"Invocación normal",primary:true,
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_SUMMON,index:iS}, "Invocar "+nm(card.code))});
      if(iSS>=0) opts.push({icon:"✧", label:"Invocación especial",primary:true,
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_SPECIAL_SUMMON,index:iSS}, "Inv. especial "+nm(card.code))});
      if(iMS>=0) opts.push({icon:"⛨", label:"Colocar boca abajo",
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_MONSTER_SET,index:iMS}, "Colocar "+nm(card.code))});
      if(iA>=0)  opts.push({icon:"✦", label:"Activar",primary:true,
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_ACTIVATE,index:iA}, "Activar "+nm(card.code))});
      if(iSp>=0) opts.push({icon:"▤", label:"Colocar tapada",
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_SPELL_SET,index:iSp}, "Colocar tapada "+nm(card.code))});
      if(!opts.length){ cancelarSuelta("Esa carta no se puede jugar ahora"); return; }
      // las trampas solo se pueden colocar: sin menú
      if(trap && opts.length===1) return opts[0].run();
      if(opts.length===1) return opts[0].run();
      V.choiceMenu(x, y, nm(card.code), [...opts,
        {icon:"✕", label:"Cancelar",run:()=>cancelarSuelta()}]);
    },
    onClick: card => {
      // clic en carta propia ya en el campo: activar o cambiar posición
      const a=acciones.get(card.uid); if(!a) return;
      const iA=a.activate??-1, iP=a.posChange??-1;
      const opts=[];
      if(iA>=0) opts.push({icon:"✦", label:"Activar",primary:true,
        // sin el índice, el motor activaba la primera carta de la lista
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_ACTIVATE,index:iA},
                     "Activar "+nm(card.code))});
      if(iP>=0) opts.push({icon:"↻", label:"Cambiar posición",
        run:()=>send({type:R.SELECT_IDLECMD,action:IA.SELECT_POS_CHANGE,index:iP})});
      if(!opts.length) return;
      const r=document.querySelector(`.card[data-uid="${card.uid}"]`)?.getBoundingClientRect();
      V.choiceMenu((r?.left??300)+40,(r?.top??300),nm(card.code),
        [...opts,{icon:"✕", label:"Cancelar",run:()=>{}}]);
    },
  });
  V.setControles({
    fase: m.to_bp ? ()=>send({type:R.SELECT_IDLECMD,action:IA.TO_BP,index:null}) : null,
    faseTxt: "Battle Phase",
    fin: m.to_ep ? ()=>send({type:R.SELECT_IDLECMD,action:IA.TO_EP,index:null}) : null,
  });
  const btns=[{label:"Ver todas las acciones",run:()=>{ fullIdlePanel(m,send); }}];
  panel(PHNAME[duel.phase]??"Main Phase", btns,
        playable.size ? "Arrastra para jugar · mantén pulsada una carta para verla · ✦ = efecto disponible"
                      : "No tienes jugadas disponibles");
}

function fullIdlePanel(m, send){
  const R=OCG.OcgResponseType, IA=OCG.SelectIdleCMDAction, opts=[];
  const push=(list,action,pref)=>(list||[]).forEach((c,i)=>
    opts.push({label:`${pref} ${nm(c.code)}`,run:()=>send({type:R.SELECT_IDLECMD,action,index:i})}));
  push(m.summons,IA.SELECT_SUMMON,"Invocar");
  push(m.special_summons,IA.SELECT_SPECIAL_SUMMON,"Inv. especial");
  push(m.activates,IA.SELECT_ACTIVATE,"Activar");
  push(m.monster_sets,IA.SELECT_MONSTER_SET,"Colocar");
  push(m.spell_sets,IA.SELECT_SPELL_SET,"Colocar tapada");
  push(m.pos_changes,IA.SELECT_POS_CHANGE,"Cambiar posición");
  if(m.to_bp) opts.push({label:"→ Battle Phase",primary:true,run:()=>send({type:R.SELECT_IDLECMD,action:IA.TO_BP,index:null})});
  if(m.to_ep) opts.push({label:"→ Terminar turno",run:()=>send({type:R.SELECT_IDLECMD,action:IA.TO_EP,index:null})});
  opts.push({label:"Volver",run:()=>armIdle(m)});
  panel("Todas las acciones", opts);
}

/* ── Battle Phase: clic en tu monstruo → elegir objetivo ── */
function armBattle(m){
  battle=m; idle=null;
  const R=OCG.OcgResponseType, BA=OCG.SelectBattleCMDAction;
  const send=(r,et)=>{ battle=null; V.setHandlers({}); V.markTargets(new Set());
                  V.markDraggable(new Set()); V.markUsable(new Set());
                  V.markAtacadas(new Set()); hidePanel(); V.quitarPrevia(false);
                  respondLogged(r,et??"battle"); loop(); };
  const attackers=new Map();
  (m.attacks||[]).forEach((l,i)=>{ const c=duel.resolve(l, l.code); if(c) attackers.set(c.uid,i); });
  V.markDraggable(new Set(attackers.keys()));
  // los que ya atacaron quedan apagados, para verlo de un vistazo
  const mios=(duel.zones[ME]?.[4]??[]).filter(Boolean).map(c=>c.uid);
  V.markAtacadas(new Set(mios.filter(u=>!attackers.has(u))));
  V.setHandlers({
    canDrag: ()=>false,
    onClick: card => {
      const i=attackers.get(card.uid);
      if(i===undefined) return;
      send({type:R.SELECT_BATTLECMD,action:BA.SELECT_BATTLE,index:i}, "Atacar con "+nm(card.code));
    },
  });
  V.setControles({
    fase: m.to_m2 ? ()=>send({type:R.SELECT_BATTLECMD,action:BA.TO_M2,index:null}) : null,
    faseTxt: "Main Phase 2",
    fin: m.to_ep ? ()=>send({type:R.SELECT_BATTLECMD,action:BA.TO_EP,index:null}) : null,
  });
  const btns=[];
  (m.chains||[]).forEach((c,i)=>btns.push({label:`Activar ${nm(c.code)}`,
    run:()=>send({type:R.SELECT_BATTLECMD,action:BA.SELECT_CHAIN,index:i})}));
  panel("Battle Phase", btns,
    attackers.size ? "Haz clic en un monstruo tuyo para declarar ataque" : "No puedes atacar");
}

/* Gancho de pruebas: deja pintar un panel de decisión concreto sin tener que
   provocar la situación en una partida real. Existe porque el fallo de "T is
   not a function" solo salía con una carta TAPADA del rival en la lista de
   objetivos —una entre mil— y sin poder montar ese panel a mano no había
   forma honesta de escribir la comprobación que lo impide. Ver
   `check-tapadas.mjs`. No hace nada por sí solo: hay que llamarlo. */
globalThis.__PREGUNTA_DE_PRUEBA__ = m => ask(m);

/* ══════════════════════════════════════════════════════════════════
   COMBINACIONES QUE SUMAN (SELECT_SUM)

   Cada carta ofrecida trae su valor en `amount`. Los 16 bits bajos son su
   valor normal y los altos un SEGUNDO valor para las cartas que pueden
   contar como dos niveles distintos; si el alto es 0, solo vale el bajo.
   Las de `selects_must` entran obligatoriamente y ya descuentan.

   `select_max` es el modo: 0 = la suma tiene que dar EXACTAMENTE `amount`;
   1 = tiene que llegar o pasarse, pero sin que sobre ninguna carta (si al
   quitar cualquiera sigue llegando, esa combinación no vale).

   Las listas son de 2 a 6 cartas, así que se prueban todos los subconjuntos
   sin más: 64 combinaciones en el peor caso.
   ══════════════════════════════════════════════════════════════════ */
function combinacionesSuma(m){
  const lista = m.selects ?? [];
  const n = lista.length;
  if(!n || n > 16) return [];
  const valores = lista.map(e=>{
    const bajo = e.amount & 0xffff, alto = (e.amount >>> 16) & 0xffff;
    return alto ? [bajo, alto] : [bajo];
  });
  const fijo = (m.selects_must ?? []).reduce((s,e)=>s + (e.amount & 0xffff), 0);
  const objetivo = (m.amount ?? 0) - fijo;
  const exacto = !m.select_max;
  /* OJO: el motor manda min y max en 0 cuando no hay límite de cuántas
     cartas puedes coger; tomarlos al pie de la letra dejaba fuera todas
     las combinaciones y los rituales seguían sin poder pagarse. */
  const min = Math.max(1, m.min || 1), max = (m.max > 0 ? m.max : n);
  const out = [];
  for(let mask=1; mask < (1<<n); mask++){
    const idx=[]; for(let i=0;i<n;i++) if(mask & (1<<i)) idx.push(i);
    if(idx.length < min || idx.length > max) continue;
    /* Cada carta puede aportar uno de sus dos valores: se prueban todas las
       repartos posibles, que con estas listas son cuatro o cinco. */
    const sumas = idx.reduce((acc,i)=>{
      const nuevo=[];
      for(const s of acc) for(const v of valores[i]) nuevo.push(s+v);
      return [...new Set(nuevo)];
    }, [0]);
    const vale = exacto
      ? sumas.includes(objetivo)
      : sumas.some(s => s >= objetivo) &&
        // sin sobrar: quitando cualquiera ya no llega
        idx.every(i => {
          const resto = idx.filter(j=>j!==i);
          const s2 = resto.reduce((acc,j)=>{
            const nuevo=[]; for(const s of acc) for(const v of valores[j]) nuevo.push(s+v);
            return [...new Set(nuevo)];
          }, [0]);
          return !s2.some(s=>s >= objetivo);
        });
    if(vale) out.push(idx);
  }
  // primero las que gastan menos cartas
  return out.sort((a,b)=>a.length-b.length);
}

/* ── el resto de decisiones, en panel ── */
function ask(m){
  /* OJO CON EL NOMBRE. Esto se llamaba `T`, igual que la funcion de
     traduccion del modulo, y la tapaba dentro de toda esta funcion. El
     dia que alguien escribio T("Carta boca abajo") aqui dentro, el juego
     reventaba con "T is not a function" —pero solo al seleccionar una
     carta tapada del rival, o sea casi nunca hasta que a alguien le toco
     un Thousand-Eyes Restrict. Se llama MT y ya no puede volver a pasar. */
  const MT=OCG.OcgMessageType, R=OCG.OcgResponseType;
  const send=(r,et)=>{ hidePanel(); V.markTargets(new Set()); V.setHandlers({});
                       V.setZoneViewClose(null); V.closeZoneView(); V.quitarPrevia(false);
                       respondLogged(r,et??msgName(m)); loop(); };
  switch(m.type){
    case MT.SELECT_IDLECMD:   return armIdle(m);
    case MT.SELECT_BATTLECMD: return armBattle(m);
    /* ── TRIBUTOS QUE TIENEN QUE SUMAR ──
       Así se pagan las invocaciones de ritual: "sacrifica monstruos cuyos
       niveles sumen 8". El motor lo manda como SELECT_SUM y esto no estaba
       implementado: caía en el "Decisión no soportada" del final y por eso
       un jugador reportó que su mazo de ritual no podía invocar nada.
       En vez de una lista donde el jugador tiene que hacer la cuenta a
       mano, se calculan las combinaciones que valen y se ofrecen hechas. */
    case MT.SELECT_SUM: {
      const combis = combinacionesSuma(m);
      if(!combis.length)
        return panel(T("No hay combinación posible"),
                     [{label:T("Continuar"),run:()=>send({type:R.SELECT_SUM,indicies:null})}]);
      const etiqueta = idx => idx.map(i=>nm(m.selects[i].code)).join(" + ");
      const opts = combis.slice(0,8).map((idx,k)=>({
        label:`${etiqueta(idx)}`, primary:k===0,
        run:()=>send({type:R.SELECT_SUM, indicies:idx}, "Tributos: "+etiqueta(idx))}));
      panel(conMomento(`${T("Sacrifica para sumar")} ${m.amount}`, m), opts,
            T("Las combinaciones que suman justo salen ya hechas"));
      return;
    }
    case MT.SELECT_CHAIN: {
      const opts=(m.selects||[]).map((c,i)=>({label:`Encadenar ${nm(c.code)}`,primary:true,
        run:()=>send({type:R.SELECT_CHAIN,index:i})}));
      if(!m.forced) opts.push({label:"No responder",run:()=>send({type:R.SELECT_CHAIN,index:null})});
      /* ESC = "no respondo". Es la tecla que más se usa en un duelo, y
         solo se activa cuando pasar es LEGAL: con una cadena obligatoria
         no hay nada que pasar y la tecla no hace nada. */
      V.atajos({ escape: m.forced ? null
                                  : () => send({type:R.SELECT_CHAIN,index:null},"ESC"),
                 espacio: null });
      /* En batalla importa MUCHO en qué momento se responde: no es lo mismo
         encadenar en la declaración de ataque que dentro del Damage Step.
         El momento no se adivina, viene en el propio mensaje del motor. */
      momentoPanel = momentoPregunta(m) || "";
      panel(m.forced?"Efecto obligatorio — elige":"¿Quieres responder?", opts,
            m.forced ? null : "Si no contestas, se pasa sola");
      if(!m.forced && CHAIN_TIMEOUT>0)
        startPromptTimer(CHAIN_TIMEOUT, ()=>{
          logIt("tiempo_agotado",{pregunta:"SELECT_CHAIN"});
          V.toast("Tiempo agotado: no se responde");
          send({type:R.SELECT_CHAIN,index:null},"sin respuesta (tiempo)");
        });
      return;
    }
    case MT.SELECT_EFFECTYN:
      return panel(conMomento(`¿Activar el efecto de ${nm(m.code)}?`, m),[
        {label:"Sí",primary:true,run:()=>send({type:R.SELECT_EFFECTYN,yes:true})},
        {label:"No",run:()=>send({type:R.SELECT_EFFECTYN,yes:false})}]);
    case MT.SELECT_YESNO: {
      /* El motor mete el código de la carta dentro de la descripción:
         así el panel dice de qué efecto habla en vez de "¿Confirmas?". */
      const cod = cartaDeDescripcion(m.description);
      return panel(conMomento(cod ? `¿Activar el efecto de ${nm(cod)}?` : "¿Confirmas?", m),[
        {label:"Sí",primary:true,run:()=>send({type:R.SELECT_YESNO,yes:true})},
        {label:"No",run:()=>send({type:R.SELECT_YESNO,yes:false})}]);
    }
    case MT.SELECT_OPTION:
      return panel("Elige una opción",(m.options||[]).map((o,i)=>
        ({label:`Opción ${i+1}`,run:()=>send({type:R.SELECT_OPTION,index:i})})));
    case MT.SELECT_POSITION: {
      const P=OCG.OcgPosition,o=[];
      if(m.positions&P.FACEUP_ATTACK)   o.push({label:"Ataque",primary:true,run:()=>send({type:R.SELECT_POSITION,position:P.FACEUP_ATTACK})});
      if(m.positions&P.FACEUP_DEFENSE)  o.push({label:"Defensa",run:()=>send({type:R.SELECT_POSITION,position:P.FACEUP_DEFENSE})});
      if(m.positions&P.FACEDOWN_DEFENSE)o.push({label:"Defensa boca abajo",run:()=>send({type:R.SELECT_POSITION,position:P.FACEDOWN_DEFENSE})});
      return panel("¿En qué posición?",o);
    }
    case MT.SELECT_CARD: case MT.SELECT_TRIBUTE: case MT.SELECT_UNSELECT_CARD: {
      const list=m.type===MT.SELECT_UNSELECT_CARD?(m.select_cards||[]):(m.selects||[]);
      const min=m.type===MT.SELECT_UNSELECT_CARD?1:Math.max(1,m.min??1);
      const rt=m.type===MT.SELECT_TRIBUTE?R.SELECT_TRIBUTE
             :m.type===MT.SELECT_UNSELECT_CARD?R.SELECT_UNSELECT_CARD:R.SELECT_CARD;
      const chosen=[], uidOf=i=>duel.resolve(list[i], list[i].code)?.uid;
      const choose=i=>{
        if(m.type===MT.SELECT_UNSELECT_CARD) return send({type:rt,index:i});
        const k=chosen.indexOf(i); k>=0?chosen.splice(k,1):chosen.push(i);
        if(chosen.length>=(m.max??min) && chosen.length>=min) return send({type:rt,indicies:[...chosen]});
        render();
      };
      // Si alguna carta elegible NO está a la vista en el tablero (cementerio,
      // deck, desterradas), abrimos un visor con las cartas para poder verlas.
      const OCULTAS=[1,16,32,64];
      const necesitaVisor = list.some(c=>OCULTAS.includes(c.location));
      const abrirVisor=()=>{
        /* ══ LO QUE SE LE PASA AL VISOR IMPORTA ══
           Antes iba solo `{code, _i}`, y eso rompía dos cosas de golpe:

           · sin `position` ni `controller`, una carta boca abajo del
             rival se pintaba de cara. El panel de texto sí la tapaba
             («Carta boca abajo») pero el visor la enseñaba entera: con
             Nobleman of Crossout se leía el monstruo colocado;
           · y sin `uid` no había forma de distinguir una carta de otra,
             que es lo que necesita el visor para saber si el clic es
             sobre la que ya estás leyendo.

           Se pasa la carta con sus datos y una identidad estable. */
        V.openZoneView(`Elige ${min===(m.max??min)?min:`${min}-${m.max}`} carta(s)`,
          list.map((c,i)=>({ code:c.code, _i:i,
                             position:c.position, controller:c.controller,
                             location:c.location, uid:uidOf(i) ?? `sel${i}` })),
          picked=>{ V.closeZoneView(); choose(picked._i);
                    if(document.getElementById("prompt").style.display==="block" && necesitaVisor)
                      setTimeout(abrirVisor,60); });
      };
      const render=()=>{
        /* Una carta boca abajo del rival NO puede enseñar su nombre. El motor
           manda el código igual —lo necesita para resolver— pero enseñarlo es
           hacer trampa: con Nobleman of Crossout se leía el monstruo tapado. */
        const etiqueta = c => (c.position & 0x0a) && c.controller !== ME
          ? T("Carta boca abajo") : nm(c.code);
        const opts=list.map((c,i)=>({label:`${chosen.includes(i)?"✓ ":""}${etiqueta(c)} (${LOCNAME[c.location]??"?"})`,
          primary:chosen.includes(i),run:()=>choose(i)}));
        if(m.type!==MT.SELECT_UNSELECT_CARD && chosen.length>=min)
          opts.unshift({label:`Confirmar (${chosen.length})`,primary:true,run:()=>send({type:rt,indicies:[...chosen]})});
        if(m.can_cancel) opts.push({label:"Cancelar",run:()=>send({type:rt,
          ...(m.type===MT.SELECT_UNSELECT_CARD?{index:null}:{indicies:null})})});
        if(m.type===MT.SELECT_UNSELECT_CARD && m.can_finish) opts.push({label:"Terminar",run:()=>send({type:rt,index:null})});
        if(necesitaVisor) opts.unshift({label:"👁 Ver las cartas",primary:true,run:abrirVisor});
        panel(conMomento(`Selecciona ${min===(m.max??min)?min:`${min}-${m.max}`} carta(s)`, m),opts,
              necesitaVisor ? "Hay cartas fuera del tablero: ábrelas para verlas"
                            : "Haz clic en las cartas marcadas, en el campo o en tu mano"
                              + (chosen.length?` · elegidas: ${chosen.length}`:""));
        V.setHandlers({ onClick: card=>{ const i=list.findIndex((_,k)=>uidOf(k)===card.uid); if(i>=0) choose(i); } });
        V.markTargets(new Set(list.map((_,i)=>uidOf(i)).filter(Boolean)));
      };
      /* Si cerrabas el visor, el panel de selección se quedaba detrás sin
         volver a pintarse y parecía que el juego se colgaba (el caso de
         Black Luster Soldier). Ahora cerrar el visor repinta el panel. */
      V.setZoneViewClose(()=>{ if(document.getElementById("prompt").style.display!=="block") render(); });
      render();
      if(necesitaVisor) abrirVisor();
      return;
    }
    case MT.ANNOUNCE_CARD: {
      /* Archfiend's Oath y compañía piden declarar el nombre de una carta.
         Los "opcodes" del mensaje limitan qué vale (solo monstruos, etc.),
         y el propio motor trae la función para comprobarlo. */
      const candidatos=[];
      for(const k in DB_RAW){
        const code=+k, d=DB.get(code);
        if(!d) continue;
        let vale=true;
        try{ vale = OCG.cardMatchesOpcode(d, m.opcodes); }catch(e){ vale=true; }
        if(vale) candidatos.push(code);
      }
      const lista = candidatos.length ? candidatos : [...DB.keys()];
      declararCarta(lista, code=>send({type:R.ANNOUNCE_CARD, card:code},
                                      "declara "+nm(code)));
      return;
    }
    case MT.ANNOUNCE_RACE: case MT.ANNOUNCE_ATTRIB: {
      const esRaza = m.type===MT.ANNOUNCE_RACE;
      const N = esRaza ? RAZAS : ATRIBUTOS;
      const bits=[]; const disp = esRaza ? BigInt(m.available) : m.available;
      for(let i=0;i<(esRaza?64:32);i++){
        const bit = esRaza ? (1n<<BigInt(i)) : (1<<i);
        const hay = esRaza ? ((disp>>BigInt(i))&1n)===1n : ((disp>>i)&1);
        if(hay) bits.push([bit, N[String(bit)] ?? ("#"+bit)]);
      }
      const cuantas=m.count??1, elegidas=[];
      const pinta=()=>panel(esRaza?"Declara un Tipo":"Declara un Atributo",
        bits.map(([b,n])=>({label:(elegidas.includes(b)?"✓ ":"")+n, primary:elegidas.includes(b),
          run:()=>{ elegidas.push(b);
            if(elegidas.length>=cuantas)
              send(esRaza?{type:R.ANNOUNCE_RACE,races:elegidas}
                         :{type:R.ANNOUNCE_ATTRIB,attributes:elegidas},"declara "+n);
            else pinta(); }})),
        cuantas>1?`Elige ${cuantas}`:null);
      pinta(); return;
    }
    case MT.ANNOUNCE_NUMBER:
      return panel("Declara un número",(m.options||[]).map((o,i)=>
        ({label:String(o), run:()=>send({type:R.ANNOUNCE_NUMBER,value:i},"declara "+o)})));
    case MT.SELECT_PLACE: case MT.SELECT_DISFIELD: {
      // si el jugador acaba de soltar en una zona concreta, respetarla
      const r=placeFromDrop(m) ?? decideAI(m,0);
      return send(r);
    }
    default: {
      const r=decideAI(m,0);
      if(r) return send(r);
      return panel("Decisión no soportada ("+m.type+")",[{label:"Continuar",run:()=>loop()}]);
    }
  }
}
function placeFromDrop(m){
  if(!preferredPlace) return null;
  const want=preferredPlace; preferredPlace=null;
  const loc = want.zone==="m" ? OCG.OcgLocation.MZONE
            : want.zone==="st" ? OCG.OcgLocation.SZONE : null;
  if(!loc) return null;
  const mask=m.field_mask>>>0;
  const byteIdx = loc===OCG.OcgLocation.MZONE ? 0 : 1;   // bytes 0-1 = jugador preguntado
  const b=(mask>>>(byteIdx*8))&0xff;
  if((b>>>want.slot)&1) return null;                      // esa zona no está disponible
  return { type:OCG.OcgResponseType.SELECT_PLACE,
           places:[{player:m.player, location:loc, sequence:want.slot}] };
}

/* ── rendirse ──
   No se le pide nada al motor: el duelo simplemente se detiene aquí y
   cuenta como derrota. Responder por ti para perder sería peor: habría
   que inventarse una jugada suicida y el log quedaría mintiendo. */
let rendido=false;
function rendirse(){
  if(rendido) return;
  rendido=true;
  logIt("rendicion", { turno:duel?.turnCount, lpTuyos:duel?.lp?.[ME], lpRival:duel?.lp?.[1-ME] });
  V.setHandlers({}); V.markTargets(new Set()); V.markDraggable(new Set());
  V.markUsable(new Set()); V.markAtacadas(new Set()); V.quitarPrevia(false);
  V.closeChoice(); V.closeZoneView(); hidePanel();
  V.banner("TE RINDES", "#ff6a55");
  setTimeout(()=>V.pantallaFinal({
    ganaste:false, motivo:"Te has rendido",
    lpMio:duel?.lp?.[ME], lpRival:duel?.lp?.[1-ME], turnos:duel?.turnCount,
    avatarMio:CONFIG?.avatarMio, avatarRival:CONFIG?.avatarRival,
    nombreRival:CONFIG?.nombreRival }), 900);
}

/* ── bucle ── */
let aiAttempt=0, aiLast=null;
async function loop(){
  try { await loopInterno(); }
  catch(e){
    console.error(e);
    logIt("ERROR", { msg:String(e && e.message || e), pila:String(e && e.stack||"").slice(0,400) });
    /* Un error que nadie reporta no existe. Viaja el TIPO de fallo —el
       mensaje recortado y limpiado—, nunca el estado de la partida. */
    globalThis.__TELE__?.error(String(e && e.message || e));
    /* Visible SIEMPRE: antes acababa escrito en la pantalla de carga oculta.
       Y además RECUPERABLE. Si lo que revienta es el dibujado del panel, la
       pregunta del motor sigue ahí sin contestar y el duelo se quedaba
       muerto: partida perdida por un fallo de la interfaz. Ahora se ofrece
       dejar que el juego conteste esa pregunta por ti y seguir jugando —el
       mismo resolutor que usan los bots— en vez de tener que empezar de
       cero. El log sigue saliendo igual, que es lo que hace falta para
       arreglarlo de verdad. */
    const q = duel?.pending ?? null;
    const botones = [];
    if(q) botones.push({ label:"Continuar (responde el juego por mí)", primary:true,
      run:async()=>{
        try{
          const r = trivial(q) ?? decideAI(q,0);
          if(r){ hidePanel(); logIt("recuperado", { pregunta:msgName(q), respuesta:r });
                 duel.respond(r); return loop(); }
        }catch(e2){ /* si ni así, se queda el botón del log */ }
        panel("Se ha roto algo", [{label:"Descargar log y avisar",primary:true,
          run:()=>document.getElementById("btnLog").click()}],
          "No se ha podido continuar: manda el log, por favor");
      }});
    botones.push({ label:"Descargar log y avisar",
      run:()=>document.getElementById("btnLog").click() });
    panel("Se ha roto algo", botones, String(e && e.message || e));
  }
}
async function loopInterno(){
  while(true){
    if(rendido) return;
    const q=await duel.run();
    if(rendido) return;
    const ended=await drain();
    if(ended||duel.finished) return;
    if(!q) return;
    if(q.player===ME){
      /* Excepción a "sin elección real, resuelve solo": si lo que se elige
         está en la mano del rival, la gracia es VERLA. Aunque solo haya un
         objetivo legal hay que enseñar la mano y esperar a que pulses, o
         Trap Dustshoot pasa en un parpadeo y parece que elige por ti. */
      const miraLaManoRival = q.type===OCG.OcgMessageType.SELECT_CARD
        && (q.selects||[]).some(s => s.location===2 && s.controller!==ME);
      const auto = miraLaManoRival ? null : trivial(q);   // sin elección real → resolver solo
      if(auto){ logIt("auto", {pregunta:msgName(q), respuesta:auto}); duel.respond(auto); continue; }
      // Solo se salta la ventana de respuesta en TU turno y sin cadena en curso.
      // Durante el turno rival hay que preguntar siempre: es cuando activas
      // Call of the Haunted en su End Phase, Book of Moon en su ataque, etc.
      /* Modo "sin cadenas": no te pregunta nada... salvo lo que sale de TU
         cementerio. Si no, el retorno de Sinister Serpent se descartaba solo
         cada turno y perdías la carta sin enterarte, que era la duda que
         quedaba abierta con este modo. */
      const disparadorDesdeGY = (q.selects||[]).some(sel => sel.location === 16);
      if(q.type===OCG.OcgMessageType.SELECT_CHAIN && !q.forced
         && chainMode==="nunca" && !disparadorDesdeGY){
        duel.respond({type:OCG.OcgResponseType.SELECT_CHAIN,index:null}); continue;
      }
      // TRAMPA: saltarse la ventana entera se comía los disparadores propios.
      // Sinister Serpent se ofrece a volver del cementerio en TU Standby Phase,
      // y esto lo descartaba sin preguntar: la carta volvía un turno tarde,
      // en la siguiente ventana que sí se preguntase. Lo delató el log del
      // 2026-08-09 (T4 Standby ofrecía 511000818 y la respuesta era "no responder").
      // En las tres partidas revisadas, lo ÚNICO que se ofrece desde el
      // cementerio es Sinister Serpent; lo demás sale de la mano, de la zona
      // de magias/trampas o del campo, y eso sí se puede saltar sin perder nada.
      const disparadorPropio = q.type===OCG.OcgMessageType.SELECT_CHAIN
        && (q.selects||[]).some(s => s.location === 16);   // 16 = cementerio
      if(q.type===OCG.OcgMessageType.SELECT_CHAIN && !q.forced && !disparadorPropio
         && chainMode==="auto" && !chainActive && duel.turnPlayer===ME){
        logIt("auto",{pregunta:"SELECT_CHAIN (ventana propia sin cadena)",respuesta:"no responder"});
        duel.respond({type:OCG.OcgResponseType.SELECT_CHAIN,index:null}); continue;
      }
      // las que se resuelven solas (colocar zona, ordenar…) no son
      // preguntas de verdad: ensuciaban el log
      if(!AUTO_KINDS.has(q.type)) logIt("te_pregunta", { pregunta:msgName(q), datos:resumen(q) });
      return ask(q);
    }
    if(q!==aiLast){ aiLast=q; aiAttempt=0; }
    /* ── QUE SE LE VEA PENSAR ──
       El bot contestaba al instante y eso, además de no dar tiempo a leer
       el tablero, hacía que sus jugadas parecieran reflejos en vez de
       decisiones. Antes de la PRIMERA decisión de cada fase suya se para
       un momento y se enciende un aviso junto a su avatar. No es
       decoración pura: es el rato que tú necesitas para ver qué acaba de
       pasar antes de que pase lo siguiente. */
    /* Cuántas decisiones lleva la IA seguidas sin devolverte el turno.
       Se reinicia en `drain`, que es lo que corre entre turno y turno. */
    const decisionDeVerdad = q.type===OCG.OcgMessageType.SELECT_IDLECMD
                          || q.type===OCG.OcgMessageType.SELECT_BATTLECMD;
    if(decisionDeVerdad && aiAttempt===0 && PENSAR>0){
      V.pensando?.(true);
      await V.sleep(PENSAR);
      V.pensando?.(false);
    }
    // el cerebro decide; el piloto genérico cubre lo que no le interesa
    // (colocación de zona, ordenar cartas, declarar tipos…)
    const r=trivial(q) ?? cerebro?.(q,aiAttempt) ?? decideAI(q,aiAttempt);
    aiAttempt++;
    if(!r){ logIt("ERROR",{msg:"la IA no supo responder a "+msgName(q)}); console.warn("IA sin respuesta",q); return; }
    logIt("ia", { pregunta:msgName(q), respuesta:r });
    duel.respond(r);
    /* ══ Y LA OTRA MITAD DEL "FREEZE" ══
       Este respiro de 160 ms va DESPUÉS DE CADA respuesta de la IA, y un
       turno suyo puede llevar quince: dos segundos y medio más encima de
       las animaciones. Sirve para que se vea que ha pensado, así que se
       mantiene en las primeras decisiones y se acorta cuando la ráfaga
       se alarga — que es justo cuando ya no aporta nada y solo espera. */
    decisionesSeguidas++;
    await V.sleep(decisionesSeguidas > 6 ? 40 : 160);
  }
}

export async function boot({ createCore, Xns, GoatDuel, makeAutoPlayer, makeTrivialResolver,
                             scriptReader, cardsRaw, names, deck, extra, deckRival, extraRival, View, config }){
  V=View; NAMES=names; OCG=Xns; CONFIG=config??null;
  /* Estado del duelo ANTERIOR fuera. En el Reino se juegan varios duelos
     seguidos sin recargar la página y esto se quedaba puesto: la cadena
     "activa", el temporizador de respuesta corriendo y el atacante del
     duelo pasado. */
  chainActive = false;
  if(promptTimer){ clearInterval(promptTimer); promptTimer = null; }
  DECKLOG = null; LOG.length = 0;
  /* Estado del panel plegado, y la pestaña para volver a abrirlo.
     Con el dedo se DESPLIEGA siempre: quien plegó el panel en una
     versión anterior se quedó con la pestaña debajo de la tira de
     fases y sin forma de recuperarlo. La preferencia guardada no puede
     dejar a nadie encerrado. */
  if(V?.esTactil?.() && plegado()) setPlegado(false);
  document.body.classList.toggle("sinCarril", plegado());
  const pest = document.getElementById("pestana");
  if(pest) pest.onclick = ()=>setPlegado(false);
  // Declarar carta, tipo, atributo o número SÍ es una decisión tuya.
  // Antes se resolvían solas y siempre salía "Pot of Greed".
  AUTO_KINDS = new Set([OCG.OcgMessageType.SELECT_PLACE,
    OCG.OcgMessageType.SELECT_DISFIELD, OCG.OcgMessageType.SORT_CARD]);
  DB_RAW = cardsRaw;
  const cardDb=new Map();
  for(const k in cardsRaw){ const c=cardsRaw[k]; cardDb.set(c.code,{...c,race:BigInt(c.race)}); }
  DB=cardDb;
  /* ══ EL MOTOR TARDA, PERO NO INFINITO ══
     Cargar el wasm es lo único lento del arranque de un duelo. Si por lo
     que sea no resuelve —y ha pasado— la pantalla de carga se queda con
     "Cargando el núcleo de reglas…" para siempre y sin ningún error,
     porque un `await` colgado no lanza nada. Ahora se cuenta el tiempo en
     pantalla y a los 25 segundos se dice que no ha arrancado. */
  const pantallaCarga = document.getElementById("boot");
  const textoCarga = pantallaCarga?.querySelector?.("p");
  const t0 = Date.now();
  const tic = setInterval(() => {
    if(textoCarga) textoCarga.textContent =
      `${T("Cargando el núcleo de reglas")}… ${Math.round((Date.now()-t0)/1000)}s`;
  }, 1000);
  const limite = setTimeout(() => {
    if(pantallaCarga) pantallaCarga.innerHTML =
      `<div style="color:#ff6a55;max-width:70ch;text-align:center;font:14px/1.6 system-ui">
         <b style="font-size:18px">${T("El motor no ha arrancado")}</b><br><br>
         ${T("El núcleo de reglas no ha terminado de cargar. Recarga la página; si vuelve a pasar, mándale una captura de la consola (F12) a Claude.")}
       </div>`;
  }, 25000);
  let lib;
  try{ lib = await createCore({sync:true}); }
  finally{ clearInterval(tic); clearTimeout(limite); }
  duel=new GoatDuel({ lib, X:OCG, cardDb, scriptReader, onEvent });
  decideAI=makeAutoPlayer(OCG); trivial=makeTrivialResolver(OCG);
  if(config?.nivel && NIVELES.includes(config.nivel)) nivelBot = config.nivel;
  if(config?.cadenas) chainMode = config.cadenas;
  if(typeof config?.tiempo === "number" && typeof globalThis.GOAT_CHAIN_TIMEOUT !== "number")
    CHAIN_TIMEOUT = config.tiempo;
  /* El sorteo va ANTES de nada: decide de qué lado juegas, y tanto el
     tablero como el cerebro de la IA dependen de eso. Hacerlo después
     dejaba el tablero espejado y a la IA jugando en TU sitio. */
  const empiezasTu = Math.random() < 0.5;
  ME = empiezasTu ? 0 : 1;
  logIt("sorteo", { empiezasTu });
  // la pantalla de carga tapaba la moneda: hay que quitarla antes
  document.getElementById("boot").style.display="none";
  await View.sorteo(empiezasTu);

  cerebro = crearCerebro({ X:OCG, duel, db:cardDb, names, nivel:nivelBot, yo:1-ME,
                           log: d => logIt("ia_piensa", d) });
  View.initView({ duel, db:cardDb, names, me:ME, images:true });
  /* Las chapas de cuenta (Final Countdown y compañía) viven fuera del
     tablero, así que un duelo nuevo no se las lleva por delante solo. */
  View.limpiarCuentas?.();
  const ZL={gy:16, extra:64, banish:32};
  View.setZoneViewHandler((owner, zone)=>{
    // cementerio y desterradas son información pública; el Extra Deck del
    // rival no: solo puedes mirar el tuyo
    if(zone==="extra" && Number(owner)!==ME){
      V.toast("No puedes ver el Extra Deck del rival"); return;
    }
    const arr=duel.zones[owner][ZL[zone]] ?? [];
    const quien = T(Number(owner)===ME ? "tu" : "del rival");
    const titulo = T(zone==="gy"?"Cementerio" : zone==="extra"?"Extra Deck" : "Cartas desterradas");
    View.openZoneView(`${titulo} ${quien} — ${arr.length} carta(s)`,
      [...arr].reverse());
  });

  const bc=document.getElementById("btnChain");
  const CICLO={auto:"always", always:"nunca", nunca:"auto"};
  const ETIQ_CAD={auto:"Cadenas: automáticas", always:"Cadenas: preguntar siempre",
                  nunca:"Cadenas: no activar nada"};
  const paintChain=()=>{ bc.textContent = T(ETIQ_CAD[chainMode] ?? ETIQ_CAD.auto);
                         bc.classList.toggle("peligro", chainMode==="nunca"); };
  bc.onclick=()=>{ chainMode = CICLO[chainMode] ?? "auto"; paintChain();
                   V.toast(T(ETIQ_CAD[chainMode])); }; paintChain();


  /* Avatares: el tuyo lo eliges en el menú, el rival siempre es Roland. */
  const ponAvatar=(idImg, idNom, a, quien)=>{
    const img=document.getElementById(idImg), nom=document.getElementById(idNom);
    if(img && a?.src){ img.src=a.src; img.alt=a.nombre??""; img.style.display="block"; }
    else if(img) img.style.display="none";
    if(nom && a?.nombre) nom.textContent = quien==="mio" ? a.nombre
      : `${a.nombre} · ${T(ETIQUETA_NIVEL[nivelBot] ?? nivelBot)}`;
  };
  ponAvatar("avMe","nomMe", config?.avatarMio, "mio");
  ponAvatar("avOpp","nomOpp", config?.avatarRival, "rival");

  /* Tocar el panel de detalle abre la carta grande: en el móvil ese panel
     es diminuto y no se puede leer un efecto ahí. */
  const lateral=document.getElementById("side");
  if(lateral) lateral.onclick=()=>V.verUltimaCarta?.();

  const btnR=document.getElementById("btnRendirse");
  if(btnR) btnR.onclick=()=>{
    if(rendido || duel.finished) return;
    V.confirmar("¿Seguro que quieres rendirte?",
      "El duelo termina ahora mismo y cuenta como derrota.", rendirse);
  };

  // botón de emergencia para depurar: fuerza a la IA a pasar
  document.getElementById("btnUnstick").onclick=()=>{
    V.toast("Forzando avance…"); aiAttempt++; loop();
  };

  MSGNAME=Object.fromEntries(Object.entries(OCG.OcgMessageType).map(([k,v])=>[v,k]));
  /* El log también se puede pedir desde fuera (el Reino lo ofrece en la
     pantalla de resultado, que es cuando de verdad hace falta). */
  globalThis.descargarLog = () => document.getElementById("btnLog")?.onclick?.();
  document.getElementById("btnLog").onclick=()=>{
    const cab=[
      "GOAT FORMAT — registro de partida",
      "fecha: "+new Date().toISOString(),
      "semilla: "+SEED,
      "modo cadenas: "+chainMode,
      "nivel del rival: "+nivelBot,
      "tu mazo: "+(config?.nombreMazo??"?")+" · mazo rival: "+(config?.nombreRival??"?"),
      "desincronizaciones detectadas y corregidas: "+(duel?.desyncs??0),
      "turno actual: "+(duel?.turnCount??0)+" · fase: "+(PHNAME[duel?.phase]??""),
      "LP  tú: "+duel.lp[ME]+"   rival: "+duel.lp[1-ME],
      "mazo: "+safeJSON(DECKLOG),
      "".padEnd(70,"─"),""].join("\n");
    const cuerpo=LOG.map(e=>{
      const cab=`[${String(e.ms).padStart(6)}ms] T${e.turno} ${e.deQuien.padEnd(5)} ${String(e.fase).padEnd(14)} ${e.kind}`;
      return cab+" · "+safeJSON(e.data);
    }).join("\n");
    const blob=new Blob([cab+cuerpo],{type:"text/plain;charset=utf-8"});
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob);
    a.download=`goat-log-${new Date().toISOString().slice(0,19).replace(/[:T]/g,"-")}.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    V.toast("Log descargado ("+LOG.length+" entradas)");
  };
  /* Barajado. Con `globalThis.GOAT_SEED` puesto, el sorteo y la semilla del
     motor son fijos y el duelo entero es reproducible: hacía falta porque
     las comprobaciones que juegan una partida de verdad sobre el DOM
     simulado dependían del azar y fallaban una de cada cinco veces sin que
     hubiera nada roto. Un test que parpadea deja de mirarse.
     En el navegador la variable no existe y todo sigue siendo aleatorio. */
  const fija = Number(globalThis.GOAT_SEED) || 0;
  let _x = (fija || 1) >>> 0;
  const azar = fija ? ()=>{ _x^=_x<<13; _x^=_x>>>17; _x^=_x<<5;
                            return ((_x>>>0)%100000)/100000; } : Math.random;
  const shuffle=a=>{const b=[...a];for(let i=b.length-1;i>0;i--){const j=azar()*(i+1)|0;[b[i],b[j]]=[b[j],b[i]];}return b;};
  // cada jugador con su propio mazo
  const mioBaraja = shuffle(deck);
  let rivalBaraja = shuffle(deckRival ?? deck);
  /* MANO DE SALIDA DE UN JEFE (modo historia). El orden del array ES el
     orden de robo, así que colocarle su motor arriba le garantiza abrir
     con él. Va DESPUÉS de barajar, evidentemente. No ve tu mano ni roba
     de más: solo se evita que el jefe final abra sin su carta clave y
     juegue con media baraja muerta. */
  if(config?.manoRival && globalThis.Story?.sembrarManoDeJefe)
    rivalBaraja = globalThis.Story.sembrarManoDeJefe(
      rivalBaraja, config.manoRival, { barajar:shuffle }, c => names[c]?.name ?? "");
  const s0 = ME===0 ? mioBaraja : rivalBaraja;
  const s1 = ME===0 ? rivalBaraja : mioBaraja;
  const e0 = ME===0 ? extra : (extraRival ?? extra);
  const e1 = ME===0 ? (extraRival ?? extra) : extra;
  logIt("mazos", { tuyo:config?.nombreMazo, rival:config?.nombreRival });
  /* Qué se juega y a qué nivel. `nombreMazo` es "Reino" en el modo
     historia y el nombre del mazo en el duelo libre, así que las dos
     cosas se separan solas. */
  globalThis.__TELE__?.dueloEmpieza(
    config?.nombreMazo === "Reino" ? "kingdom" : "free",
    config?.nivel ?? "?", config?.nombreMazo);
  SEED = fija || ((Date.now()&0xffff)+1);
  DECKLOG={ tu:mioBaraja, rival:rivalBaraja };
  await duel.create({ deck0:s0, deck1:s1, extra0:e0, extra1:e1,
    seed:[BigInt(SEED), 7n, 13n, 29n],
    /* ══ LOS PUNTOS DE VIDA VAN POR LADO ══
       El campamento del Reino da vida extra AL JUGADOR, pero esto ponía
       un solo `lp` para los dos: el buff se lo llevaba también el rival
       y por tanto no servía absolutamente de nada. Y por el otro lado,
       `lpRival` es el mando de dificultad del jefe final: no puede ser
       "que juegue mejor" —ya juega en experto— ni hacer trampa.
       ME dice de qué lado juegas tú tras el sorteo. */
    lp0: ME===0 ? (config?.lpIniciales ?? 8000) : (config?.lpRival ?? 8000),
    lp1: ME===0 ? (config?.lpRival ?? 8000) : (config?.lpIniciales ?? 8000),
    /* Y la mano de salida, también por lado: Pegasus abre con siete. */
    mano0: ME===0 ? 5 : (config?.manoRivalCuantas ?? 5),
    mano1: ME===0 ? (config?.manoRivalCuantas ?? 5) : 5 });
  View.layoutAll(true);
  document.getElementById("boot").style.display="none";
  await loop();
}
