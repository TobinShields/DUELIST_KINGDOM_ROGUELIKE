/* ════════════════════════════════════════════════════════════════
   BANCO DE POSICIONES — la vara para medir si la IA juega bien.

   POR QUÉ HACE FALTA.

   El marcador bot contra bot no sirve para esto. Da 50% haga lo que
   haga: dos bots igual de malos se reparten las partidas, y la jugada
   CORRECTA a veces mide peor que la codiciosa porque el rival tampoco
   te castiga por regalar cartas. Lleva toda la sesión pasando: cada
   tanda de cambios mide 49-52% contra la anterior, suba o baje la
   calidad de juego.

   Esto es lo que usan los motores de ajedrez desde los 80: un conjunto
   de posiciones fijas con la jugada buena conocida, y una nota. Aquí
   cada posición sale de un misplay REAL —los logs de E y los reportes
   de la gente de Reddit—, no de lo que a mí me parezca.

   Uso:
     node banco.mjs                       el cerebro actual
     node banco.mjs /tmp/viejo/…/browser  para comparar dos versiones
     node banco.mjs --fallos              solo lo que falla

   Cada posición vale 1 punto si acierta, 0.5 si hace algo aceptable y
   0 si no. La nota es sobre 100 y se desglosa por familia, porque lo
   interesante no es el total sino DÓNDE falla.
   ════════════════════════════════════════════════════════════════ */
import { mesa, ref, cod, L, P, MT, R, IA, BA, X, DB, NOMBRES,
         preguntaIdle, preguntaBatalla, preguntaCadena, preguntaObjetivo,
         preguntaSiNo, queHizo } from "./banco-tablero.mjs";

/* OJO: process.argv[0] es la ruta de node y empieza por "/", así que
   buscar "el primer argumento que parezca una ruta" cogía /usr/bin/node.
   Los argumentos de verdad empiezan en el índice 2. */
const ruta = process.argv.slice(2).find(a=>!a.startsWith("--")) ?? "./src/ai/brain.js";
const destino = ruta.endsWith(".js") ? ruta : ruta.replace(/\/$/,"")+"/src/ai/brain.js";
const { crearCerebro } = await import(destino);
const soloFallos = process.argv.includes("--fallos");

const FICHA = 73915052;      // Sheep Token
const pensar = (duel, nivel="experto") =>
  crearCerebro({ X, duel, db:DB, names:NOMBRES, nivel, yo:0 });

/* ── el catálogo ──
   familia · qué situación es · el tablero · la pregunta · cómo se puntúa.
   `bien` devuelve 1, `regular` 0.5, cualquier otra cosa 0.
   `de` es de dónde salió: log de E, reporte de Reddit, o guía. */
const POSICIONES = [];
const pos = (familia, titulo, de, montar) => POSICIONES.push({familia, titulo, de, montar});

/* ══════════════ 1. NO DISPARARSE EN EL PIE ══════════════
   La familia más numerosa y la que más se reporta. */

pos("no dispararse en el pie", "Heavy Storm con su propia Snatch Steal puesta",
    "reporte de E", () => {
  const d = mesa({ mios:{ mano:["Heavy Storm"], mt:[{carta:"Snatch Steal", pos:P.ATK}],
                          campo:["Airknight Parshath"] },
                   suyos:{ mt:["Sakuretsu Armor","Mirror Force"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no dispararse en el pie", "Heavy Storm sin nada propio que perder",
    "control: no puede quedarse mudo", () => {
  const d = mesa({ mios:{ mano:["Heavy Storm"], campo:["Airknight Parshath"] },
                   suyos:{ mt:["Sakuretsu Armor","Mirror Force","Torrential Tribute"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

/* ══ EL CASO DE PEGASUS, SACADO DEL LOG DE E ══
   `[328029ms] T8 rival · {"msg":"activar Heavy Storm","puntos":1.3}` — con
   tres mágicas suyas colocadas y una sola del rival. La heurística vieja
   contaba CARTAS ("¿tiene el rival backrow? pues adelante"); ahora compara
   VALOR, y volarse tres por una no sale a cuenta. */
pos("no dispararse en el pie", "Heavy Storm con tres cartas propias contra una del rival",
    "log de E contra Pegasus, T8", () => {
  const d = mesa({ mios:{ mano:["Heavy Storm"],
                          mt:["Sakuretsu Armor","Solemn Judgment","Book of Moon"] },
                   suyos:{ mt:["Sakuretsu Armor"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

/* Y el reverso, para que no se quede muda: tres suyas contra una mía sí
   es una tormenta buena. Un veto sin su contraejemplo acaba en una IA que
   nunca juega la carta. */
pos("no dispararse en el pie", "Heavy Storm con una propia contra tres del rival",
    "control del caso anterior", () => {
  const d = mesa({ mios:{ mano:["Heavy Storm"], mt:["Book of Moon"] },
                   suyos:{ mt:["Sakuretsu Armor","Solemn Judgment","Mirror Force"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("no dispararse en el pie", "MST sin backrow rival: el único objetivo es el suyo",
    "AyeRye, Reddit", () => {
  const d = mesa({ mios:{ mt:["Mystical Space Typhoon","Torrential Tribute"] },
                   suyos:{}, turnPlayer:1 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no dispararse en el pie", "Skull Lair con el rival sin monstruos",
    "log de E, partida 6", () => {
  const d = mesa({ mios:{ mt:["Skull Lair"], campo:["Airknight Parshath"],
                          gy:["Sangan","Magician of Faith"] },
                   suyos:{ mt:["Mirror Force"] }, turnPlayer:1 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no dispararse en el pie", "Raigeki Break sin nada del rival",
    "log de E, partida 2", () => {
  const d = mesa({ mios:{ mt:["Raigeki Break"], mano:["Sangan"],
                          campo:["Airknight Parshath"] },
                   suyos:{}, turnPlayer:1 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no dispararse en el pie", "Torrential Tribute sobre su propia invocación",
    "reporte de E", () => {
  const d = mesa({ mios:{ mt:["Torrential Tribute"],
                          campo:["Airknight Parshath","Breaker the Magical Warrior"] },
                   suyos:{ campo:["Sangan"] }, turnPlayer:0 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no dispararse en el pie", "Solemn Judgment sobre su propia carta",
    "log del 10 de agosto", () => {
  const d = mesa({ mios:{ mt:["Solemn Judgment"] }, turnPlayer:0 });
  d.cadena = [{ code:cod("Trap Dustshoot"), controller:0, uid:999 }];
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no dispararse en el pie", "Ring of Destruction que también le mata a él",
    "log de E, partida 6", () => {
  const d = mesa({ mios:{ mano:["Ring of Destruction"] },
                   suyos:{ campo:["Airknight Parshath"] }, lp:[1500,1500] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no dispararse en el pie", "destruir M/T elige la del rival aunque la suya valga más",
    "reporte de E", () => {
  const d = mesa({ mios:{ mt:[{carta:"Snatch Steal", pos:P.ATK}] },
                   suyos:{ mt:[{carta:"Sakuretsu Armor", pos:P.ATK}] } });
  return { d, q: preguntaObjetivo([d.zones[0][L.SZONE][0], d.zones[1][L.SZONE][0]]),
           bien: r => r?.indicies?.[0] === 1 };
});

pos("no dispararse en el pie", "Book of Moon ya puesta y solo su monstruo como objetivo",
    "reporte de E", () => {
  const d = mesa({ mios:{ mt:["Book of Moon"],
                          campo:["Dekoichi the Battlechanted Locomotive"] },
                   suyos:{ campo:[{carta:"Magician of Faith", pos:P.TAPADA}] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.SZONE][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no dispararse en el pie", "Book of Moon encadenada a su propia invocación",
    "escáner: 234 veces en 300 partidas", () => {
  const d = mesa({ mios:{ mt:["Book of Moon"], campo:["Asura Priest"] },
                   suyos:{}, turnPlayer:0 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

/* ══════════════ 2. NO MALGASTAR ══════════════ */

pos("no malgastar", "Snatch Steal sobre una ficha de Scapegoat",
    "reporte de E", () => {
  const d = mesa({ mios:{ mano:["Snatch Steal"] }, suyos:{} });
  d.zones[1][L.MZONE][0] = { uid:900, code:FICHA, controller:1,
                             location:L.MZONE, sequence:0, position:P.ATK };
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Snatch Steal sobre un Airknight sí vale",
    "control", () => {
  const d = mesa({ mios:{ mano:["Snatch Steal"] },
                   suyos:{ campo:["Airknight Parshath"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("no malgastar", "remoción sobre una ficha",
    "reporte de E", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground"] }, suyos:{} });
  d.zones[1][L.MZONE][0] = { uid:901, code:FICHA, controller:1,
                             location:L.MZONE, sequence:0, position:P.ATK };
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "remoción sobre un muro de 2000 en defensa",
    "goatformat: los muros se comen tu remoción", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground"] },
                   suyos:{ campo:[{carta:"Gravekeeper's Spy", pos:P.DEF}] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Thunder Dragon sin copias en el mazo",
    "reporte de E", () => {
  const d = mesa({ mios:{ mano:["Thunder Dragon"],
                          gy:["Thunder Dragon","Thunder Dragon"] },
                   mazoMio:["Thunder Dragon","Thunder Dragon","Thunder Dragon"] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]],
                                coloca:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Thunder Dragon con copias sí se activa",
    "control", () => {
  const d = mesa({ mios:{ mano:["Thunder Dragon"] },
                   mazoMio:["Thunder Dragon","Thunder Dragon","Thunder Dragon"] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]],
                                coloca:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Sakuretsu Armor contra un atacante de 300",
    "goatformat: guárdala para lo que duele", () => {
  const d = mesa({ mios:{ mt:["Sakuretsu Armor"] },
                   suyos:{ campo:["Sinister Serpent"] }, turnPlayer:1, fase:0x10 });
  const atk = d.zones[1][L.MZONE][0];
  d.atacante = { uid:atk.uid, code:atk.code, controller:1 };
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no malgastar", "Sakuretsu Armor contra un Airknight sí",
    "control", () => {
  const d = mesa({ mios:{ mt:["Sakuretsu Armor"] },
                   suyos:{ campo:["Airknight Parshath"] }, turnPlayer:1, fase:0x10 });
  const atk = d.zones[1][L.MZONE][0];
  d.atacante = { uid:atk.uid, code:atk.code, controller:1 };
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index === 0 };
});

pos("no malgastar", "Solemn Judgment: media vida por un Book of Moon",
    "goatformat: solo por lo que decide la partida", () => {
  const d = mesa({ mios:{ mt:["Solemn Judgment"] }, turnPlayer:1 });
  d.cadena = [{ code:cod("Book of Moon"), controller:1, uid:999 }];
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("no malgastar", "Solemn Judgment sí por un Black Luster Soldier",
    "control", () => {
  const d = mesa({ mios:{ mt:["Solemn Judgment"] }, turnPlayer:1 });
  d.cadena = [{ code:cod("Black Luster Soldier - Envoy of the Beginning"),
                controller:1, uid:999 }];
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index === 0 };
});

pos("no malgastar", "Hand of Nephthys con el Phoenix ya en el campo",
    "TheBlackbird95, Reddit", () => {
  const d = mesa({ mios:{ mt:[{carta:"Hand of Nephthys", pos:P.ATK}],
                          campo:["Magician of Faith","Sacred Phoenix of Nephthys"] },
                   mazoMio:["Sacred Phoenix of Nephthys"] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.SZONE][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Premature Burial por un monstruo de 300 de ataque",
    "goatformat: reanimar basura es tirar la carta", () => {
  const d = mesa({ mios:{ mano:["Premature Burial"], gy:["Magician of Faith"] },
                   suyos:{ campo:["Airknight Parshath"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

/* ══════════════ 3. COMBATE ══════════════ */

const ataqueContra = (mio, suyo, extra={}) => () => {
  const d = mesa({ mios:{ campo:[mio] }, suyos:{ campo:[suyo] }, ...extra });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]) };
};

pos("combate", "no ataca a Spirit Reaper, que no muere en combate",
    "goatformat", () => ({ ...ataqueContra("Airknight Parshath","Spirit Reaper")(),
      bien: r => r?.action !== BA.SELECT_BATTLE }));

pos("combate", "no se lanza contra D.D. Warrior Lady",
    "goatformat: destierra a los dos", () => ({
      ...ataqueContra("Airknight Parshath","D.D. Warrior Lady")(),
      bien: r => r?.action !== BA.SELECT_BATTLE }));

pos("combate", "sí ataca a un Breaker de 1600",
    "control", () => ({ ...ataqueContra("Airknight Parshath","Breaker the Magical Warrior")(),
      bien: r => r?.action === BA.SELECT_BATTLE }));

pos("combate", "sí ataca a una Gravekeeper's Spy boca arriba EN ATAQUE",
    "medido: marcarla como peligrosa costaba 2 puntos", () => ({
      ...ataqueContra("Airknight Parshath",{carta:"Gravekeeper's Spy", pos:P.ATK})(),
      bien: r => r?.action === BA.SELECT_BATTLE }));

pos("combate", "no ataca a una Spy de 2000 en DEFENSA",
    "mx4WAYNE_styles, Reddit", () => ({
      ...ataqueContra("Airknight Parshath",{carta:"Gravekeeper's Spy", pos:P.DEF})(),
      bien: r => r?.action !== BA.SELECT_BATTLE }));

pos("combate", "Thousand-Eyes Restrict ataca con lo que ha absorbido",
    "reporte de E: no atacaba nunca con él", () => {
  const d = mesa({ mios:{ campo:[{carta:"Thousand-Eyes Restrict", atkReal:1900, defReal:1500}] },
                   suyos:{ campo:["Magician of Faith"] } });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("combate", "…y sin absorber nada no se suicida",
    "control", () => {
  const d = mesa({ mios:{ campo:[{carta:"Thousand-Eyes Restrict", atkReal:0, defReal:0}] },
                   suyos:{ campo:["Airknight Parshath"] } });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action !== BA.SELECT_BATTLE };
});

pos("combate", "ataca primero con el grande para forzarle el Scapegoat",
    "goatformat, 40 common mistakes", () => {
  const d = mesa({ mios:{ campo:["Airknight Parshath","Sinister Serpent"] }, suyos:{} });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0], d.zones[0][L.MZONE][1]]),
           bien: r => r?.action===BA.SELECT_BATTLE && r?.index===0,
           regular: r => r?.action===BA.SELECT_BATTLE };
});

pos("combate", "D.D. Warrior Lady no se destierra ganando limpio",
    "log de E, partida 4", () => {
  const d = mesa({ mios:{ campo:["D.D. Warrior Lady"] },
                   suyos:{ campo:["Magician of Faith"] } });
  return { d, q: preguntaSiNo(cod("D.D. Warrior Lady")), bien: r => r?.yes === false };
});

pos("combate", "…pero sí contra un Black Luster Soldier",
    "control", () => {
  const d = mesa({ mios:{ campo:["D.D. Warrior Lady"] },
                   suyos:{ campo:["Black Luster Soldier - Envoy of the Beginning"] } });
  return { d, q: preguntaSiNo(cod("D.D. Warrior Lady")), bien: r => r?.yes === true };
});

/* ══════════════ 4. TEMPO Y POSICIÓN ══════════════ */

pos("tempo", "no invoca de frente delante de algo más grande",
    "reporte de E", () => {
  const d = mesa({ mios:{ mano:["Dekoichi the Battlechanted Locomotive"] },
                   suyos:{ campo:["Airknight Parshath"] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action === IA.SELECT_MONSTER_SET };
});

pos("tempo", "una ficha de Scapegoat nunca pasa a ataque",
    "reporte de E", () => {
  const d = mesa({ mios:{}, suyos:{} });
  d.zones[0][L.MZONE][0] = { uid:910, code:FICHA, controller:0,
                             location:L.MZONE, sequence:0, position:P.DEF };
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]] }),
           bien: r => r?.action !== IA.SELECT_POS_CHANGE };
});

pos("tempo", "no invoca Asura Priest en un turno sin Battle Phase",
    "TheBlackbird95, Reddit", () => {
  const d = mesa({ mios:{ mano:["Asura Priest"] }, suyos:{} });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c], bp:false }),
           bien: r => r?.action !== IA.SELECT_SUMMON };
});

pos("tempo", "con Battle Phase y campo vacío sí lo invoca",
    "control", () => {
  const d = mesa({ mios:{ mano:["Asura Priest"] }, suyos:{} });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c], bp:true }),
           bien: r => r?.action === IA.SELECT_SUMMON };
});

pos("tempo", "Scapegoat no se quema en la Main Phase 1 del rival",
    "goatformat: encadénala en la End Phase", () => {
  const d = mesa({ mios:{ mt:["Scapegoat"] }, turnPlayer:1, fase:0x4 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]), bien: r => r?.index == null };
});

pos("tempo", "Scapegoat sí en la End Phase del rival",
    "control", () => {
  const d = mesa({ mios:{ mt:["Scapegoat"] }, turnPlayer:1, fase:0x200 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]), bien: r => r?.index === 0 };
});

/* ══════════════ 5. A QUÉ APUNTAR PRIMERO ══════════════ */

pos("prioridades", "la remoción va al Jinzo antes que al Airknight",
    "goatformat: los candados primero", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground"] },
                   suyos:{ campo:["Jinzo","Airknight Parshath"] } });
  return { d, q: preguntaObjetivo(d.zones[1][L.MZONE].filter(Boolean)),
           bien: r => r?.indicies?.[0] === 0 };
});

pos("prioridades", "Breaker rompe el Premature Burial, no una tapada cualquiera",
    "log de E, partida 6, turno 12", () => {
  const d = mesa({ mios:{ campo:["Breaker the Magical Warrior"] },
                   suyos:{ mt:[{carta:"Premature Burial", pos:P.ATK},
                               {carta:"Sakuretsu Armor", pos:P.TAPADA}],
                           campo:["Jinzo"] } });
  return { d, q: preguntaObjetivo(d.zones[1][L.SZONE].filter(Boolean)),
           bien: r => r?.indicies?.[0] === 0 };
});

pos("prioridades", "Thousand-Eyes absorbe el mayor, no una tapada",
    "check-cartas: tapado se queda con 0 de ataque", () => {
  const d = mesa({ mios:{ campo:["Thousand-Eyes Restrict"] },
                   suyos:{ campo:[{carta:"Magician of Faith", pos:P.TAPADA},
                                  "Airknight Parshath"] } });
  return { d, q: preguntaObjetivo(d.zones[1][L.MZONE].filter(Boolean)),
           bien: r => r?.indicies?.[0] === 1 };
});

pos("prioridades", "no descarta la carta con la que gana la partida",
    "guías de mazo: las claves no son coste", () => {
  const d = mesa({ mios:{ mano:["Black Luster Soldier - Envoy of the Beginning",
                                "Sinister Serpent"] },
                   mazoMio:["Scapegoat","Metamorphosis","Tsukuyomi","Scapegoat"] });
  return { d, q: { type:MT.SELECT_CARD, player:0, can_cancel:false, min:1, max:1,
                   selects: d.zones[0][L.HAND].map(ref) },
           bien: r => r?.indicies?.[0] === 1 };
});

/* ══════════════ 6. REMATAR ══════════════ */

pos("rematar", "Ring of Destruction remata cuando solo le mata a él",
    "control", () => {
  const d = mesa({ mios:{ mano:["Ring of Destruction"] },
                   suyos:{ campo:["Airknight Parshath"] }, lp:[8000,1500] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("rematar", "con el rival a 1200 y un 1900 delante, quita el bloqueador",
    "reporte de E: guardaba la remoción", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground"], campo:["Airknight Parshath"] },
                   suyos:{ campo:["Breaker the Magical Warrior"] }, lp:[8000,1200] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

/* ══════════════ 7. LAS QUE NO HE PROGRAMADO ══════════════
   Las de arriba salen de misplays ya arreglados: son una red de
   seguridad, no un examen. Estas son decisiones de Goat sacadas de las
   guías para las que NO hay ningún caso escrito en el cerebro. Aquí es
   donde se ve de verdad si juega o si acierta de memoria. Que fallen
   varias es lo esperado y es el trabajo que queda. */

/* OJO: aquí puse Breaker y la posición estaba mal planteada. Breaker
   rompe una tapada al invocarse, así que contra dos M/T colocadas es
   justo lo que hay que hacer. Con un cuerpo sin efecto sí aplica la
   regla de no sobreextender. */
pos("sin programar", "no invoca en un campo lleno con dos tapadas suyas sin ver Torrential",
    "goatformat: no le regales el Torrential", () => {
  const d = mesa({ mios:{ mano:["Berserk Gorilla"],
                          campo:["Airknight Parshath","Asura Priest"] },
                   suyos:{ mt:[{carta:"Torrential Tribute"},{carta:"Mirror Force"}] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action !== IA.SELECT_SUMMON };
});

pos("sin programar", "Graceful Charity sin descarte gratis: mejor esperar",
    "goatformat: guárdala para el Sinister Serpent", () => {
  const d = mesa({ mios:{ mano:["Graceful Charity","Airknight Parshath",
                                "Black Luster Soldier - Envoy of the Beginning"] },
                   /* El mazo importa: sin una lista reconocible, el plan es
                      "Beatdown sin piezas" y cavar SÍ es lo correcto. Con un
                      Goat Control de verdad, la guía dice guardarla. */
                   mazoMio:["Scapegoat","Scapegoat","Metamorphosis","Metamorphosis",
                            "Tsukuyomi","Tsukuyomi","Sangan","Magician of Faith"], turno:2 });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("sin programar", "Metamorphosis gasta la ficha, no el Airknight",
    "goatformat: la ficha es el combustible", () => {
  const d = mesa({ mios:{ campo:["Airknight Parshath"] },
                   suyos:{ campo:["Jinzo"] } });
  d.zones[0][L.MZONE][1] = { uid:920, code:FICHA, controller:0,
                             location:L.MZONE, sequence:1, position:P.DEF };
  return { d, q: { type:MT.SELECT_CARD, player:0, can_cancel:false, min:1, max:1,
                   selects: d.zones[0][L.MZONE].filter(Boolean).map(ref) },
           bien: r => r?.indicies?.[0] === 1 };
});

pos("sin programar", "Scapegoat en respuesta a un ataque, no solo en la End Phase",
    "goatformat: corta el ataque", () => {
  const d = mesa({ mios:{ mt:["Scapegoat"] },
                   suyos:{ campo:["Airknight Parshath"] }, turnPlayer:1, fase:0x10 });
  const atk = d.zones[1][L.MZONE][0];
  d.atacante = { uid:atk.uid, code:atk.code, controller:1 };
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]), bien: r => r?.index === 0 };
});

pos("sin programar", "Book of Moon corta el ataque del monstruo grande",
    "goatformat: su uso principal", () => {
  const d = mesa({ mios:{ mt:["Book of Moon"], campo:["Magician of Faith"] },
                   suyos:{ campo:["Black Luster Soldier - Envoy of the Beginning"] },
                   turnPlayer:1, fase:0x10 });
  const atk = d.zones[1][L.MZONE][0];
  d.atacante = { uid:atk.uid, code:atk.code, controller:1 };
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]), bien: r => r?.index === 0 };
});

pos("sin programar", "no ataca con todo teniendo él dos tapadas y yendo por delante",
    "goatformat: no te comas el Mirror Force", () => {
  const d = mesa({ mios:{ campo:["Airknight Parshath","Asura Priest",
                                 "Breaker the Magical Warrior"] },
                   suyos:{ mt:[{carta:"Mirror Force"},{carta:"Sakuretsu Armor"}] },
                   lp:[8000,7000] });
  const r0 = d.zones[0][L.MZONE].filter(Boolean);
  return { d, q: preguntaBatalla(r0),
           bien: r => r?.action===BA.SELECT_BATTLE && r?.index===0,
           regular: r => r?.action !== BA.SELECT_BATTLE };
});

pos("sin programar", "Sinister Serpent se queda en la mano, no se coloca",
    "goatformat: vale más en la mano", () => {
  const d = mesa({ mios:{ mano:["Sinister Serpent"] },
                   suyos:{ campo:["Airknight Parshath"] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action !== IA.SELECT_MONSTER_SET && r?.action !== IA.SELECT_SUMMON };
});

pos("sin programar", "Nobleman of Crossout va a la tapada, no se guarda",
    "goatformat: destierra a los flip", () => {
  const d = mesa({ mios:{ mano:["Nobleman of Crossout"] },
                   suyos:{ campo:[{carta:"Magician of Faith", pos:P.TAPADA}] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("sin programar", "ataca directo con el campo rival vacío",
    "lo más básico", () => {
  const d = mesa({ mios:{ campo:["Airknight Parshath"] }, suyos:{} });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("sin programar", "Tsukuyomi tumba al monstruo grande del rival",
    "goatformat: apaga y prepara el Nobleman", () => {
  const d = mesa({ mios:{ mano:["Tsukuyomi"] },
                   suyos:{ campo:["Black Luster Soldier - Envoy of the Beginning"] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action === IA.SELECT_SUMMON };
});

pos("sin programar", "no tributa el Airknight teniendo una ficha",
    "goatformat: los tributos salen de lo barato", () => {
  const d = mesa({ mios:{ campo:["Airknight Parshath"] } });
  d.zones[0][L.MZONE][1] = { uid:921, code:FICHA, controller:0,
                             location:L.MZONE, sequence:1, position:P.DEF };
  return { d, q: { type:MT.SELECT_TRIBUTE, player:0, can_cancel:false, min:1, max:1,
                   selects: d.zones[0][L.MZONE].filter(Boolean).map(c=>({...ref(c), release_param:1})) },
           bien: r => r?.indicies?.[0] === 1 };
});

pos("sin programar", "Delinquent Duo en el turno 1 con la mano llena",
    "goatformat: el mejor momento es pronto", () => {
  const d = mesa({ mios:{ mano:["Delinquent Duo"] }, suyos:{}, turno:2 });
  d.zones[1][L.HAND] = ["Sangan","Sangan","Sangan","Sangan","Sangan"].map((n,i)=>
    ({ uid:930+i, code:cod(n), controller:1, location:L.HAND, sequence:i, position:1 }));
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

/* ══════════════ 8. ELEGIR ENTRE VARIAS JUGADAS BUENAS ══════════════
   Aquí es donde las constantes se rompen. Las familias de arriba
   preguntan "¿juego esta carta o no?", y para eso basta un umbral. Estas
   preguntan "¿CUÁL primero?", y para responder hay que poder comparar
   cosas distintas —robar dos cartas contra matarle un 1900— en la misma
   moneda. Es justo lo que no se puede hacer con un número inventado por
   acción, y para lo que existe `valorar.js`. */

pos("elegir la mejor", "Pot of Greed antes de comprometer nada",
    "goatformat: roba primero, decides con más información", () => {
  const d = mesa({ mios:{ mano:["Pot of Greed","Smashing Ground"],
                          campo:["Airknight Parshath"] },
                   suyos:{ campo:["Breaker the Magical Warrior"] },
                   mazoMio:["Scapegoat","Metamorphosis","Tsukuyomi","Scapegoat","Sangan"] });
  const [pot, smash] = d.zones[0][L.HAND];
  return { d, q: preguntaIdle({ activa:[pot, smash] }),
           bien: r => r?.action===IA.SELECT_ACTIVATE && r?.index===0,
           regular: r => r?.action===IA.SELECT_ACTIVATE };
});

pos("elegir la mejor", "Snatch Steal antes que Smashing Ground sobre el mismo gordo",
    "robar es +1, destruir es 1-por-1", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground","Snatch Steal"] },
                   suyos:{ campo:["Black Luster Soldier - Envoy of the Beginning"] } });
  const [smash, snatch] = d.zones[0][L.HAND];
  return { d, q: preguntaIdle({ activa:[smash, snatch] }),
           bien: r => r?.action===IA.SELECT_ACTIVATE && r?.index===1,
           regular: r => r?.action===IA.SELECT_ACTIVATE };
});

pos("elegir la mejor", "Heavy Storm antes de invocar, no después",
    "goatformat: limpia el Torrential primero", () => {
  const d = mesa({ mios:{ mano:["Heavy Storm","Berserk Gorilla"] },
                   suyos:{ mt:["Torrential Tribute","Mirror Force","Sakuretsu Armor"] } });
  const [storm, gorila] = d.zones[0][L.HAND];
  return { d, q: preguntaIdle({ activa:[storm], invoca:[gorila], coloca:[gorila] }),
           bien: r => r?.action===IA.SELECT_ACTIVATE };
});

pos("elegir la mejor", "con el rival a 1000 y campo vacío, a la batalla",
    "no hay nada que preparar: se acaba ya", () => {
  const d = mesa({ mios:{ mano:["Pot of Greed"], campo:["Airknight Parshath"] },
                   suyos:{}, lp:[8000,1000],
                   mazoMio:["Scapegoat","Metamorphosis","Tsukuyomi"] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action===IA.TO_BP,
           regular: r => r?.action===IA.SELECT_ACTIVATE };
});

pos("elegir la mejor", "quitar el monstruo grande antes que el pequeño",
    "la remoción va a lo que más duele", () => {
  const d = mesa({ mios:{ mano:["Smashing Ground"] },
                   suyos:{ campo:["Sinister Serpent",
                                  "Black Luster Soldier - Envoy of the Beginning"] } });
  return { d, q: preguntaObjetivo(d.zones[1][L.MZONE].filter(Boolean)),
           bien: r => r?.indicies?.[0] === 1 };
});

pos("elegir la mejor", "Delinquent Duo antes que Graceful sin descarte",
    "goatformat: Duo pronto, Graceful cuando haya con qué", () => {
  const d = mesa({ mios:{ mano:["Delinquent Duo","Graceful Charity",
                                "Airknight Parshath","Breaker the Magical Warrior"] },
                   suyos:{}, turno:2,
                   mazoMio:["Scapegoat","Scapegoat","Metamorphosis","Metamorphosis",
                            "Tsukuyomi","Tsukuyomi","Sangan","Magician of Faith"] });
  d.zones[1][L.HAND] = ["Sangan","Sangan","Sangan","Sangan","Sangan"].map((n,i)=>
    ({ uid:940+i, code:cod(n), controller:1, location:L.HAND, sequence:i, position:1 }));
  const [duo, graceful] = d.zones[0][L.HAND];
  return { d, q: preguntaIdle({ activa:[duo, graceful] }),
           bien: r => r?.action===IA.SELECT_ACTIVATE && r?.index===0 };
});

pos("elegir la mejor", "no cambia un Black Luster por un 1900",
    "guías: las piezas de victoria no se cambian", () => {
  const d = mesa({ mios:{ campo:["Black Luster Soldier - Envoy of the Beginning"] },
                   suyos:{ campo:["Airknight Parshath"] },
                   mazoMio:["Scapegoat","Scapegoat","Metamorphosis","Metamorphosis",
                            "Tsukuyomi","Tsukuyomi"] });
  /* 3000 contra 1900: le gana. Debe atacar. El control es que la regla de
     "no cambies tus piezas" no se pase de frenada. */
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("elegir la mejor", "prefiere el objetivo que le deja sin plan",
    "goatformat: los candados primero", () => {
  const d = mesa({ mios:{ mano:["Mystical Space Typhoon"] },
                   suyos:{ mt:[{carta:"Sakuretsu Armor", pos:P.ATK},
                               {carta:"Snatch Steal", pos:P.ATK}] } });
  return { d, q: preguntaObjetivo(d.zones[1][L.SZONE].filter(Boolean)),
           bien: r => r?.indicies?.[0] === 1 };
});

/* ══════════════ 9. LAS NUEVE PARTIDAS DEL 15 DE AGOSTO ══════════════
   Cada una es un misplay que E describió jugando, con la jugada que él
   habría hecho. Son las más valiosas del banco: vienen con la alternativa
   correcta, no solo con "esto está mal". */

pos("partidas del 15", "un monstruo robado tiene que atacar: al acabar el turno se va",
    "partida 1, turnos 5 y 8", () => {
  /* Mind Control roba hasta la End Phase. Si no lo usas, se lo devuelves
     intacto: hay que meterlo en combate aunque muera. */
  const d = mesa({ mios:{ campo:["Thunder Dragon"] },
                   suyos:{ campo:["Breaker the Magical Warrior"] },
                   mazoMio:["Scapegoat","Metamorphosis","Tsukuyomi"] });
  d.decklist = { 0:[cod("Scapegoat"),cod("Metamorphosis")], 1:[cod("Thunder Dragon")] };
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("partidas del 15", "Thousand-Eyes Restrict sin nada boca arriba que absorber",
    "partidas 2 y 8: se activaba con un 3.0 fijo", () => {
  const d = mesa({ mios:{ campo:["Thousand-Eyes Restrict"] },
                   suyos:{ campo:[{carta:"Magician of Faith", pos:P.TAPADA}] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.MZONE][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("partidas del 15", "…pero con un monstruo grande boca arriba, sí",
    "control", () => {
  const d = mesa({ mios:{ campo:["Thousand-Eyes Restrict"] },
                   suyos:{ campo:["Black Luster Soldier - Envoy of the Beginning"] } });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.MZONE][0]] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE };
});

pos("partidas del 15", "Dust Tornado sobre una mágica que ya se está resolviendo",
    "partidas 6 y 8: destruirla no la niega", () => {
  const d = mesa({ mios:{ mt:["Dust Tornado"] },
                   suyos:{ mt:[{carta:"Nobleman of Crossout", pos:P.ATK}] },
                   turnPlayer:1 });
  d.cadena = [{ code:cod("Nobleman of Crossout"), controller:1, uid:998 }];
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("partidas del 15", "…pero sobre una Snatch Steal ya puesta, sí",
    "control: ahí sí quita algo", () => {
  const d = mesa({ mios:{ mt:["Dust Tornado"] },
                   suyos:{ mt:[{carta:"Snatch Steal", pos:P.ATK}] },
                   turnPlayer:1 });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index === 0 };
});

pos("partidas del 15", "no activa un segundo Wall of Revealing Light",
    "partida 9, turno 10: una basta y cuesta 1000 más", () => {
  const d = mesa({ mios:{ mano:["Wall of Revealing Light"],
                          mt:[{carta:"Wall of Revealing Light", pos:P.ATK}] },
                   suyos:{ campo:["Airknight Parshath"] }, lp:[5000,8000] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]],
                                colocaMT:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("partidas del 15", "Spirit Reaper va en defensa, no en ataque",
    "partida 4: en ataque le regalas daño gratis", () => {
  const d = mesa({ mios:{ campo:[{carta:"Spirit Reaper", pos:P.ATK}] },
                   suyos:{ campo:["Airknight Parshath"] } });
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]] }),
           bien: r => r?.action === IA.SELECT_POS_CHANGE };
});

pos("partidas del 15", "ataca con lo que le gana a lo que ya ha visto",
    "partida 5, turnos 7 y 10: no atacó con Wicked Worm Beast", () => {
  const d = mesa({ mios:{ campo:["The Wicked Worm Beast"] },
                   suyos:{ campo:[{carta:"Magician of Faith", pos:P.ATK}] } });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("partidas del 15", "Ring of Destruction se guarda si no hace falta ya",
    "partida 7, turno 7: iba por delante y la gastó", () => {
  const d = mesa({ mios:{ mano:["Ring of Destruction"],
                          campo:["Airknight Parshath","Asura Priest"] },
                   suyos:{ campo:["Magician of Faith"] }, lp:[8000,8000] });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.HAND][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("partidas del 15", "Book of Moon no se gasta en un monstruo pequeño",
    "partida 9, turnos 13 y 23", () => {
  const d = mesa({ mios:{ mt:["Book of Moon"], campo:["Airknight Parshath"] },
                   suyos:{ campo:["Sinister Serpent"] }, turnPlayer:1, fase:0x10 });
  const atk = d.zones[1][L.MZONE][0];
  d.atacante = { uid:atk.uid, code:atk.code, controller:1 };
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

/* ══════════════ 10. LAS DIEZ PARTIDAS DEL 18 DE AGOSTO ══════════════
   Diez logs seguidos con sus turnos señalados. No son quince casos
   sueltos: son SIETE sistemas, y cada posición de aquí abajo dice a cuál
   pertenece. Si mañana alguien toca uno, esto dice cuál se rompió.
   ═══════════════════════════════════════════════════════════════════ */

/* ── A · EL EVALUADOR DE POSICIÓN ──
   Cinco reportes distintos, una sola causa: para agacharse se exigía
   `def > atk`, y Sangan es 1000/600. */
pos("posición", "Sangan de frente contra La Jinn: se agacha",
    "log 18-35-22, turno 5", () => {
  const d = mesa({ mios:{ campo:[{carta:"Sangan (GOAT)", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"La Jinn the Mystical Genie of the Lamp", pos:P.ATK}] } });
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]], bp:false }),
           bien: r => r?.action === IA.SELECT_POS_CHANGE };
});

pos("posición", "Spirit Reaper no se queda en ataque cobrando daño",
    "log 19-30-16, turnos 1 y 5", () => {
  const d = mesa({ mios:{ campo:[{carta:"Spirit Reaper (GOAT)", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] } });
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]], bp:false }),
           bien: r => r?.action === IA.SELECT_POS_CHANGE };
});

pos("posición", "Gearfried delante de un 3000: a defensa",
    "nota de E sin log", () => {
  const d = mesa({ mios:{ campo:[{carta:"Gearfried the Iron Knight (GOAT)", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Blue-Eyes White Dragon", pos:P.ATK}] } });
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]], bp:false }),
           bien: r => r?.action === IA.SELECT_POS_CHANGE };
});

/* Y su contraejemplo: un veto sin contraejemplo acaba en una IA que se
   pasa la partida agachada. Si gana el combate, se queda de frente. */
pos("posición", "pero si gana el combate se queda de frente",
    "control del caso anterior", () => {
  const d = mesa({ mios:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Sangan (GOAT)", pos:P.ATK}] } });
  return { d, q: preguntaIdle({ giros:[d.zones[0][L.MZONE][0]], bp:false }),
           bien: r => r?.action !== IA.SELECT_POS_CHANGE };
});

/* ── B · CARTAS QUE QUIEREN ENTRAR BOCA ABAJO ── */
pos("posición", "Man-Eater Bug se coloca, no se invoca de frente",
    "log 18-35-22, turno 16", () => {
  const d = mesa({ mios:{ mano:["Man-Eater Bug"] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action === IA.SELECT_MONSTER_SET };
});

pos("posición", "Black Dragon's Chick tampoco entra de frente",
    "log 21-12-59, turno 5", () => {
  const d = mesa({ mios:{ mano:["Black Dragon's Chick"] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] } });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], coloca:[c] }),
           bien: r => r?.action === IA.SELECT_MONSTER_SET };
});

/* ── C · REACTIVAS CON CONDICIÓN, NO CON VENTANA ── */
pos("no malgastar", "Waboku no se activa en tu propia Main Phase",
    "logs 18-20-40 T6 y 21-12-59 T21", () => {
  const d = mesa({ mios:{ mt:[{carta:"Waboku", pos:P.TAPADA}],
                          campo:[{carta:"Axe Raider", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] },
                   turnPlayer:0 });
  return { d, q: preguntaIdle({ activa:[d.zones[0][L.SZONE][0]] }),
           bien: r => r?.action !== IA.SELECT_ACTIVATE };
});

pos("no malgastar", "Just Desserts por 500 puntos se guarda",
    "log 18-20-40, turno 3", () => {
  const d = mesa({ mios:{ mt:[{carta:"Just Desserts", pos:P.TAPADA}] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK}] },
                   turnPlayer:1, lp:[8000,8000] });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index == null };
});

pos("rematar", "pero Just Desserts que MATA se activa",
    "contraejemplo del anterior", () => {
  const d = mesa({ mios:{ mt:[{carta:"Just Desserts", pos:P.TAPADA}] },
                   suyos:{ campo:[{carta:"Luster Dragon", pos:P.ATK},
                                  {carta:"Battle Ox", pos:P.ATK},
                                  {carta:"Axe Raider", pos:P.ATK}] },
                   turnPlayer:1, lp:[8000,1200] });
  return { d, q: preguntaCadena([d.zones[0][L.SZONE][0]]),
           bien: r => r?.index != null };
});

/* ── D · UNA MÁGICA NORMAL NO SE COLOCA SI SE PUEDE JUGAR ── */
pos("no malgastar", "Reinforcement of the Army se juega, no se coloca",
    "log 21-12-59, turno 1", () => {
  const d = mesa({ mios:{ mano:["Reinforcement of the Army (GOAT)"] } });
  /* OJO: un buscador con el mazo VACÍO no consigue nada, y la IA hace
     bien en no jugarlo. `mesa` no monta el mazo, así que hay que llenarlo
     a mano o el test mide lo contrario de lo que cree medir. */
  d.zones[0][L.DECK].push({ code:cod("Axe Raider"), uid:900, controller:0,
                            location:L.DECK, sequence:0, position:P.TAPADA });
  d.zones[0][L.DECK].push({ code:cod("Battle Ox"), uid:901, controller:0,
                            location:L.DECK, sequence:1, position:P.TAPADA });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ activa:[c], colocaMT:[c] }),
           bien: r => r?.action === IA.SELECT_ACTIVATE,
           regular: r => r?.action !== IA.SELECT_SPELL_SET };
});

/* ── E · EL TRIBUTO TIENE QUE SALIR A CUENTA ── */
pos("tempo", "no tributar Dark Magician por algo peor",
    "log 19-59-23, turno 13", () => {
  const d = mesa({ mios:{ campo:[{carta:"Dark Magician", pos:P.ATK}],
                          mano:["Summoned Skull"] },
                   suyos:{} });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c] }),
           /* Summoned Skull (2500) por Dark Magician (2500) no gana nada
              y encima pierde un cuerpo: cualquier cosa menos invocar. */
           bien: r => r?.action !== IA.SELECT_SUMMON };
});

pos("tempo", "atacar con Goblin Attack Force antes de tributarlo",
    "log 21-12-59, turno 3", () => {
  const d = mesa({ mios:{ campo:[{carta:"Goblin Attack Force", pos:P.ATK}],
                          mano:["Summoned Skull"] },
                   suyos:{} });
  const c = d.zones[0][L.HAND][0];
  return { d, q: preguntaIdle({ invoca:[c], bp:true }),
           /* Con el campo rival vacío, el Goblin de 2300 pega directo: se
              ataca primero y se tributa en la Main Phase 2. */
           bien: r => r?.action !== IA.SELECT_SUMMON };
});

/* ── F · LO QUE YA HE VISTO, LO RECUERDO ──
   Los dos casos opuestos, que es lo que los hace una pareja: la memoria
   tiene que servir para NO atacar y para SÍ atacar. */
pos("combate", "no atacar una defensa que sé que no puedo romper",
    "log 20-08-11, turno 14", () => {
  const d = mesa({ mios:{ campo:[{carta:"Axe Raider", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Giant Soldier of Stone", pos:P.DEF}] } });
  /* Se ve boca arriba una vez —así entra en la memoria— y luego se tapa. */
  const cerebroPrevio = pensar(d);
  cerebroPrevio(preguntaIdle({}), 0);
  d.zones[1][L.MZONE][0].position = P.TAPADA;
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action !== BA.SELECT_BATTLE };
});

pos("combate", "y sí atacar una defensa que sé que sí puedo romper",
    "log 20-13-52, turno 10", () => {
  const d = mesa({ mios:{ campo:[{carta:"Summoned Skull", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Sangan (GOAT)", pos:P.DEF}] } });
  const cerebroPrevio = pensar(d);
  cerebroPrevio(preguntaIdle({}), 0);
  d.zones[1][L.MZONE][0].position = P.TAPADA;
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

/* ── G · ¿PUEDO GANAR ESTE TURNO? ── */
pos("rematar", "con el campo rival vacío y daño de sobra, ataca con todo",
    "log 20-08-11, turno 10", () => {
  const d = mesa({ mios:{ campo:[{carta:"Axe Raider", pos:P.ATK},
                                 {carta:"Battle Ox", pos:P.ATK}] },
                   suyos:{}, lp:[8000, 2000] });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0], d.zones[0][L.MZONE][1]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

/* ── B · ATACAR HACIA ARRIBA CUANDO EL EFECTO LO PAGA ── */
pos("combate", "Hyper Hammerhead ataca hacia arriba para rebotar la amenaza",
    "log 19-33-51, turno 5", () => {
  const d = mesa({ mios:{ campo:[{carta:"Hyper Hammerhead", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Blue-Eyes White Dragon", pos:P.ATK}] },
                   lp:[8000,8000] });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action === BA.SELECT_BATTLE };
});

pos("combate", "pero no se suicida si el rebote no compensa",
    "contraejemplo del anterior", () => {
  const d = mesa({ mios:{ campo:[{carta:"Hyper Hammerhead", pos:P.ATK}] },
                   suyos:{ campo:[{carta:"Blue-Eyes White Dragon", pos:P.ATK}] },
                   lp:[900,8000] });
  return { d, q: preguntaBatalla([d.zones[0][L.MZONE][0]]),
           bien: r => r?.action !== BA.SELECT_BATTLE };
});

/* ══════════════ ejecutar ══════════════ */
const familias = new Map();
const fallos = [];
let total = 0;

for(const P0 of POSICIONES){
  let nota = 0, hizo = "(reventó)";
  try{
    const { d, q, bien, regular } = P0.montar();
    const r = pensar(d)(q, 0);
    hizo = queHizo(r);
    nota = bien?.(r) ? 1 : (regular?.(r) ? 0.5 : 0);
  }catch(e){ hizo = "error: " + e.message; }
  total += nota;
  const f = familias.get(P0.familia) ?? { n:0, de:0 };
  f.n += nota; f.de += 1; familias.set(P0.familia, f);
  if(nota < 1) fallos.push({ ...P0, hizo, nota });
  if(!soloFallos && nota===1) console.log(`  ✓ ${P0.titulo}`);
}

const sobre100 = Math.round(total / POSICIONES.length * 100);
console.log(`\n═══ BANCO DE POSICIONES · ${destino} ═══`);
console.log(`nota: ${sobre100}/100   (${total} de ${POSICIONES.length} posiciones)\n`);
for(const [f, {n, de}] of familias)
  console.log(`  ${String(Math.round(n/de*100)).padStart(3)}%  ${f}  (${n}/${de})`);

if(fallos.length){
  console.log(`\n── falla en ${fallos.length} ──`);
  for(const f of fallos)
    console.log(`  ${f.nota ? "~" : "✗"} ${f.titulo}\n      hizo: ${f.hizo}   ·   de: ${f.de}`);
}
process.exit(0);
