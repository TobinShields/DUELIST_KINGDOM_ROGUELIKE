/* ¿«Ver el tablero» deja salida? Se monta la pantalla final REAL con el
   `onNuevo` del Reino, se pulsa el botón y se comprueba que quede algo
   que pulsar y que llame a `onNuevo`. */
import { readFileSync, writeFileSync } from "node:fs";
import { installDOM } from "./domstub.mjs";
globalThis.GOAT_SEED=1; installDOM();
globalThis.matchMedia=q=>({matches:false,media:q,addListener(){},removeListener(){}});
globalThis.innerWidth=1280;
const mem=new Map();
global.localStorage={getItem:k=>k==="goatConfig"?'{"idioma":"es"}':(mem.get(k)??null),setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)};
const html=readFileSync("./out/goat.html","utf-8");
writeFileSync("./out/_sal.mjs", html.match(/<script type="module">([\s\S]*?)<\/script>/)[1]);
console.warn=()=>{};
await import("./out/_sal.mjs"); await new Promise(r=>setTimeout(r,400));

const V = globalThis.__VIEW_PRUEBA__ ?? null;
console.log("gancho de View:", V ? "sí" : "no");
