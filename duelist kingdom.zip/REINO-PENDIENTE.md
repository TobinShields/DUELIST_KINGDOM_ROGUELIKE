# Reino de los Duelistas — lo que falta

Lista viva, por orden de importancia. Sale del feedback de E jugando, no de
lo que quedaba de un plan. Actualizada el 16 de agosto de 2026.

## Hecho desde la última sesión

- **El duelo se moría en silencio cuando el motor barajaba tus tapadas.**
  El más gordo de todos y no lo había reportado nadie porque no da error
  visible: el paquete `ocgcore-wasm` lee mal el mensaje 36 y se sale del
  buffer con `eof`, lo que mata el bucle del duelo entero. Detrás había
  un segundo bug tapado por el primero: ese mensaje no dice a dónde va
  cada carta, y el espejo tenía Armored Zombie y Wandering Mummy
  cambiadas de casilla — **volteabas una tapada y salía la otra**.
  Los dos arreglados; lo vigila `check-barajatapadas.mjs`.
- **El evento que atascaba la run.** Era lo que sospechábamos y peor:
  perder la última ficha en una apuesta marca `terminada`, y `opciones()`
  devuelve lista vacía con la run terminada — el mapa se quedaba sin un
  solo nodo pulsable. Ahora cualquier vista de juego con la run terminada
  va sola a la pantalla de final.
- **Perder al jefe ya no te pasa de acto.** El nodo se queda sin resolver
  y la única salida es la revancha. `check-run.mjs 200` pasó del 33% de
  runs terminadas sin ganar a **0%**.
- **Portada y careo con arte**, y **la curva de rivales medida**: ver más
  abajo.
- **Los textos que quedaban en español**: las once frases de los
  duelistas, los tres títulos de jefe y la barra.
- **Móvil**, lo de abajo.

## Bugs abiertos

1. ~~**Kuriboh no funcionó**~~ — **COMPROBADO Y FUNCIONA.** Montado el
   tablero exacto en `check-kuriboh.mjs`: con Kuriboh en la mano y un
   ataque declarado contra ti, el motor abre la ventana de cadena y la
   carta se activa. Dos falsos negativos por el camino, los dos culpa
   del test y no del juego:
   · el piloto automático juega TAMBIÉN tu lado, y en la primera Main
     Phase invocaba el Kuriboh al campo — cuando llegaba el ataque ya no
     estaba en la mano;
   · y el resolutor por defecto pasa de fase en vez de atacar, así que
     hubo 1.047 ventanas de cadena y ninguna con nada dentro.
   Lo que E vio fue casi seguro el bug de `SHUFFLE_SET_CARD`, que mataba
   el bucle del duelo sin dar un solo error y ya está arreglado.

2. **Cartas sin arte, todavía alguna.** `engine/data/img-alias.json`
   arregló 212 passcodes, pero E ha visto alguna suelta. Hace falta
   apuntar CUÁL: sin el nombre no se puede saber si es que el servidor
   de imágenes tampoco tiene el passcode base.

## Interfaz

Nada pendiente. La portada del Reino dejó de ser texto hace varias
sesiones (banner, elenco de retratos y la carta que representa a cada
starter); lo que decía este apartado estaba desfasado y se contradecía
con la sección de abajo.

## Lo visual, hecho

- **La portada del Reino** ya no es un h2 y tres cajas de texto: rótulo
  grande con la silueta del castillo en CSS, Pegasus mirándote desde
  arriba, los tres starters con **la carta que los representa** (Dark
  Magician, Gaia, Black Luster Soldier) y la fila de los diez duelistas
  que te esperan en la isla.
- **El careo antes del duelo**: retrato grande, su frase, y lo que te
  juegas **en estrellas dibujadas** en vez de "En juego: 2 ★". El jefe
  lleva marco dorado.
- Todo el arte sale de lo que ya viajaba dentro del HTML —los 28 retratos
  y las imágenes de carta por passcode—. Ni un archivo nuevo, +10 KB.

## Móvil

Reescrito esta sesión a partir de lo que reportó E jugando en el teléfono:
*"algunas partes de la interfaz son injugables en móvil... la info de las
cartas es pequeña, no se puede scrollear ni nada. muchas funcionalidades
también dicen hover para... pero en móvil no se puede."*

Lo que se ha hecho:

- **La hoja de carta.** En el Reino el panel deja de ser una columna y
  sube desde abajo, a tamaño legible, con scroll, ✕ y botón grande de
  confirmar. **El primer toque LEE, el segundo ELIGE**: antes tocabas una
  recompensa y te la llevabas sin haber podido leerla nunca.
- **El panel de detalle del duelo tenía `pointer-events:none`**, lo que
  mataba su propio `onclick` — el único que abre la lupa. Es literalmente
  el "no se puede scrollear ni nada": un recuadro de 104 px con letra de
  8 px y sin forma de agrandarlo. Ahora la caja no captura toques (para no
  estorbar al arrastre) pero el contenido sí, y lo dice en pantalla.
- **El deck builder no tenía UNA SOLA media query.** `#wrap` era una
  rejilla de 300 + 1fr + 380 px: 680 px de columnas fijas en una pantalla
  de 390. Ahora queda una columna y las otras dos son paneles que se
  abren; añadir al mazo y al Side son botones escritos, no clic derecho.
- **Los toques, de 44 px** como mínimo, safe-areas de iOS en los cuatro
  lados y el buscador a 16 px (por debajo, iOS hace zoom al enfocar y ya
  no vuelve).
- Todo lo anterior lo vigila **`node check-movil.mjs`** (28 comprobaciones
  sobre los dos HTML construidos). El disparador es `pointer:coarse`, no
  el ancho: un iPad declara 1024 px y se maneja con el dedo.

Lo que queda:

6. **Probarlo en un teléfono de verdad.** Nada de esto se ha visto en un
   iPhone ni en un Android; la comprobación lee CSS, no píxeles.
7. **El mapa en vertical con el rastreador debajo** puede quedar muy
   largo. Habría que ver si el rastreador merece ir plegado por defecto.
8. **El duelo sigue pidiendo girar el teléfono.** Nueve columnas no caben
   en vertical y no hay plan mejor por ahora, pero es lo primero que
   sorprende a quien abre el juego desde el móvil.

## Equilibrio: medido y arreglado

`simular-historia.mjs` medía en "normal" y "duro", niveles que el modo
historia ya no usa: los números salían maquillados porque enfrente había
un bot con lastres. Vuelto a medir TODO en experto, que es lo que juega
el juego. El mazo inicial contra cada tier 1, bot contra bot:

| rival | gana el starter |
|---|---|
| Weevil | 85% |
| Mai | 58% |
| Rex | 54% |
| Joey | 38% · Panik 38% |
| Kaiba | 35% |
| Mako | 31% |
| Bonz | 23% |

O sea que **tu primer duelo podía ser Weevil (85%) o Mako (31%) según la
tirada**. Eso no es dificultad, es lotería. Ahora cada personaje lleva su
`dureza` medida en `personajes.json` y `asignarRivales` reparte de más
blando a más duro según avanzas de columna. Comprobado sobre 300 mapas:
el primer duelo del acto I es siempre Weevil o Rex, y la dureza media
sube 29 → 66 dentro del acto. Sigue saliendo de la semilla.

Los tres starters son equivalentes (80/87/87% contra Weevil): lo que
parecía "el mazo B es flojo" era el rival, no el mazo.

Lo que queda:

9. **Pegasus.** Con la mano sembrada gana el 42% a un mazo de tier 3 y el
   54% al de Keith. Como el humano juega mejor que el bot, para un
   jugador será más fácil que eso. Decidir si el jefe final debe doler
   más; ojo que ahora la revancha es obligatoria y se pelea varias veces.

10. **Weevil T2 → T3 se nota poco** (38%). Los demás saltos de tier sí.

11. **M9 sin hacer**: simular runs completas con el mazo mejorándose para
    afinar cuántos packs salen (29% de los nodos) y la curva de recompensas.

## Cómo se prueba todo esto

```bash
cd engine && ./rebuild.sh          # reconstruye y pasa la suite entera
cd engine/browser
node check-reino.mjs               # la pantalla del Reino sobre el HTML real
node check-movil.mjs               # que se pueda jugar con el dedo
node check-run.mjs 200             # 200 runs completas sin navegador
node simular-historia.mjs 20       # duelos reales entre los mazos del modo
```

Y la regla que ya ha costado dos sesiones: **el DOM simulado no tiene
estilos ni construye `innerHTML`**. Todo lo que sea visual hay que
comprobarlo leyendo el CSS del HTML construido (`check-dom.mjs` ya valida
que las llaves estén equilibradas, `check-reino.mjs` los z-index).
