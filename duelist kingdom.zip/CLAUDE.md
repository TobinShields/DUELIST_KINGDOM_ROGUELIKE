# Simulador de Yu-Gi-Oh! Goat Format

Simulador jugable de Goat Format (abril de 2005) en el navegador, con reglas
reales y bots de cuatro niveles. Todo se entrega como **archivos HTML sueltos
que se abren con doble clic**: sin servidor, sin instalaciones, sin cuentas.

## Qué hay ahora mismo

| Archivo | Qué es |
|---|---|
| `goat-simulador.html` | El juego. ~4,6 MB, autocontenido (motor wasm + scripts + cartas dentro). |
| `deckbuilder.html` | Constructor de mazos. ~0,86 MB, con las 1.685 cartas legales. |
| `mazos/` | Los 20 `.ydk` originales. |
| `FORMATO-DECKLISTS.md` | Cómo pasar decklists nuevas (formato YDK). |
| `engine/` | Todo el código fuente y el sistema de construcción. |
| `publicar/` | La carpeta lista para subir a GitHub (más `goat-format-simulator.zip`). |
| `docs/` | Guía de publicación y borrador del post de Reddit. |
| `avatares/` | Los PNG originales de los 28 avatares (dentro del HTML van en WebP). |
| `engine/data/story/` | Datos del **modo historia** (en construcción, ver `docs/MODO-HISTORIA-ESTADO.md`). |

Los dos HTML son **artefactos generados**: no se editan a mano nunca.
Se editan las fuentes de `engine/` y se reconstruye.

## Decisión de arquitectura que lo sostiene todo

Las reglas **no** están programadas. Se usa **ocgcore**, el motor de
EDOPro/Project Ignis compilado a WebAssembly, en modo `MODE_GOAT` (reglas de
2005: SEGOC, damage step, six-step battle, priority). Escribir las reglas de
Yu-Gi-Oh a mano habría sido un proyecto de años con bugs de ruling para
siempre.

Entre el motor y la interfaz hay un **adaptador** (`browser/src/duel.mjs`) que
traduce los mensajes de ocgcore a eventos genéricos: `move`, `summon`, `chain`,
`attack`, `damage`, `phase`. **La capa visual no menciona ocgcore ni una vez.**
Ese fue el objetivo desde el principio: cuando E haga su propio juego de cartas,
escribe otro adaptador que emita los mismos eventos y toda la interfaz se
reutiliza.

```
ocgcore (wasm)  →  duel.mjs (adaptador)  →  eventos  →  view.js (interfaz)
                                                     →  ai/brain.js (bots)
```

## Estructura de engine/

```
engine/
  rebuild.sh              reconstruye todo y pasa la verificación
  data/                   base de cartas, pool legal, límites, mazos
    GOAT.lflist.conf      lista oficial de Project Ignis (whitelist)
    goat-pool.json        1.685 passcodes legales
    goat-limites.json     límite de copias por carta
    mazos.json            los 20 mazos, ya traducidos y con portada
  browser/
    src/ai/plan.js        con qué gana cada mazo (arquetipo → cómo jugar)
    src/duel.mjs          ADAPTADOR (lo reutilizable)
    src/view.js           interfaz: tablero, animaciones, arrastre
    src/main.js           orquestador: menús, decisiones, log
    src/trivial.js        resuelve decisiones sin elección real
    src/autopilot.mjs     piloto genérico de reserva
    src/ai/               knowledge.js · view.js · evaluar.js · brain.js
    src/template.html     plantilla del HTML final
    build-html.mjs        ensambla goat-simulador.html
    build-scripts.mjs     empaqueta los scripts Lua del pool
    out/                  bundles generados
    check-*.mjs, jugar.mjs, torneo.mjs   la suite de verificación
  deckbuilder/            app.js, estilo.css, plantilla.html, build.mjs
  vendor/                 ocgcore-wasm 0.1.2 (dist + lib)
```

Fuera de esta carpeta, en la del usuario, están los repos descargados:
`BabelCDB-master/` (base de cartas), `CardScripts-master/` (los Lua) y
`ocgcore-wasm-main/` (fuente del motor, no se usa: se usa el compilado).

## Cómo reconstruir

```bash
cd engine && ./rebuild.sh
```

O paso a paso, desde `engine/browser/`:

```bash
node build-scripts.mjs ../data/goat-pool.json   # 1.364 scripts Lua, ~2,2 MB
node build-html.mjs                             # genera out/goat.html
```

Y desde `engine/deckbuilder/`: `node build.mjs`.

Los HTML resultantes se copian a la carpeta del usuario.

## La suite de verificación

No hay navegador en el sandbox. Se ejecuta el HTML real sobre un DOM simulado
(`domstub.mjs`). **Cada comprobación existe porque un bug se coló sin ella.**

| Comando | Qué protege |
|---|---|
| `node jugar.mjs` | **El más importante.** Juega una partida como humano. |
| `node check-dom.mjs` | Los elementos existen en el HTML real y no hay ids huérfanos. |
| `node check-sync.mjs` | El espejo de estado coincide con el motor (6 partidas). |
| `node check-flip.mjs` | Los volteos dejan la carta boca arriba. |
| `node check-hand.mjs` | Nada de tu mano se pinta del revés. |
| `node check-lado.mjs 0.9` | El sorteo y el punto de vista concuerdan. |
| `node check-controles.mjs` | Los botones de fase y fin aparecen y funcionan. |
| `node torneo.mjs 250` | Los niveles de IA se ordenan como deben. **250 partidas por cruce o el ruido engaña.** |
| `node check-reglas.mjs` | Los interruptores de reglas de 2005 están puestos y se comportan. |
| `node check-cartas.mjs` | 17 rulings sobre 10 cartas concretas, con tableros montados a mano. |
| `node check-idioma.mjs` | La traducción llega a todos los textos, también al deck builder. |
| `node check-ia-propias.mjs` | Que la IA no se destruya sus propias cartas. Cada caso es una jugada que alguien reportó; con el cerebro anterior saca 10/17. |
| `node check-tapadas.mjs` | Que el panel aguante una carta tapada del rival en la lista de objetivos, y que nadie vuelva a tapar la función de traducción. |
| `node check-mudas.mjs` | Que ninguna carta entre al duelo con el passcode sin script. Es el bug que no da error. |
| `node check-bots.mjs` | Modo bots, historial, móvil y táctil. |
| `node check-suelta.mjs` | Arrastre, hitboxes y rendición. |
| `node check-revelar.mjs` | Cartas reveladas y momento de la cadena. |

| `node check-contadores.mjs` | Que las cuentas de Final Countdown, las Espadas y Wall of Revealing Light lleguen a la pantalla. |
| `node check-barajatapadas.mjs` | Que el motor pueda barajar tus cartas colocadas sin matar el duelo, y que el espejo se entere del nuevo orden. |
| `node check-movil.mjs` | Que se pueda jugar con el dedo: ninguna ayuda que hable solo de ratón, nada que se toque por debajo de 44 px, los recortes del iPhone reservados y las hojas de carta con salida. Lee los DOS html construidos. |
| `node check-actos.mjs` | Que la etiqueta de un acto no contradiga a sus botones: si dice CERRADO, nada dentro se puede pulsar. Recorre una run entera hasta Pegasus. También que «Al binder» abra el binder. |
| `node check-maestria.mjs` | Las tres ventajas de maestría en los CINCO personajes, y el ciclo exportar → borrar → importar, con cinco archivos corruptos rechazados sin tocar el progreso. |

| `node check-preparacion.mjs` | Elegir la ventaja de maestría PULSANDO los botones: que elegir la carta no borre la ventaja, que no se empiece con una ventaja a medias y que cambiar de duelista sí olvide lo elegido. |
| `node check-mapa.mjs 5000` | La ramificación: aristas coherentes, columnas de 1/2/3, ninguna ruta elegible sin las diez fichas, y las estadísticas de forma. |
| `node check-eventos.mjs` | Las 16 opciones de los 8 encuentros: que apliquen su efecto Y que se vea. |
| `node check-fichas.mjs` | Que con 1-9 fichas y sin clasificar SIEMPRE haya un botón que pulsar. Mira botones, no la API. |
| `node check-utilidades.mjs` | Campamento y mercader: una sola acción, y no se explota con Back ni recargando. |
| `node check-lp.mjs` | Que el espejo de puntos de vida diga lo mismo que el motor y que con el rival a 0 no se juegue nada más. |
| `node check-custom.mjs` | El Duelista libre: desbloqueo, selector de cara, torre de cinco + Pegasus y sus tres ventajas. |
| `node check-tablero.mjs` | Que la mano NO entre en el tablero: geometría en 8 viewports × manos de 5/7/10/12. El juego lleva además `__MEDIR_TABLERO__()` para medirlo con píxeles reales en el navegador. |
| `node check-record.mjs` | El historial del duelista: que cuente una vez, que viaje en el archivo de progreso y que el porcentaje pueda llegar a 100. |
| `node check-sobres.mjs` | Que la guía de sobres diga la verdad, cogiendo cartas de las listas REALES del generador. |
| `node check-fusiones.mjs` | Que ninguna fusión ni ritual que el juego reparta sea imposible de construir. 0 INVALID. |
| `node bench.mjs` | Dónde se va el tiempo, con el peor caso además de la media. |
| `node check-inspector.mjs` | La ficha de carta (clic fija, hover con retardo, ESC suelta), las uniones equipo→monstruo y que el robo salga del mazo. |
| `node check-kuriboh.mjs` | Que Kuriboh se pueda activar de verdad: tablero montado con la carta en mano y un ataque declarado. El bug que reportó E era del bucle del duelo, no de la carta. |
| `node check-salida.mjs` | Que «Ver el tablero» al acabar un duelo no te deje encerrado: el botón de fin pasa a ser «Continuar» y devuelve al mapa CON el progreso. Pulsa los botones de verdad. |
| `node check-telemetria.mjs` | Que el contador de uso siga mudo desde `file://`, sin código de sitio y con Do Not Track; que no viaje nada del estado de la partida; y que un fallo suyo no pueda tirar un duelo. |
| `node check-publicar.mjs` | Que la carpeta `publicar/` tenga el HTML RECIÉN construido (no una copia vieja), las capturas que enlaza el README, nada que pese más de 12 MB, y que la configuración sea de UN solo sitio: sin `CNAME`, con canonical, `og:url` y sitemap diciendo lo mismo, y con lo que enlaza el README fuera del `.gitignore`. |
| `node check-zona.mjs` | El visor de cementerio: que se pueda LEER la carta desde dentro, con el dedo, y que elegir un objetivo sea un botón y no un roce. |
| `node check-ingles.mjs` | Pone el juego en INGLÉS, recorre las 31 pantallas del Reino y lee lo que sale buscando español. `check-idioma` mira el mecanismo; esto mira el resultado. |
| `node banco.mjs` | **La vara para saber si juega bien.** 94 posiciones con la jugada correcta conocida, sacadas de misplays reales. Nota sobre 100 y desglose por familia. `node banco.mjs /ruta/vieja` compara versiones. |

### Herramientas de medida (no son comprobaciones, son datos)

| Comando | Para qué |
|---|---|
| `node analizar.mjs 150 experto duro` | Escanea partidas: **jugadas sin sentido**, ataques buenos y suicidas, cartas jugadas y cuándo, cartas muertas en mano. |
| `node medir-lastres.mjs 250` | Cuánto lastra cada defecto de la IA, uno a uno, contra el cerebro limpio. |
| `node duelo-versiones.mjs /ruta/vieja 300` | Enfrenta dos versiones del cerebro con las mismas semillas: la única forma honesta de saber si un cambio suma. Con `GOAT_MAZOS=todos` recorre las 20 barajas y desglosa por mazo. |
| `node escenario.mjs` (biblioteca) | Monta un tablero exacto y pregunta AL MOTOR, no al espejo. |
| `node story-tools/soporte.mjs` | Cuánto SOPORTE recibe de los sobres cada uno de los 20 mazos iniciales. Sale 1 si alguno con tema baja de 10 cartas. `--detalle` dice cuáles y `--huecos` solo los que fallan. |

## Trampas que ya han mordido (leer antes de tocar nada)

**El motor identifica las cartas por posición, no por identidad.** Un desfase de
un puesto en nuestro espejo hace que juegues una carta distinta a la que
arrastras. Pasó con Chaos Sorcerer: el UI decía "colocar Chaos Sorcerer" y el
motor colocaba Nobleman of Crossout. La causa era no seguir `SHUFFLE_HAND`
(Delinquent Duo y Graceful Charity barajan la mano). **La interfaz nunca debe
emparejar por índice: se resuelve a `uid` y se trabaja con uids.**

**Las posiciones son máscaras de bits, no valores.** `FACEDOWN` es `0x0a`.
Comparar con `===` contra `FACEDOWN_DEFENSE` hacía que las tapadas del rival se
vieran boca arriba. Y una M/T colocada lleva el bit de defensa, así que se
pintaba tumbada.

**La visibilidad depende de la ZONA, no de la posición.** El motor marca como
boca abajo todo lo que hay en una mano; una carta devuelta desde el cementerio
llegaba con posición 10 y se pintaba del revés en tu propia mano.

**Un volteo no manda `POS_CHANGE`.** La posición nueva viene dentro del propio
`FLIPSUMMONING`.

**Al enviar una acción hay que mandar el índice.** Faltaba en "Activar" desde el
campo y el motor activaba siempre `activates[0]` — activabas Snatch Steal
creyendo que activabas Breaker.

**El DOM simulado crea elementos al pedirlos.** Preguntarle "¿existe el botón?"
siempre da verde. Por eso los botones de fase estuvieron ausentes del HTML sin
que ninguna comprobación se quejara. Verificar contra el HTML real
(`check-dom.mjs`), no contra el stub.

**Un error del bucle se puede volver invisible.** El `catch` escribía en la
pantalla de carga, que ya estaba oculta: el juego se quedaba muerto sin ni un
mensaje. Ahora cualquier fallo sale en pantalla con botón para descargar el log.

**Guardar cartas "para el momento perfecto" pierde partidas.** La primera IA
experta perdía 36% contra la de nivel medio porque se le morían las cartas en la
mano. Hay un concepto de *prisa* que relaja las condiciones si vas por detrás.

**El ATK de la base de datos no es el ATK del tablero.** Thousand-Eyes Restrict
figura con 0 y absorbiendo pega con 1.900; un monstruo con Snatch Steal encima
tampoco coincide. La IA leía la ficha de fábrica y por eso no atacaba nunca con
el TER. Ahora `duel.refrescarStats()` le pregunta al motor con
`duelQueryLocation` una vez por decisión y deja `atkReal`/`defReal` en la carta
del espejo; `evaluar.js` los prefiere. **Al añadir cualquier dato nuevo que
venga del motor, recortarlo en `ai/view.js`**: ese módulo es la frontera que
impide que el bot vea las tapadas del rival, y `refrescarStats` responde
también por ellas.

**Una lista de objetivos legales incluye tus propias cartas.** El motor no dice
si el efecto que se resuelve hace bien o mal al objetivo. Ring of Destruction,
Book of Moon, Nobleman y Tsukuyomi admiten monstruos de los dos lados, y
ordenar por "lo más valioso" hacía que el bot se volara lo suyo. Regla: si en
la lista hay algo del rival, lo propio va al final. Cuando la carta necesita de
verdad un objetivo propio (material de Metamorphosis, tributo, reanimación) la
lista es solo tuya y la regla no llega a aplicarse.

**No llames `T` a dos cosas.** En `main.js`, `T()` es la traducción; dentro de
`ask()` había un `const T = OcgMessageType` que la tapaba. La línea que oculta el
nombre de las cartas boca abajo llamaba a `T("Carta boca abajo")` y reventaba con
"T is not a function" — pero solo cuando en la lista de objetivos había una tapada
del rival, o sea casi nunca hasta que a un jugador le tocó absorber con
Thousand-Eyes Restrict. El enum ahora se llama `MT` y `check-tapadas.mjs` monta ese
panel a mano con el gancho `globalThis.__PREGUNTA_DE_PRUEBA__`. **Cualquier fallo
del bucle deja ahora un botón para que el juego conteste por ti y siga**: un error
de interfaz no debería costar la partida.

**Las banderas de carta son para lo que las cuentas NO ven.** `knowledge.js`
tiene el vocabulario de WindBot: `peligroso` (D.D. Warrior Lady destierra a los
dos aunque la mates), `inmuneCombate` (Spirit Reaper), `prioritario` (Jinzo,
Royal Decree, TER: quítalo antes que nada), `espiritu` (vuelve a la mano),
`invoca` (si eso ya está en el campo, el efecto no hace nada). **Error medido:**
marcar también los muros como `peligroso` hizo que el bot no atacara a un
Gravekeeper's Spy boca arriba en ATAQUE —1200, hay que matarla— y costó dos
puntos de victoria. Un muro ya se defiende con su propia defensa.

**EL DEDO NO TIENE HOVER, Y ESO NO ES UN DETALLE DE ESTILO.** Medio
sistema del Reino se llenaba solo con `onmouseenter`: en un teléfono
tocabas una recompensa y te la llevabas **sin haber podido leerla nunca**.
Y el panel de detalle del duelo llevaba `pointer-events:none` desde que se
hizo flotante, lo que mataba su propio `onclick` —el único que abre la
lupa—, así que la carta se leía en un recuadro de 104 px con letra de 8 px
y overflow oculto. Regla: **toda función que solo se alcance pasando el
ratón necesita su gesto táctil equivalente, y toda ayuda que diga "pasa el
ratón" o "clic derecho" necesita su gemela con `class="soloTacto"`**. El
disparador es `pointer:coarse`, NO `max-width`: un iPad declara 1024 px y
se maneja con el dedo. Lo vigila `check-movil.mjs`.

**Un puente global mal escrito no da error, devuelve el texto tal cual.**
El de la traducción se llama `globalThis.__T` y el Reino pedía `__T_`: TODAS
sus llamadas a `T()` fueron un no-op desde que se escribió la pantalla. No
saltó ninguna alarma porque `traducirDOM` pasa después y arregla los nodos de
texto sueltos —por eso "AT STAKE" salía en inglés—, pero no puede con nada
compuesto: "Su mazo: de aficionado" se quedaba en español. Lo vigila ahora
`check-idioma.mjs`, que busca cualquier `globalThis.__T` con letras de más.

**Un test que espera un número de milisegundos es una apuesta.**
`check-controles` hacía `sleep(11000)` y luego miraba si te tocaba decidir.
Al engordar los estilos del móvil 20 KB, el arranque tardó un poco más y el
test empezó a fallar cuatro de cada cinco veces sin que nada estuviera roto.
Se espera A LA CONDICIÓN con un tope, y con `GOAT_SEED` puesta para que la
partida sea siempre la misma.

**`import * as` NO SOBREVIVE AL EMPAQUETADO.** `build-html.mjs` concatena los
módulos del Reino dentro de un mismo ámbito y BORRA los imports. Un
`import * as recompensasMod from "./recompensas.js"` desaparece sin dejar rastro
y la referencia se queda colgada: en el navegador salía "recompensasMod is not
defined" al resolver cualquier encuentro con morralla, y en node no pasaba
porque ahí SÍ son módulos de verdad. Se arma el objeto a mano con lo que ya
está en el ámbito.

**ENTRAR EN UN NODO NO ES RESOLVERLO.** `entrar()` mueve `run.pos` y
`siguientes()` devuelve la columna de después, así que ASOMARSE a un duelo y
volver al mapa te adelantaba una columna. La regla que lo ordena todo:
mientras el nodo donde estás no esté `resuelto`, la única opción es ese nodo.
Y solo GANAR resuelve un duelo — perder cuesta la ficha y lo deja ahí. Corolario
que costó un cuelgue: las UTILIDADES tienen que poder saltarse (`saltarNodo`),
o un campamento cuyo buff ya tienes te encierra para siempre.

**Cuidado con las unidades fijas en el CSS.** El viñeteado era
`inset 0 0 260px 70px`: perfecto en un monitor de 1080 de alto, media pantalla
en un móvil de 400 y justo por el borde donde está la mano. Dos usuarios lo
reportaron como "es más oscuro que en PC". Todo lo que cubra pantalla va en
`vmin`/`vh`.

**LA TRAMPA MÁS CARA: cartas que no hacen nada.** En la base, muchas cartas de
Goat existen con DOS passcodes —Pyramid Turtle (77044671) y Pyramid Turtle
(GOAT) (504700135)— y el script Lua está solo en la del pool. Con el otro
código la carta se reparte, se invoca y **no hace absolutamente nada**, sin
error y sin aviso. Y ese es justo el passcode que trae cualquier decklist
copiada de internet. Explicaba de golpe cuatro reportes distintos. Ahora se
traduce por nombre al entrar, tanto en el simulador como en el deck builder
(`alPool`), y lo vigila `check-mudas.mjs`.

**El paquete de ocgcore también tiene bugs.** `ocgcore-wasm` 0.1.2 lee mal el
mensaje `SELECT_SUM` —los tributos de una invocación ritual—: se salta el campo
de posición y a partir de la primera carta el flujo va desfasado. Se parchea
sobre el texto del dist en `bundle.mjs`, con un aviso si algún día deja de
encajar. Antes de dar por hecho que un mensaje raro es culpa nuestra, mirar si
el paquete lo parsea bien.

**Y un segundo, peor: `SHUFFLE_SET_CARD`.** El mensaje 36 es el que baraja tus
cartas COLOCADAS —lo manda el motor cada vez que pones algo boca abajo teniendo
ya otra tapada, para que nadie pueda seguirle la pista a una carta concreta—.
El paquete lo lee mal de dos formas a la vez: la cuenta es un `u8` y él lee un
`u32`, y las posiciones no vienen en parejas sino en dos bloques. Se salía del
buffer con `eof` y **eso mata el bucle del duelo entero**. Apareció midiendo el
equilibrio del modo historia: el mazo de Bonz, lleno de tapadas, lo reventaba.

Y detrás había un segundo bug tapado por el primero: **el mensaje NO dice a
dónde va cada carta**. El motor reserva el hueco de las posiciones nuevas antes
de barajar y en esta versión llega siempre a ceros. Usarlo movía las cartas a
"la casilla 0 del jugador 0" y multiplicaba por diez los desajustes. La
solución es no adivinar: al recibirlo se le PREGUNTA al motor cómo ha quedado
la zona (`duelQueryLocation`) y se reordena el espejo para que coincida.
Sin eso, el espejo tenía Armored Zombie y Wandering Mummy cambiadas de casilla:
volteabas una tapada y salía la otra.

**`bundle.mjs` escribe DOS copias del bundle** (raíz y `out/`). Todo lo demás
lee la de `out/`: regenerar solo la de la raíz hacía que un arreglo del motor no
llegara a ningún sitio y pareciera que no funcionaba.

**EL `default` ERA LA REGLA, NO LA EXCEPCIÓN.** `knowledge.js` tiene 109 cartas
escritas a mano; el pool son 1.685. Las otras 1.576 caían en `default: p = 1.2`
del cerebro — y el umbral para jugar una carta es 0.8. O sea que la regla
efectiva era **"si no te suena la carta, juégala en cuanto puedas"**, con el
objetivo elegido por el criterio genérico de "lo más valioso". De ahí salían,
todos con la MISMA causa, el Breaker rompiendo una tapada cualquiera en vez del
Premature Burial que sostenía un Jinzo, el Skull Lair sobre su propio monstruo y
el Raigeki Break sobre lo suyo. Ahora existe `ai/lectura.js`: lee el TEXTO de la
carta —viaja dentro del HTML, las 2.157— y saca qué hace y qué necesita para
hacerlo. Cubre el 53% de las mágicas y trampas del pool, y lo que no sabe leer
se queda en **cero**, que es el lado seguro. Al añadir una carta rara, mirar
primero si `lectura.js` la entiende antes de escribirle un caso.

**El adaptador tiraba 72 de los ~100 mensajes del motor.** Tres reportes
distintos salían de ahí: `SWAP` (Creature Swap no intercambiaba las cartas —el
motor sí lo hacía, el espejo no se enteraba, y los ATK/DEF sí cambiaban porque
esos se le preguntan al motor), `ADD_COUNTER`/`REMOVE_COUNTER` (Wave-Motion
Cannon sin mostrar cuánto daño lleva acumulado) y `EQUIP`. Antes de dar por
hecho que algo visual es culpa de la vista, comprobar si el mensaje llega.

**Lo que se pinta con `content:attr(data-*)` no lo ve la traducción.** La
etiqueta "DECLARACIÓN DE ATAQUE" sobre la tira de fases no es un nodo de texto,
así que ni `traducirDOM` ni el cazador de fugas de `check-idioma` la tocaban. Se
traduce al escribir el atributo.

**Un rival al azar dentro del acto es una lotería, no una dificultad.**
El mazo inicial le gana el 85% al tier 1 de Weevil y el 23% al de Bonz, y
la primera versión elegía rival al azar: tu PRIMER duelo de la aventura
podía ser cualquiera de los dos. Ahora cada personaje lleva su `dureza`
medida en `personajes.json` —sale de jugar el starter contra su tier 1 en
experto— y `asignarRivales` reparte de más blando a más duro según avanzas
de columna. Al tocar un mazo del modo historia, volver a medir esa fila.

**El plan de cada mazo sale de su guía, no de la intuición.** `ai/plan.js`
tiene los 20 mazos con lo que dice goatformat.com de cada uno, citado en el
comentario: con qué gana, cuánto arriesga, las cartas pesadas del 1 al 3, el
motor y lo que tiene que seguir en el campo. Añadir un mazo es añadir una fila.
Dos avisos al tocarlo: contar señales no basta cuando dos mazos comparten motor
(Monarch y Phoenix llevan los mismos Apprentice Magician; para eso está
`requiere`), y `agresivo` NO es decorativo — escala la prudencia al invocar, y
tenerlo sin usar le costaba 13 puntos a Beastdown.

**Cuidado al "arreglar" algo que dice una guía sin medirlo.** Las guías de
PACMAN y Clown Control dicen que esos mazos ganan volteando sus bichos una y
otra vez, así que levanté el freno anti-bucle para ellos. PACMAN se hundió del
59% al 24%, monótono con el número de volteos permitidos. La guía tiene razón y
la implementación no: esos monstruos se re-tapan SOLOS con su efecto y el bot
los dejaba a cara descubierta con 500 de ataque. Lo que sí sirve es voltear solo
cuando el volteo consigue algo (`voltearVale`).

**Jugar bien y ganar el espejo bot contra bot no son lo mismo.** Las reglas que
evitan las jugadas que un humano castiga —no invocar en ataque delante de algo
más grande, colocar en vez de regalar la carta— miden PEOR contra otro bot: el
rival no te castiga por regalar cartas, así que la prudencia solo cuesta tempo.
Medido varias veces, entre 2 y 4 puntos. La decisión ha sido quedárselas y
decir el número, no maquillarlo; se pueden apagar con `GOAT_AI_OFF=sobrevivir`,
`posicionSegura`, `postura`.

**Y la vara que sí lo mide es `banco.mjs`.** El espejo bot contra bot da 49-52%
haga lo que haga —lo comprobé toda una sesión, subiera o bajara la calidad—
porque dos bots igual de malos se reparten las partidas. El banco son 57
posiciones fijas con la jugada correcta conocida, como los test suites de los
motores de ajedrez. Contra las versiones antiguas del cerebro da la progresión
que el marcador nunca enseñó: 49 → 65 → 74 → 81 → 86 → 89 → 100. **Al tocar la
IA, correr el banco ANTES que el torneo.** Y cuando llegue a 100, añadir
posiciones que falle: un banco saturado ya no mide, solo protege.

**Un cambio no es un suicidio.** `ganaCombate` pide ATK estrictamente
mayor, que es lo correcto para "me lo llevo gratis", pero con ataques
IGUALES mueren los dos: eso es un cambio, y en `valeAtacar` caía en la rama
de suicidio (−4). Por eso el Thunder Dragon robado con Mind Control no
atacaba al Breaker de 1600 y volvía intacto a su dueño en la End Phase
(partida 1 de E, turnos 5 y 8). Y el escáner tenía el mismo error de
concepto: contaba SUICIDA cualquier ataque en el que muriera el atacante,
así que al arreglar lo anterior el número saltó del 1% al 5% sin que nada
hubiera empeorado. Ahora suicida es "muero y él vive", y los cambios se
cuentan aparte.

**Lo que te prestan hay que gastarlo.** Un monstruo robado con Mind Control
o Snatch Steal vuelve a su dueño; si no lo metes en combate, se lo devuelves
entero. La vista legal marca `prestado` comparando con las decklists (su
código está en la lista del rival y no en la mía) y `valeAtacar` le suma
tres puntos: cambiarlo por lo que sea es ganancia.

**Cuidado con el `else` final de una cadena de condiciones.** Al meter
"Spirit Reaper va en defensa" como un `if` suelto delante del `if/else if/
else` que ya había, el `else { p = 0.05 }` lo pisaba y la carta seguía en
ataque regalando daño. Un caso nuevo en esas cadenas va SIEMPRE encadenado.

**Las jugadas sin sentido del escáner no son todas del bot que mides.**
`analizar.mjs 100 experto duro` daba 0,39 por partida y casi todas eran
Book of Moon y Torrential Tribute del turno propio… del lado `duro`, que
tiene el lastre `cadenaTonta` a propósito (responde con lo primero que
tenga). El experto contra sí mismo da 0,07. **Para juzgar al experto,
medirlo contra el experto**; el cruce contra niveles bajos mide la escalera,
no la calidad.

**No dependas de la tabla escrita a mano para saber qué es una ficha.**
`esFicha` era `valorCarta(c) <= 0.2`, o sea "está en `knowledge.js` con
valor bajo". Se mira también el bit de ficha de la base y el caso
"monstruo normal de 0/0": sin eso seguían colándose la Snatch Steal y el
Smashing Ground sobre una ficha de Scapegoat.

**Lo que la carta CUENTA ya lo manda el motor.** Final Countdown y las
Espadas de Luz Reveladora llaman a `SetTurnCounter`, Wall of Revealing Light
a `SetHint(CHINT_NUMBER, pagado)` y Wave-Motion Cannon también cuenta turnos:
todo eso llega como `CARD_HINT`, otro de los mensajes que el adaptador tiraba.
No había que inventar ninguna cuenta, solo dejar de tirar el mensaje. **Pero
`CARD_HINT` no trae el código de la carta**, solo dónde está: hay que
resolverla contra el espejo o la chapa sale como "undefined 7". Y Final
Countdown es una mágica NORMAL, así que cuenta desde el CEMENTERIO y no hay
carta en la mesa donde colgar el número: esas van a una chapa junto a los
puntos de vida.

**El marcador no mide si juega bien.** Dos bots igual de tontos dan 50%, así
que "no ha empeorado" no significa "juega bien". Lo que el usuario ve no es el
porcentaje: es la Snatch Steal sobre una ficha de Scapegoat. `analizar.mjs`
cuenta **jugadas sin sentido** con nombre y apellidos (1,38 por partida antes,
0,06 después) y esa es la métrica que hay que mirar para las quejas de tipo
"la IA hace cosas raras". El porcentaje solo sirve para comprobar que arreglarlo
no le ha costado partidas.

**Una ventana de respuesta no es una razón para responder.** El caso más
repetido del escáner —234 veces en 300 partidas— era el bot encadenando su
propia Book of Moon a su propia invocación, con el campo rival vacío. En
`cadena()` la carta no tenía ninguna condición: "puedo encadenar algo" bastaba.
Toda carta que se encadena tiene que decir CONTRA QUÉ.

**Cuidado al contar activaciones: los mantenimientos también son eslabones.**
El peaje de Snatch Steal en la Standby Phase llega como `chain` igual que una
activación. Contarlos daba 144 "Snatch Steal sin objetivo" que eran una sola
Snatch Steal cobrando cada turno.

**Un test que parpadea deja de mirarse.** `check-chain` fallaba una de cada tres
ejecuciones sin que hubiera nada roto: jugaba una partida real y el bot rival decide
con `Math.random`. Con `globalThis.GOAT_SEED`, `domstub.mjs` fija todo el azar del
proceso (barajado, desempates de la IA, porcentaje de error) y el duelo entero es
reproducible. En el navegador la variable no existe y todo sigue siendo aleatorio.

**Cuidado con medir con el evento equivocado.** Los ataques directos se
contaban con `battle`, que el motor solo manda cuando hay cálculo de daño entre
dos monstruos: salía "0 directos en 1.550" y parecía un fallo de la IA. Un
ataque directo llega como `attack` sin objetivo. Antes de creerse un número
raro, comprobar de qué evento sale.

**«CERRADO» TIENE QUE SIGNIFICAR CERRADO.** El estado del acto salía de
`run.pos.acto`, y `run.pos` sigue en el acto I hasta que PISAS un nodo del II.
Entre ganar al jefe de la isla y entrar al castillo había un hueco en el que
los peldaños del castillo ya se podían pulsar y la etiqueta encima decía
CERRADO. Hay un estado más, `siguiente` («TE ESPERA»), y `check-actos.mjs`
prohíbe la contradicción en general: ningún acto rotulado como cerrado puede
tener un botón vivo.

**Recorrer la pantalla del Reino a base de pulsar botones no funciona.** En
cuanto un nodo es un duelo, la pantalla se va al tablero y el recorrido se
queda mudo: el primer `check-actos` daba VERDE después de un solo paso. Para
eso está el gancho `globalThis.__REINO_PRUEBA__` (`H`, `pintar`, `alMapa`,
`entrar`, `abrirPack`): se mueve la run por su API y se repinta el mapa, que
es lo que se quiere mirar. Y ojo con `disabled`: solo se pone a mano en los
nodos del mapa, en el resto de botones llega `undefined`.

**Un test que aserta píxeles se pone rojo cuando mejoras el código.** Dos
comprobaciones de `check-bots` exigían `right:34px` literal; la pasada de
móvil los cambió por `env(safe-area-inset-*)` —que era justo lo que había que
hacer— y saltaron. Se comprueba la INTENCIÓN (no está centrado / está pegado a
la esquina respetando el recorte), no el número.

**UN REPINTADO NO PUEDE BORRAR LO QUE HAS ELEGIDO.** Las tres variables de
la preparación —ventaja, carta de maestro, familia del sobre— vivían DENTRO de
la función que dibuja la pantalla, y elegir la carta llamaba a `pintar()` para
enseñar el aviso. `pintar()` monta la pantalla entera otra vez, así que volvía
a ejecutar la declaración y las dejaba las tres a null: con el mismo clic con
el que elegías la carta perdías la carta Y la ventaja. `check-maestria` daba
verde porque llamaba a `H.empezar({pasivo, cartaDeMaestro})` directamente; el
bug estaba en la pantalla, no en la API. Para eso está `check-preparacion.mjs`,
que pulsa los botones. Corolario: una ventaja a medias ya no se gasta —ni la
run la aplica ni la pantalla deja empezar.

**UN ALIAS DE IMPORT TAMPOCO SOBREVIVE AL EMPAQUETADO.** Ya estaba escrito que
`import * as` desaparece; `import { exportar as exportarEstado }` desaparece
igual, y eso dejó **Importar progreso** roto en el navegador con el test en
verde (en node sí son módulos de verdad). Ahora `build-html.mjs` PARA la
construcción si encuentra cualquiera de los dos, con el módulo y la línea.

**«DURO» NO ES "UN POCO PEOR".** `nivelDeIA()` devuelve siempre experto, pero
el nivel se perdía por el camino: la línea que lanza el duelo del Reino ponía
`carga.rival?.nivel ?? "duro"`, así que cualquier rival al que no le llegara el
campo jugaba con el cerebro lastrado —el que ataca sin mirar y encadena lo
primero— sin un solo aviso. Un respaldo silencioso a "juega mal a propósito" es
lo peor que puede haber en una aventura.

**LOS PUNTOS DE VIDA IBAN A LOS DOS LADOS.** `duel.create` recibía un solo
`lp`, así que el +1000 del campamento se lo llevaba también el rival: el buff
no hacía nada. Ahora hay `lp0`/`lp1`, y de paso eso da el único mando de
dificultad honesto para un jefe final —la IA ya juega en experto y el mazo ya
es meta—. Pegasus juega con 14000.

**EL JEFE FINAL ERA EL MAZO MÁS FLOJO DEL CASTILLO.** Medido: un mazo de tier 3
le ganaba el 67% y el mazo INICIAL sin mejorar le hacía cara a cara (45%). Dos
causas. Una, que las cartas Toon son malas de verdad —Toon Summoned Skull no
ataca el turno que sale y se muere con Toon World—, así que un mazo Toon puro
no puede ser un jefe: ahora es el Goat Control de Worlds 2020 con SEIS cartas
Toon dentro, medido contra versiones de 7 y 8. Y dos, que sembrarle tres cartas
Toon en la mano de salida le COSTABA 6 puntos, porque cambiaba tres cartas de
un esqueleto meta por Toons; ahora solo se le garantiza Toon World. Con
maestría desbloqueada juega directamente mazos meta del simulador. Lo genera
`engine/story-tools/pegasus.mjs` y no se edita a mano.

**LA API OFRECÍA DUELOS Y LA PANTALLA NO LOS DIBUJABA.** E llegó con nueve
fichas a los Hermanos Paradoja sin salida. `opciones()` devolvía los duelos de
última oportunidad perfectamente; lo que pasa es que esos nodos NO viven en
`acto.columnas` y el mapa solo dibujaba columnas. Simular contra la API daba
CERO bloqueos con el juego roto. Cuando el bug puede estar en la pantalla, el
test tiene que mirar los BOTONES.

**LO QUE VIVE DENTRO DE `vistaInicio` SE PIERDE AL REPINTAR — TODO ELLO.**
Ya estaba escrito para la ventaja y la carta de maestro; faltaban `quien` (el
duelista) y el starter. Elegías Joey, elegías su carta —ese clic llama a
`pintar()`— y arrancabas con Yugi. Cualquier variable de una pantalla que se
repinte va FUERA de la función que la dibuja.

**UN NODO DE UTILIDAD ES UNA DECISIÓN, NO UNA TIENDA.** El mercader no marcaba
resuelto al comerciar: trueque, volver al mapa, entrar otra vez, y a vaciar el
binder. La comprobación de "ya gastado" va en el ESTADO, no en la pantalla,
porque la pantalla se puede volver a abrir.

**UNA COMPARACIÓN DE RAREZA CON UNA SOLA SEMILLA ES UNA MONEDA.** «Mano firme»
y el buff del abuelo suben la TABLA de pesos, y de las tres cartas de una
recompensa solo UNA sale de esa tabla. Con una semilla empatan por azar y el
test se pone rojo sin que nada esté roto. Se miden 40.

**EL ESPEJO DE LP MENTÍA, Y PARECÍA UN BUG DEL MOTOR.** E jugó contra Pegasus
y el marcador enseñó 0 LP en el turno 21; el duelo siguió seis turnos más hasta
el `win` de verdad. No era ocgcore ni el adaptador perdiendo el mensaje:
`duel.create` pasaba `lp0`/`lp1` al motor correctamente pero el espejo hacía
`this.lp[0]=this.lp[1]=lp` con el valor POR DEFECTO. Con Pegasus a 14000, tras
8000 de daño la pantalla marcaba 0 y el motor seguía con 6000. Antes de tocar
reglas por un síntoma visual, comprobar si el espejo y el motor dicen lo mismo.

**UNA TORMENTA ES UN BALANCE, NO UNA CUENTA DE CARTAS.** `massRemoval` miraba
CUÁNTAS cartas hay a cada lado; en el log de E, Pegasus activó Heavy Storm con
tres mágicas suyas colocadas contra una del rival. Ahora compara VALOR: lo que
destruye del rival menos lo que destruye propio, con las cartas ya gastadas
—una Premature cuyo monstruo ya no está— valoradas casi a cero. Y en el banco
hay las DOS posiciones: la que no debe activarse y su contraejemplo, porque un
veto sin contraejemplo acaba en una IA que nunca juega la carta.

**EL SEXTO JUGABLE NO SE QUITA A NADIE DE LA TORRE.** Los cinco protagonistas
se eliminan a sí mismos del castillo. El Duelista libre no representa a
ninguno, así que su torre lleva a los CINCO más Pegasus: seis combates. La
plantilla del acto III tiene un peldaño de más y `generarActo` lo recorta
cuando sobra — dejar una columna de torre sin nadie dentro bloquea el castillo.

**ELEGIR DUELISTA NO REPINTABA.** El selector de cara del Custom se monta
dentro de la pantalla de inicio, así que sin repintar no aparecía nunca:
elegías Custom y no había caras que pulsar. Repintar ahí es seguro DESDE que
las elecciones viven fuera del render; antes era justo lo que las borraba.

**EL SIGNO ESTABA AL REVÉS Y EL TEST DABA VERDE.** Tres iteraciones para que la
mano dejara de tapar las mágicas y trampas, y las tres medí el número del CSS en
vez de dónde acaban las cartas. `y` es el borde de ARRIBA de la carta, así que
`y = gridH - CH*asoma` con `asoma:1` no la deja debajo del tablero: la deja
ENTERA DENTRO. El test comprobaba que `--asoma-mia` valiera 1 y por eso pasaba.
Ahora la mano se coloca SUMANDO (`gridH + hueco`), `fitBoard` reserva la carta
entera más el hueco, y `check-tablero.mjs` calcula la separación en píxeles.
Regla para la próxima: si el bug es de posición, el test mide POSICIONES.

**LOS STARTERS DEL CUSTOM ERAN UN MAZO DE TORNEO.** Puntuando por lo que cada
carta cambia una partida, daban 86,3 contra 46,7 de media de los cinco
protagonistas: llevaban Pot, Graceful, Heavy Storm, Snatch, Premature, Mirror
Force, Torrential y Metamorphosis de salida. Con eso no queda nada que ganar
durante la run. Ahora son tres estructuras (Guerreros, Hechiceros, Dragones) a
44-45, generadas por `story-tools/custom-starters.mjs`, y `check-custom` vigila
que no vuelvan a subir.

**UNA COMPARACIÓN DE JAVASCRIPT PUEDE PARECER TEXTO SIN TRADUCIR.**
`check-idioma` busca lo que hay entre `>` y `<`, y `a > b && c.left < d` cae
justo en medio: lo daba por una cadena en español sin traducir. Ahora el
detector descarta lo que lleve `&&`, `||` o `.algo <`.

**LOS "PARONES DE 5 A 10 SEGUNDOS" NO ERAN UN BUCLE LENTO.** Medido: una decisión
de la IA tarda 0,01 ms y nada del Reino pasa de 16 ms. El hilo no estaba
bloqueado: estaba ESPERANDO a propósito. Cada evento del motor lleva su
animación —240 ms al robar, 290 al mover, 500 por eslabón, 400 al invocar— más
160 ms después de cada respuesta de la IA, y un turno con Scapegoat (cuatro
fichas = cuatro `move`), Metamorphosis y una cadena de tres suma más de ocho
segundos en los que no se puede tocar nada. Desde fuera es indistinguible de un
cuelgue. La solución no es quitar las animaciones sino que la espera dependa de
CUÁNTAS quedan: con la cola vacía, igual que antes; con veinte eventos, a un
quinto. 6,2 s → 1,2 s en el turno cargado que mide `bench.mjs`.

**ESTAR EN EL POOL NO ES PODER CONSEGUIRLA.** El validador de fusiones daba 0
INVALID sin comprobar nada porque aceptaba cualquier material del pool, y con
1.685 cartas siempre hay alguna. Exigiendo que la pieza salga en algún sobre
aparecieron tres agujeros de verdad: Polymerization no estaba en NINGUNA lista
del generador (o sea que la ruta "materiales + Poly" era imposible para las 52
fusiones), Summoned Skull tampoco —y es la mitad de Black Skull Dragon—, y Black
Luster Ritual se repartía sin que su monstruo saliera en ningún sitio.

**IMPORTAR PROGRESO SE COMÍA LAS ESTADÍSTICAS.** `importarProgreso` reconstruía
el `meta` desde cero con solo la maestría, así que todo lo que se guardara ahí
al lado se perdía al cambiar de navegador. Cualquier cosa nueva en `meta` hay
que copiarla explícitamente, y saneada.

**LA POSICIÓN NO SE COMPARA CON EL ATAQUE PROPIO.** Para agacharse se exigía
`def(c) > atk(c)`, y Sangan es 1000/600: nunca entraba y se quedaba de frente
regalando 800 por turno. En defensa el daño es CERO mida lo que mida la
defensa. Cinco reportes distintos de E eran esa línea.

**UNA VENTANA DE TEXTO FIJA CADUCA.** `check-reino` miraba los 6.000 caracteres
siguientes a `function vistaBinder` para comprobar que la pantalla tuviera panel
de carta. Al añadirle el buscador y los filtros, la llamada al panel se fue a
8.463 y el test dijo que faltaba algo que estaba ahí. Si se busca dentro de una
función, el límite es la SIGUIENTE función, no un número.

## El log de partida

El botón "Descargar log" saca un `.txt` con semilla, mazos barajados, cada
mensaje del motor, qué se preguntó y qué se eligió, con marca de tiempo y fase.
**Es la herramienta de depuración principal**: casi todos los bugs se
localizaron leyéndolo. Si el usuario reporta algo, pedirle el log.

## Cosas que no se pueden hacer

- **No hay simulación hacia adelante.** ocgcore no permite clonar ni serializar
  un duelo, así que no hay MCTS ni búsqueda en árbol. La IA es heurística,
  igual que la de Master Duel.
- **Las imágenes se cargan de ygoprodeck** por passcode desde el navegador del
  usuario. Sin internet, se ve una ficha de respaldo con nombre y stats.
- **Licencia:** ocgcore y los CardScripts son AGPL-3. Uso personal sin problema;
  publicarlo obliga a liberar el código bajo la misma licencia. Las imágenes de
  carta son de Konami.

## Modo historia (Duelist Kingdom roguelike) — a medias

Capa NUEVA por encima del simulador: mapa sembrado, Star Chips, packs y
progresión de mazo. **No toca el motor ni las reglas**: cuando llega el
momento de pelear, lanza un duelo normal con `lanzarDuelo()`.

Está hecho de M0 a M7 (datos, mapa, fichas, guardado, colección,
recompensas, packs, mercader, campamento, eventos, rivales, Pegasus y
maestría), todo con comprobación propia y sin interfaz todavía. **Falta M8
(la interfaz) y M9 (equilibrio y build final).**

Lo que falta, por orden y con los bugs abiertos, está en
**`docs/REINO-PENDIENTE.md`**. Lo de más abajo del capó está en
**`docs/MODO-HISTORIA-ESTADO.md`**: archivos, enganches con el juego,
números medidos y lo que queda por afinar. Tres avisos que ya han mordido:

**El nombre bueno de una carta está en `pool_texts.json`, no en
`names.json`.** En `names.json`, "Sinister Serpent" es el passcode moderno,
que NO está en el pool; el que juega es "Sinister Serpent (Pre-Errata)".
Buscar por el archivo equivocado daba 31 cartas "inexistentes" que sí están.

**El tope de copias se cuenta sobre el mazo entero, no línea a línea.**
Sustituir una carta por otra que el mazo ya llevaba a tres metía cinco
Two-Headed King Rex, y cada línea era legal.

**Una carta que no dice nada en su texto necesita un caso escrito.** Toon
World solo pone "Pay 1000 Life Points", así que `lectura.js` no podía sacar
nada y la IA no la jugaba nunca: el Pegasus del modo historia perdía el 75%
contra el mazo inicial porque llevaba nueve cartas muertas. De ahí el rol
`habilita` en `knowledge.js`.

**LOS SOBRES SOLO REPARTEN 200 CARTAS DE LAS 1.685.** Las listas de
`data/story/cards.json` están escritas a mano y son TODO lo que un jugador
puede conseguir. Si el tema de un mazo inicial no está ahí, ese jugador abre
sobres durante toda la aventura y no mejora nunca: le salen cartas buenas,
pero de otro mazo. E lo olió sin medirlo («para efectos de volteo igual no
tanto») y el número le dio la razón: las arpías tenían 6 cartas de apoyo,
los zombis 7, el volteo 9. Lo mide `story-tools/soporte.mjs`, que saca las
señales DEL PROPIO MAZO —razas, archetipos y palabras que sus cartas
repiten— y las cruza con lo que reparten los sobres. Dos avisos al tocarlo:
una palabra que sale en más del 4% del pool ("battle", "spell") no es una
señal y con ella todos los mazos sacaban entre 39 y 114, o sea nada; y no
todos los mazos tienen tema —"La guardia de KaibaCorp" son Battle Ox y La
Jinn— así que a esos se les mide el camino genérico, no el temático.

**UNA FUSIÓN EN EL MAIN DECK ES UNA CARTA MUERTA.** El starter de Fusión
llevaba dos Flame Swordsman en el mazo principal: el motor no las deja salir
de ahí, así que eran dos huecos perdidos de cuarenta, y ninguna comprobación
se quejaba porque las dos estaban en el pool y dentro del límite de copias.
Ahora `check-fusiones` mira las dos mitades de los 58 mazos, y de paso
comprueba que un monstruo con condición —Horus LV6, Ultimate Insect LV5,
Levia-Dragon— tenga su llave en algún sobre.

**LA PORTADA DE UN MAZO NO PUEDE SER `main[0]`.** El mazo de Fusión enseñaba
un Baby Dragon y el de volteo un Old Vindictive Magician porque la insignia
era la primera carta de la lista. Un mazo se elige por la carta que te
imaginas jugando: va escrita a mano en el generador (`insignia`).

**HAY DOS FUNCIONES QUE LANZAN UN DUELO.** `lanzarDuelo` (el libre) y
`lanzarDueloDelReino` (el del mapa). El arreglo de la cara del Duelista libre
—`REINO?.run?.avatar ?? cfg.avatar`— estaba solo en la primera, y el test lo
buscaba en TODO el bundle: lo encontraba allí, daba verde, y en el Reino
seguías jugando con la cara de Opciones. E eligió a Arkana y jugó de Dark
Magician Girl. Un test que busca una expresión tiene que decir DENTRO DE QUÉ
función la busca.

**UNA CLAVE REPETIDA EN LA TABLA DE TRADUCCIÓN GANA LA ÚLTIMA, EN SILENCIO.**
JavaScript no se queja de una clave duplicada en un objeto literal.
Traduciendo los mazos de salida los metí por segunda vez con la redacción
cambiada y la tabla se quedó con 21 claves que decían dos cosas distintas
según dónde mirases. Lo vigila `check-idioma`.

**«ESTÁ TRADUCIDO» Y «NO QUEDA ESPAÑOL EN PANTALLA» NO SON LO MISMO.**
`check-idioma` comprueba el mecanismo: que el puente `__T` esté bien escrito,
que nadie tape la función, que la clave exista. Con todo eso en verde seguía
saliendo español, por tres causas distintas: `ev.quien` se pintaba sin
envolver en `T()`, cuatro avisos se escribían en crudo, y el motivo del
mercader lleva el número dentro ("tienes 4 de las 10 que pide") así que una
tabla de frases exactas no puede cubrirlo. `check-ingles.mjs` pone el juego
en inglés, recorre las 31 pantallas del Reino y LEE lo que sale.

**UN TEST QUE BUSCA UN BOTÓN POR SU TEXTO PUEDE COGER OTRO.** `check-sobres`
buscaba el botón cuyo texto contuviera "sobre"… y la semilla de la prueba se
llamaba "SOBRES", así que se llevaba el botón de copiar semilla. Filtrar
además por la clase.

**`scale()` ENCOGE DESDE EL CENTRO, Y ESO DEJA UNA BANDA MUERTA.**
`fitBoard` hacía `transform:scale(k)` sobre `#plane`, cuya caja es SOLO el
tablero —la mano se dibuja con transformaciones y no cuenta para el tamaño—.
Con `transform-origin` por defecto (50% 50%), el borde de arriba del tablero
BAJA `(1-k)·alto/2`: 113 px de media en los ocho móviles que mide
`check-tablero`. Desde fuera son las dos cosas que E mandó en una captura a
la vez: una franja vacía entre la barra y el tablero, y su propia mano
cortada por el borde de abajo. Se compensa con un `translateY` ANTES del
`scale` —en el espacio sin escalar, así que no lo afecta— reservando solo lo
que asoma la mano del rival, que se dibuja en `y` negativa y por tanto fuera
de la caja. **No se toca `transform-origin`**: movería también el eje del
giro 3D y cambiaría la perspectiva.

**Y LO MISMO CON LA TIRA DE FASES, QUE ES LA TERCERA VEZ.** Al mudarla al
borde izquierdo —a la derecha se peleaba con el panel de decisiones— se
metió en el carril del historial de jugadas. En el Android de E se pisan;
en una pantalla más alta no, porque la tira va centrada a media altura.
Hay un hueco fijo que resuelve la mayoría de teléfonos y, además,
`apartarDelHistorial()` mide los dos rectángulos y la aparta solo cuando
de verdad se solapan. **Regla ya establecida: para apartar dos cosas que
crecen, se mide; un número escrito a mano acierta en un aparato y falla
en el siguiente.**

**UN `top` FIJO PARA APARTAR UN PANEL ES UNA APUESTA.** El panel de
decisiones tapaba el marcador del rival. Lo intenté dos veces con un número
en el CSS del móvil y las dos se quedó corto, porque el alto del marcador
depende de la cara, del nombre del duelista y de qué bloque de estilos gane
en ese aparato. Ahora `apartarPanel()` mide los DOS rectángulos y baja el
panel lo justo, y se llama cada vez que el panel se enseña.

**REPINTAR DENTRO DE UN `onmouseenter` ES UN BUCLE.** El hover del sobre
llamaba a `pintar()`, que monta la pantalla entera otra vez: destruye el
botón que hay bajo el ratón y crea otro en su sitio, el navegador dispara
`mouseenter` sobre el nuevo, y vuelta a empezar. E lo vio como un panel
parpadeando. Regla: **una respuesta al ratón no puede repintar la pantalla
que contiene al elemento que la disparó** — se rellena el panel en su sitio.

**`conPanel()` LLAMADO N VECES CREA N VISORES, Y SOLO VALE EL ÚLTIMO.**
`panel` es una sola variable del módulo. La guía de sobres lo llamaba una vez
por sección, así que pintaba tres visores de carta y solo funcionaba el de
abajo del todo. Da igual cuántas listas haya: una llamada, un visor.

**EL ORDEN DEL ARCHIVO DECIDÍA, Y EL BLOQUE DE MÓVIL VA PRIMERO.** Las
reglas del Reino para `pointer:coarse` están ESCRITAS ANTES que las reglas
base, así que con la misma especificidad ganaba la última: subir el tamaño
de carta para PC agrandó también el teléfono, y `check-reino` daba verde
porque miraba si la regla de móvil EXISTÍA, no si ganaba. **Un test de
presencia no vale para un problema de cascada.**

**PERO ARREGLARLO EN MASA FUE PEOR.** Al ver que 89 reglas del Reino
estaban en esa situación, les puse `#reino` delante a todas de golpe. Eso
cambió el valor efectivo de decenas de cosas que nadie había reportado: en
la mitad de ellas la que ganaba era la regla BASE, y ese era el tamaño que
llevaba meses funcionando. E lo notó en el primer arranque — las cartas de
Mazo y binder pasaron de 63 px a 76. La regla buena es la contraria: se
blindan **solo** las reglas que arreglan un bug reportado, una por una y
con su motivo escrito, y el resto se dejan como están. La lista vive en
`check-reino.mjs` (`DEBEN_GANAR`).

**«VER EL TABLERO» ESCONDÍA LA ÚNICA SALIDA.** Al acabar un duelo, el
botón principal de la pantalla final es lo ÚNICO que resuelve el nodo y
te devuelve al mapa con la ficha ganada. El tercer botón solo escondía
esa pantalla, así que mirar el campo después de ganar te dejaba encerrado
y sin el progreso. Ahora la salida se muda al rincón de fase y fin de
turno —el que en móvil está reservado justo para que nada lo tape— y el
botón de fin pasa a decir «Continuar».

**Y NO SE PODÍA PROBAR PORQUE LOS BOTONES IBAN EN UN `innerHTML`.** El
DOM simulado no lo construye: devuelve lo que se le asignó pero no crea
hijos, así que los tres botones de la pantalla final eran invisibles para
toda la suite. Peor: `querySelector` sobre el stub CREA el elemento que
le pidas, o sea que buscar `.finCaja` devolvía un fantasma y colgar algo
de ahí no llegaba a ninguna parte. Los botones se crean ahora con
`createElement`/`appendChild` y se cablean sobre la referencia, sin
volver a buscarlos. Regla: **lo que haya que poder pulsar en una prueba
no puede nacer dentro de un `innerHTML`.**

**UNA PESTAÑA PLEGADA DEBAJO DE OTRA COSA ES UN PANEL PERDIDO.** El panel
de decisiones se podía plegar, y la pestaña para recuperarlo (`#pestana`)
vive en `right:0; top:50%` con z-index 151. En móvil, ahí mismo está la
tira de fases (`#phases`, z-index 300, y está a 300 justamente porque nada
puede taparla). Al plegar, la pestaña quedaba debajo de DRAW/STANDBY/MAIN
y no había forma de volver. Con el dedo ya no hay flecha de plegar, y una
preferencia guardada de antes se deshace al arrancar para no dejar a nadie
encerrado.

**UN `vw` DENTRO DE UN `clamp` SE DISPARA EN HORIZONTAL.** La rejilla de
Mazo y binder usaba `clamp(56px,7vw,80px)`: en un teléfono da 56 px y está
bien, pero en un táctil de 1024 da 72 y con `1fr` estirando la columna
acababa en 74 px por carta — seis por pantalla en vez de veinte. `check-reino`
calcula ahora el ancho EFECTIVO en cinco anchos de pantalla y le pone tope;
mirar la regla no sirve, porque la regla parecía razonable.

**Y LA MISMA GUERRA, AL REVÉS: TRES CLASES GANABAN A LA REGLA DE MÓVIL.**
`.rPanel.suelto.abierto` —la ventana flotante de 280 px del mapa— tiene
(0,0,3,0) y le ganaba a `.rPanel` (0,0,1,0), que es la que hace que con el
dedo la ficha de carta suba desde abajo a lo ancho. En Mazo y binder salía
un recuadro estrecho con el texto partido cada dos palabras. Regla que se
repite: **cuando dos reglas compiten, mirar la ESPECIFICIDAD antes que el
orden**, y blindar solo la que arregla el bug.

**UN BOTÓN DE 34 PX SOBRE UNA CARTA DE 50 SE COME LA CARTA.** Al encoger
las cartas del binder, el botón de mover pasó a tapar media ilustración.
El primer arreglo fue quitarlo con el dedo y dejar la acción solo en la
hoja de carta — y E lo rechazó: quiere el botón directo, sin abrir nada.
La solución buena no era ni encogerlo ni quitarlo, sino **sacarlo de
encima de la carta**: baja a una barra debajo, a todo el ancho de la
celda. No tapa un píxel de arte y el área de toque queda MÁS grande que
antes (69×34 en vez de 34×34). Con eso la carta puede además crecer, así
que el tope del binder sube de 62 a 80 px. Regla general: cuando un
control y su contenido se pelean por el mismo sitio, moverlo suele ser
mejor que encogerlo.

**UN ID GANA A CUALQUIER NÚMERO DE CLASES, Y ESO ROMPIÓ TRES REJILLAS.**
Para que el tamaño de carta de PC no se colara en el móvil se blindó
`#reino .rCarta`. Especificidad (1,0,1,0), o sea que pasó a ganarle a
`.rCartas.mini .rCarta` (0,0,3,0) — la regla que dice que dentro del binder
la carta RELLENA su casilla— y las cartas del binder saltaron de 50 px a
120. De paso rompió la rejilla de recompensas y la del mercader, que nadie
miró. E lo reportó tres veces seguidas y las tres el culpable fue el mismo
selector. La regla estructural: **una regla de contenedor
(`.rCartas.algo .rCarta`) tiene que ganar siempre a una de carta suelta**,
así que si una lleva id, la otra también. `check-reino` calcula la
especificidad y compara quién gana, en vez de mirar si la regla existe.

**UNA FRANJA A TODO EL ANCHO EN UN TELÉFONO ES MEDIA PANTALLA.** Las
ilustraciones del Reino se apilaban como cabecera de 104 px para decir
«esto es un sobre», que ya lo dice el título. En móvil van como icono de
46-58 px encima del encabezado; en PC siguen flotando al lado del texto.

**UN OVERLAY A PANTALLA COMPLETA DEJA EL PANEL DE CARTA DEBAJO.** El visor
de cementerio es `position:fixed; inset:0` con fondo borroso: llenar el
`#detail` de la izquierda —que es lo que hacía— no servía de nada, y
encima solo se llenaba con `onmouseenter`, o sea con nada en un móvil.
La ficha va DENTRO del visor. Y de paso, ahí un toque ELEGÍA el objetivo
sin haber podido leerlo: ahora tocar lee y elegir es un botón.

**DOS BOTONES EN LA MISMA ESQUINA SE PISAN, Y UNO SE PIERDE AL HACER
SCROLL.** En la ficha de carta, «coger» era `sticky` a lo ancho y «cerrar»
`absolute` arriba a la derecha: el primero tapaba al segundo —E cogía
cartas queriendo cerrar— y además un `absolute` dentro de un panel con
scroll se va con el contenido, así que al bajar a leer el efecto la ✕
desaparecía. Los dos van ahora en la misma barra pegada arriba.

**LA CARA DE LA RUN LA GUARDA LA RUN, PARA TODOS.** `run.avatar` solo se
rellenaba cuando llegaba el parámetro `avatar`, y ese solo llega jugando al
Duelista libre: con Yugi o con Joey se quedaba en null, el duelo caía al
respaldo —la cara de Opciones— y salías de Dark Magician Girl. El primer
arreglo cubrió solo al Custom porque la comprobación solo miraba al Custom.
Ahora `empezar()` guarda siempre la cara (la elegida, o la del personaje) y
`check-custom` empieza una run con cada uno de los cinco.

**UNA VENTANA DE TEXTO FIJA CADUCA — Y LOS COMENTARIOS CUENTAN.** Ya
estaba escrito para `check-reino`; volvió a morder dos veces en un rato en
`check-zona`, porque cortaba N caracteres de una función que lleva dentro
un párrafo de veinte líneas explicando el bug. Si se busca dentro de una
función, se quitan los comentarios ANTES de cortar.

**UNA PALABRA CORTA Y EN MAYÚSCULAS SE ESCAPA DEL CAZADOR DE ESPAÑOL.**
La chapa «JEFE» del mapa siguió en español con `check-idioma` en 21/21 y con
`check-ingles` recorriendo 31 pantallas en verde: no lleva acentos, ni
artículos, ni minúsculas. Por eso `check-ingles` mira además, en las FUENTES
(no en el bundle: dentro va el pegamento de emscripten con sus propias
funciones de una letra), que cada `T("…")` tenga entrada en la tabla.
Y ojo: `T()` hace `trim()` antes de buscar, así que la clave de `T("Turno ")`
es `"Turno"`.

## Pendiente

1. **M9, el equilibrio del Reino.** La interfaz (M8) está hecha. Falta
   simular runs COMPLETAS con el mazo mejorándose para afinar cuántos sobres
   salen (29% de los nodos) y la curva de recompensas. Hoy el equilibrio se ha
   medido por piezas —Pegasus, los tiers, el soporte de los starters— pero
   nunca de principio a fin.
2. **Multijugador.** Es lo primero que pide la gente en Reddit.
3. **Partidas atascadas**: entre el 3% y el 12% de los duelos bot contra bot
   llegan al tope de 60 turnos, según el cruce. Con el contador de uso puesto,
   `stuck/turn-limit` dirá si a un jugador humano le pasa de verdad o es solo
   cosa de dos bots dándose vueltas.
4. **Afinar la IA con partidas reales.** El usuario tiene acceso al dataset de
   GFWL en Kaggle (`nedhmn/yu-gi-oh-gfwl-matches`, un CSV de 2 MB). Si lo deja
   en la carpeta, se puede extraer en qué turno se juega cada carta y con qué
   estado de tablero se ataca, y ajustar las heurísticas con datos.
5. **App de Android** envolviendo la web con Capacitor.

## Cómo trabaja el usuario (E)

Habla en español y prueba el juego a fondo entre iteraciones. Reporta bugs con
capturas y con el log descargado. Le importa mucho que la interfaz se sienta
bien —arrastre, animaciones, claridad visual— y que el simulador no le obligue a
hacer nada a mano, al contrario que Dueling Book.

Prefiere que se le diga lo que no funciona a que se le adorne. Cuando algo se
rompe por un cambio propio, decirlo claro y explicar la causa.
