# Informe de validación del modo historia

Generado el 2026-08-15 por `engine/story-tools/importar-diseno.mjs`.

El pool legal tiene **1685** passcodes. El diseño usa **299** cartas distintas repartidas en **35** mazos.

## Cartas del diseño que NO existen en el pool

Ninguna.

## Mazos con avisos

**yugi-starter-a**
- sustituida Mystic Elf → Mystical Elf (errata del brief: la carta se llama Mystical Elf)

**yugi-starter-b**
- sustituida Berfomet → Gemini Elf (Berfomet no está en el pool y sin él tampoco hay Chimera; se cambia por otra carta clásica de Yugi del mismo nivel de potencia)
- sustituida Chimera the Flying Mythical Beast → Rabid Horseman (la fusión de Gazelle+Berfomet no existe en el pool; Rabid Horseman es una fusión de nivel 6 legal, así que sigue valiendo como objetivo de Metamorphosis)

**weevil-t1**
- sustituida Gokibore → Kuwagata α (insecto vanilla equivalente (1250/1000 nivel 4) para el mazo anime de Weevil)

**rex-t1**
- sustituida Sword Arm of Dragon → Kabazauls (el pool solo tiene dos dinosaurios de nivel 5-6 y los dos son demasiado fuertes para un Tier 1; Kabazauls (1700/1500) es el dinosaurio grande que sí existe)
- sustituida Megazowler → Element Saurus (mismo caso: no hay dinosaurios medianos de nivel 6 en el pool, así que se cubre el hueco con otro cuerpo de nivel 4)
- sustituida Trakodon → Mammoth Graveyard (dinosaurio vanilla de nivel 3 casi idéntico (1200/800))

**mako-t1**
- sustituida Kairyu-Shin → Sea Serpent Warrior of Darkness (mismas estadísticas (1800/1500) y misma raza de serpiente marina)
- sustituida Fiend Kraken → Flying Penguin (Aqua vanilla de nivel 4 con estadísticas equivalentes para el mazo anime de Mako)

**joey-t1**
- sustituida Battle Warrior → Armaill (guerrero vanilla de nivel 3 (700/1300) del mismo tramo)
- sustituida Copycat → Garoozis (Copycat no está en el pool; Garoozis es otra carta del Joey del anime y aporta un cuerpo de 1800)
- sustituida Panther Warrior → Nin-Ken Dog (no hay Beast-Warrior de nivel 4 con 2000 que no sea de castigo; Nin-Ken Dog (1800) mantiene la raza y el papel de atacante)
- sustituida Alligator's Sword → Pale Beast (bestia vanilla de nivel 4 con las mismas estadísticas (1500/1200))
- sustituida Kunai with Chain → Reinforcements (trampa de combate del mismo estilo y de la misma época; Kunai with Chain no está en el pool)

**mai-t1**
- sustituida Cyber Shield → Malevolent Nuzzler (equipo genérico de +700 en lugar del equipo de Harpies, que no está en el pool)

**panik-t1**
- sustituida Dark Chimera → Ryu-Kishin Powered (Fiend de estadísticas parecidas (1600/1200) para la baraja de PaniK)
- sustituida Metal Guardian → Wall of Illusion (muro Fiend del pool (1000/1850) que además devuelve al atacante a la mano: mismo papel defensivo)
- sustituida Barox → Reaper on the Nightmare (fusión legal del pool en el mismo hueco del Extra; Barox no está)

**bonz-t1**
- sustituida The Snake Hair → Wandering Mummy (zombi de nivel 4 con estadísticas equivalentes (1500/1500))

**bandit-keith-t1**
- sustituida Pendulum Machine → Gadget Soldier (máquina de nivel 6 casi calcada (1800/2000))
- sustituida Blast Sphere → Cannon Soldier (máquina de nivel 4 del pool; además encaja con el Keith del anime)

**labyrinth-brothers-t1**
- sustituida Dungeon Worm → Neo Bug (insecto de estadísticas equivalentes (1800/1700))
- sustituida Monster Tamer → Dark Blade (guerrero de nivel 4 con 1800/1500, mismo papel de cuerpo grande)

## Tamaño de cada mazo

| Mazo | Main | Extra |
|---|---|---|
| yugi-starter-a | 40 | 0 |
| yugi-starter-b | 40 | 2 |
| yugi-starter-c | 40 | 0 |
| weevil-t1 | 40 | 0 |
| weevil-t2 | 40 | 0 |
| weevil-t3 | 40 | 0 |
| rex-t1 | 40 | 0 |
| rex-t2 | 40 | 0 |
| rex-t3 | 40 | 0 |
| mako-t1 | 40 | 0 |
| mako-t2 | 40 | 0 |
| mako-t3 | 40 | 0 |
| joey-t1 | 40 | 2 |
| joey-t2 | 40 | 4 |
| joey-t3 | 40 | 8 |
| mai-t1 | 40 | 0 |
| mai-t2 | 40 | 0 |
| mai-t3 | 40 | 0 |
| panik-t1 | 40 | 1 |
| panik-t2 | 40 | 0 |
| panik-t3 | 40 | 0 |
| bonz-t1 | 40 | 0 |
| bonz-t2 | 40 | 0 |
| bonz-t3 | 40 | 0 |
| bandit-keith-t1 | 40 | 0 |
| bandit-keith-t2 | 40 | 0 |
| bandit-keith-t3 | 40 | 0 |
| kaiba-t1 | 40 | 1 |
| kaiba-t2 | 40 | 6 |
| kaiba-t3 | 40 | 15 |
| labyrinth-brothers-t1 | 40 | 0 |
| labyrinth-brothers-t2 | 40 | 5 |
| labyrinth-brothers-t3 | 40 | 15 |
| pegasus-m0-boss | 40 | 15 |
| pegasus-m1-boss | 40 | 15 |

## Pools de recompensa

| Pool | Cartas |
|---|---|
| ultra | 14 |
| super | 29 |
| rare | 36 |
| arcane | 27 |
| warrior | 29 |
| dragon | 26 |
| recruit | 30 |
| forbid | 30 |
| fusion | 11 |
| fusionTematica | 6 |
| maestria | 10 |
