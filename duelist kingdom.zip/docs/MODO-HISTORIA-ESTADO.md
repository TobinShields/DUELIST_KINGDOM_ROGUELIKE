# Modo historia (Duelist Kingdom roguelike) — dónde va y qué falta

Actualizado el 15 de agosto de 2026. Lee esto antes de tocar nada de
`src/story/`.

## Qué está hecho y funcionando

Todo lo que hay debajo tiene comprobación propia y se ejecuta en
`engine/rebuild.sh`. **Ya se puede jugar**: el menú tiene "Reino de los Duelistas" y la pantalla
lleva mapa, nodos, recompensas, packs, mercader, campamento, eventos y
editor de mazo. Falta pulir (retratos que faltan, animación de apertura de
sobre) y M9.

| Milestone | Qué hay | Comprobación |
|---|---|---|
| M0 auditoría | Puntos de enganche localizados (abajo) | — |
| M1 datos | 35 mazos y 11 pools del brief resueltos a passcodes del pool | `check-historia.mjs` |
| M2 mapa y fichas | Mapa sembrado por columnas, Star Chips, guardado y export/import | `check-mapa.mjs` |
| M3 colección | Binder, binder de fusiones, mazo 40-60 con topes | `check-recompensas.mjs` |
| M4 recompensas | 1-de-3 con suelo de calidad, packs de 10 casillas, 5 familias | `check-recompensas.mjs` |
| M5 utilidad | Mercader sin dinero, campamento, 8 eventos | `check-utilidad.mjs` |
| M6 rivales | 10 duelistas × 3 tiers, escalera de IA, registro de derrotados | `check-rivales.mjs` |
| M7 Pegasus y maestría | Toon → Relinquished → mazos meta del simulador; pasivo del abuelo | `check-rivales.mjs` |
| Mano de jefe | `sembrarManoDeJefe`: al jefe se le garantiza su motor de salida | `check-jefes.mjs` |
| M8 pantalla | Menú nuevo, mapa, nodos, recompensas, binder, ES/EN | `check-reino.mjs` |
| M8 (a medias) | **El orquestador** (`historia.js`): la máquina que une todo. Falta solo la pantalla | `check-run.mjs` |

### Archivos

```
engine/data/story/
  diseno-v1.txt        el brief de E, tal cual (fuente de todo)
  decks.json           35 mazos en passcodes  ← GENERADO, no editar a mano
  cards.json           los 11 pools de recompensa ← GENERADO
  sustituciones.json   las 23 cartas que no están en el pool y por qué
  personajes.json      duelistas, jefes, Pegasus, starters
  eventos.json         los 8 eventos
  validation.json      informe para máquinas
engine/story-tools/
  importar-diseno.mjs  regenera decks.json y cards.json desde el brief
engine/browser/src/story/
  rng.js  balance.js  mapa.js  estado.js
  catalogo.js  coleccion.js  recompensas.js  utilidad.js  personajes.js
docs/story-validation-report.md   informe legible carta por carta
```

Para regenerar los datos tras tocar el brief o las sustituciones:

```bash
node engine/story-tools/importar-diseno.mjs
cd engine/browser && node check-historia.mjs
```

## Lo que falta

### M8 — la interfaz (lo siguiente, y es lo gordo)

**El orquestador ya está**: `src/story/historia.js` contesta a las dos únicas
preguntas que hace una pantalla —`opciones()` («¿qué puedo hacer?») y
`entrar()`/`resolver()` («he hecho esto, ¿y ahora?»)— y guarda después de
cada acción. `check-run.mjs` juega 200 runs completas de punta a punta sin
navegador: ninguna se rompe, el mazo sigue legal toda la run, 7,3 duelos de
media, y quien gana todo se clasifica y termina.

O sea que la interfaz es **solo pintura**: no tiene que tocar el estado.

Nada de `src/story/` toca el DOM todavía. Hace falta:

1. **Entrada al modo** en el menú de `src/template.html`, junto a "Duelo VS"
   y "Modo bots". Con "Continuar" si hay `goat.story.run.v1` guardado.
2. **Pantalla de mapa**: las 20 casillas en tres actos, la ficha del guante
   con las Star Chips, el retrato del rival al pasar por encima, la semilla
   visible y copiable.
3. **Pantallas de nodo**: recompensa 1-de-3, apertura de pack (las diez
   cartas), mercader, campamento y evento con retrato.
4. **Editor de mazo desde el mapa**: el deck builder ya existe como
   `deckbuilder.html`, pero el del modo historia trabaja sobre el binder de
   la run, no sobre los mazos guardados. Es una vista nueva, aunque puede
   reusar el CSS de cartas.
5. **Idiomas**: todo el texto nuevo pasa por `T()` de `src/i18n.js` y hay que
   añadir las cadenas en inglés. `check-idioma.mjs` caza lo que se escape,
   **pero no lo que se pinta con `content:attr(data-*)`** (ver CLAUDE.md).
6. **Móvil**: nada de unidades fijas en lo que cubra pantalla; `vmin`/`vh`.

**Los tres enganches con el juego que ya existen** (auditados en M0):

- `lanzarDuelo(opciones)` en `src/template.html` acepta mazo del rival y
  nivel. El modo historia necesita además pasar mazo PROPIO explícito (hoy
  lo saca de `cfg.mazo`) y puntos de vida iniciales (para el campamento).
- `boot({..., config})` en `src/main.js` recibe `config.avatarRival`,
  `config.nombreRival` y `config.nivel`.
- `View.pantallaFinal({..., onNuevo})` ya admite un callback: por ahí vuelve
  el modo historia al mapa con el resultado.

### M9 — equilibrio y build final

- Simulación de runs completas (hoy `simular-historia.mjs` solo cruza mazos
  sueltos, no simula una run con el mazo mejorándose).
- Informe de distribución de recompensas por acto.
- Reconstruir el HTML con todo dentro y comprobar que VS, bots y deck
  builder siguen intactos.

## Números medidos hasta ahora

Mapa (5.000 semillas): 0 imposibles, 0 que incumplan reglas, 8,7 duelos por
run, 1,00 intentos de generación por mapa.

Recompensas (2.000 muestras): 0% de tríos por debajo del suelo, 37% de
cartas C (todas temáticas, de las listas curadas), 0,40 UR por pack, la
casilla de tipo acierta el 100%.

Duelos reales (bot contra bot, o sea el **suelo**: un humano juega mejor):

| Cruce | Bot |
|---|---|
| Starter vs Weevil T1 (primer duelo, IA normal) | 81% |
| Starter vs Weevil T1 (segundo nodo, IA dura) | 75% |
| Starter B vs Rex T1 | 44% |
| Starter C vs Mako T1 | 56% |
| Starter sin mejorar vs Joey T2 | 13% |
| Starter sin mejorar vs Kaiba T3 | 13% |
| Starter sin mejorar vs Pegasus M0 (sin sembrar) | 55% |
| Starter sin mejorar vs Pegasus M0 (**sembrada**) | 40% |
| Mazo de tier 3 vs Pegasus M0 (**sembrada**) | 50% |
| Weevil T1 vs T2 | 0% |
| Weevil T2 vs T3 | 56% |
| Joey T1 vs T3 | 6% |

## Pendiente de afinar (no son fallos, son números)

1. ~~Pegasus M0 está flojo~~ **ARREGLADO con la mano de salida.** A los
   jefes se les puede garantizar su motor en la mano inicial
   (`manoInicial` en `personajes.json`, función `sembrarManoDeJefe`). Con
   tres piezas sembradas, Pegasus gana el 60% a un mazo inicial sin mejorar
   y queda 50/50 contra un mazo de tier 3 competitivo. No ve tu mano ni roba
   de más: solo se evita que abra sin Toon World y juegue con nueve cartas
   muertas. Lo vigila `check-jefes.mjs`.
2. **Weevil T2 → T3 casi no se nota** (56%). Los demás saltos de tier sí
   (T1→T2 es 0%-100%, Joey T1→T3 un 6%).
3. **Perder un jefe te pasa de acto igual.** Hoy el nodo del jefe se marca
   resuelto ganes o pierdas y el mapa sigue. El brief dice que el jefe hay
   que vencerlo para avanzar y que perder solo cuesta una ficha: hay que
   hacer que el nodo del jefe se pueda repetir mientras queden fichas. Se ve
   en `check-run.mjs`: un 33% de las runs llegan al final del mapa sin haber
   ganado y sin haberse quedado sin fichas.
4. **Los packs salen mucho** (29% de los nodos del mapa). Es generoso a
   propósito, pero conviene mirarlo con una run completa.
5. **Faltan tres retratos**: PaniK, Bonz y Pegasus. Van como `avatar:null` y
   la interfaz tendrá que pintar una silueta con el nombre. Si aparecen los
   PNG, se meten en `engine/data/avatares.json` con el mismo proceso que los
   28 actuales y se cambia el `null` por su clave.

## Decisiones de diseño que se tomaron por el camino

- **23 cartas del brief no existen en el pool** (vanillas de anime que la
  whitelist de Project Ignis no incluye). Ninguna se sustituyó en silencio:
  `sustituciones.json` tiene el reemplazo y el motivo, y el informe las
  lista. Dos consecuencias: sin Berfomet no hay Chimera (Starter B lleva
  Gemini Elf y Rabid Horseman), y el pool solo tiene tres dinosaurios por
  encima de nivel 4, todos demasiado buenos para un Tier 1.
- **La rareza de historia no es la impresa.** Pot of Greed es UR; Swords of
  Revealing Light, que está limitada, es SR.
- **Las recompensas salen de las "curadas"**, no del pool entero: las tres
  listas de rareza más las cinco familias del brief. Sin eso, la mitad de lo
  ofrecido era relleno de verdad.
