# Cómo subir esto a GitHub

La carpeta ya está lista. Estos son los pasos, en orden, y lo que hay que
poner exactamente en cada casilla.

**Importante antes de nada:** el nombre del repositorio tiene que ser
`goat-format-simulator` y la cuenta `circlenline`. La URL del juego, la
canónica del SEO, el sitemap y el Open Graph ya apuntan a
`https://circlenline.github.io/goat-format-simulator/`. Si eliges otro nombre,
hay que cambiar esas cuatro cosas o Google indexará una dirección que no existe.

---

## 1 · Crear el repositorio

En GitHub, **New repository**:

| Casilla | Qué poner |
|---|---|
| Repository name | `goat-format-simulator` |
| Description | `Yu-Gi-Oh! Goat Format (April 2005) simulator with a Duelist Kingdom roguelike — free, in your browser, no install.` |
| Visibilidad | **Public** (obliga la licencia: ver más abajo) |
| Add a README | **No** — ya hay uno |
| Add .gitignore | **No** — ya hay uno |
| Choose a license | **No** — ya está el AGPL-3.0 |

Y en la página del repo, botón ⚙ junto a *About*, en **Topics**:

```
yugioh  goat-format  card-game  roguelike  deckbuilding  duelist-kingdom
wasm  browser-game  ocgcore  no-install
```

GitHub usa los topics en su propio buscador y ayudan a que aparezca a quien
busque «goat format» dentro de GitHub.

---

## 2 · Subir el contenido

Desde ESTA carpeta (`publicar/`):

```bash
git init -b main
git add -A
git commit -m "Goat Format Simulator v1: simulador + Reino de los Duelistas"
git remote add origin https://github.com/circlenline/goat-format-simulator.git
git push -u origin main
```

---

## 3 · Encender GitHub Pages

**Settings → Pages**:

- **Source**: `Deploy from a branch`
- **Branch**: `main`, carpeta `/ (root)`
- Guardar.

En un par de minutos el juego está en
<https://circlenline.github.io/goat-format-simulator/>.

No hace falta tocar nada más: el `.nojekyll` ya está puesto (sin él, GitHub
pasa el sitio por Jekyll y se come cualquier archivo que empiece por `_`).

---

## 4 · Comprobar que se ve bien

Tres cosas que solo se pueden mirar una vez publicado:

1. **La portada carga y el botón de jugar funciona.** El juego son 5,6 MB y
   GitHub los sirve comprimidos (unos 2 por la red), pero la primera carga en
   un móvil con mala cobertura tarda.
2. **El enlace se ve bien al pegarlo.** Pégalo en Discord o WhatsApp: tiene que
   salir el banner del Reino con el título. Si no aparece, suele ser caché del
   servicio; se fuerza con el
   [validador de Facebook](https://developers.facebook.com/tools/debug/).
3. **Google lo encuentra.** Puede tardar días. Para acelerarlo, dar de alta el
   sitio en [Search Console](https://search.google.com/search-console) y mandar
   `https://circlenline.github.io/goat-format-simulator/sitemap.xml`.

---

## 5 · El contador de uso (opcional)

Viene **apagado**: sin código de sitio configurado no manda un solo byte, y
desde un archivo abierto con doble clic tampoco. Para encenderlo, dos líneas:
ver [`docs/ANALITICA.md`](docs/ANALITICA.md).

---

## Lo que hay que saber de la licencia

El motor de reglas (**ocgcore**) y los scripts de carta vienen de
[Project Ignis](https://github.com/ProjectIgnis) y son **AGPL-3.0**. Eso
significa que publicar el juego obliga a ofrecer el código bajo la misma
licencia — por eso el repositorio va **público** y lleva dentro `engine/` con
todas las fuentes. No es opcional.

El arte y el texto de las cartas son de Konami. El arte **no se redistribuye**:
se pide a ygoprodeck desde el navegador de quien juega. El README lo dice y
deja claro que es un proyecto de fan, sin ánimo de lucro y sin relación con
Konami.

---

## Si algo va mal

- **El sitio da 404 al minuto de encender Pages** — normal, tarda un par de
  minutos la primera vez.
- **Se ve el README en vez del juego** — falta el `index.html` en la raíz de la
  rama, o Pages está apuntando a `/docs` en vez de a `/ (root)`.
- **Faltan estilos o imágenes** — falta el `.nojekyll`.
- **Un aviso de GitHub por tráfico** — el límite blando son 100 GB al mes. Si
  llega a pasar, la salida es poner Cloudflare delante (gratis) o mover el
  juego a una Release y dejar la portada en Pages.

---

## Antes de cada actualización

```bash
cd engine && ./rebuild.sh
```

Eso reconstruye los dos HTML y pasa la suite entera, incluida
`check-publicar.mjs`, que comprueba que lo que hay en esta carpeta es el
archivo **recién construido** y no una copia vieja — un error que ya pasó una
vez y que desde fuera no se ve.
